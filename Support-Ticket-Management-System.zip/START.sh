#!/bin/bash
set -e

echo "🚀 Ticket AI System Startup"
echo "================================="

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Start Ollama if not running
echo -e "${BLUE}1️⃣  Checking Ollama...${NC}"
if systemctl is-active --quiet ollama; then
    echo -e "${GREEN}✅ Ollama already running${NC}"
else
    echo "Starting Ollama..."
    sudo systemctl start ollama
    sleep 3
    if systemctl is-active --quiet ollama; then
        echo -e "${GREEN}✅ Ollama started${NC}"
    else
        echo -e "${RED}❌ Ollama failed to start${NC}"
        sudo journalctl -u ollama -n 20
        exit 1
    fi
fi

# Kill any existing backend processes
echo -e "${BLUE}2️⃣  Starting Backend (Port 8080)...${NC}"
pkill -f "TicketAiApplication" || true
sleep 2

cd /home/akash/Projects/ticket-ai

# Start backend in background
nohup mvn spring-boot:run -s /tmp/mvn-settings.xml > /tmp/backend.log 2>&1 &
BACKEND_PID=$!
echo "Backend PID: $BACKEND_PID"

# Wait for backend to start
echo "Waiting for backend to start..."
for i in {1..30}; do
    if curl -s http://localhost:8080/api/tickets > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Backend is running${NC}"
        break
    fi
    if [ $i -eq 30 ]; then
        echo -e "${RED}❌ Backend failed to start${NC}"
        tail -20 /tmp/backend.log
        exit 1
    fi
    sleep 1
    echo -n "."
done
echo ""

# Start frontend
echo -e "${BLUE}3️⃣  Starting Frontend (Port 3000)...${NC}"
pkill -f "react-scripts/scripts/start" || true
sleep 1

cd /home/akash/Projects/ticket-ai/frontend
nohup npm start > /tmp/frontend.log 2>&1 &
FRONTEND_PID=$!
echo "Frontend PID: $FRONTEND_PID"

# Wait for frontend (React compile can take 60+ seconds)
echo "Waiting for frontend to start..."
for i in {1..90}; do
    if curl -s http://localhost:3000 > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Frontend is running${NC}"
        break
    fi
    if [ $i -eq 90 ]; then
        echo -e "${RED}❌ Frontend failed to start${NC}"
        tail -20 /tmp/frontend.log
        exit 1
    fi
    sleep 1
    echo -n "."
done
echo ""

# Summary
echo ""
echo "================================="
echo -e "${GREEN}✅ All services running!${NC}"
echo "================================="
echo -e "${BLUE}Frontend:  ${NC}http://localhost:3000"
echo -e "${BLUE}Backend:   ${NC}http://localhost:8080/api"
echo -e "${BLUE}H2 Console:${NC}http://localhost:8080/h2-console"
echo ""
echo "Backend Log:  tail -f /tmp/backend.log"
echo "Frontend Log: tail -f /tmp/frontend.log"
echo ""
echo "To stop: pkill -f 'TicketAiApplication'; pkill -f 'npm start'"
echo "================================="
