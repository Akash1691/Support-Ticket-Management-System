# Support-Ticket-Management-System

Java 25 + Spring Boot + Spring AI + Ollama + React

## Overview
A support ticket system with:
- CRUD operations + state machine
- Semantic search + filtering
- RAG-based Q&A grounded in ticket history
- Local Ollama embeddings (no cloud dependencies)

## Architecture

```
Frontend (React)
    ↓
Spring Boot REST API
├─ Ticket CRUD
├─ Comments
├─ State Machine (OPEN → IN_PROGRESS → RESOLVED → CLOSED)
├─ Search + Filter
└─ RAG Question-Answering
    ↓
H2 Database + In-Memory Vector Store
    ↓
Ollama (nomic-embed-text + mistral)
```

See [spec/architecture.md](spec/architecture.md) for detailed architecture.

## Quick Start

### Prerequisites
- Java 25
- Docker (for Ollama)
- Maven
- Node 18+ (for frontend)

### 1. Start Ollama

```bash
docker run -d -p 11434:11434 ollama/ollama
docker exec -it <container-id> ollama pull nomic-embed-text
docker exec -it <container-id> ollama pull mistral
```

Verify:
```bash
curl http://localhost:11434/api/tags
```

### 2. Build & Run Backend

```bash
cd /home/akash/Projects/ticket-ai

mvn clean install
mvn spring-boot:run
```

Backend runs on `http://localhost:8080`

H2 Console: `http://localhost:8080/h2-console`
- URL: `jdbc:h2:mem:testdb`
- User: `sa`
- Pass: (blank)

### 3. Run Frontend (Phase 5)

```bash
cd frontend

npm install
npm start
```

Frontend runs on `http://localhost:3000`

---

## API Endpoints

### Tickets
- `POST /api/tickets` — Create ticket
- `GET /api/tickets` — List tickets (w/ search, filter, pagination)
- `GET /api/tickets/{id}` — Get ticket detail
- `PUT /api/tickets/{id}` — Update ticket
- `PATCH /api/tickets/{id}/status` — Change status (state machine enforced)

### Comments
- `POST /api/tickets/{id}/comments` — Add comment
- `GET /api/tickets/{id}/comments` — List comments

### RAG
- `POST /api/ai/ask` — Ask question over ticket history

See [spec/api-contract.md](spec/api-contract.md) for full API spec.

---

## Testing

### Unit Tests
```bash
mvn test -Dtest=*Service*
```

### Integration Tests
```bash
mvn test -Dtest=*Controller*
```

### Coverage
```bash
mvn clean test jacoco:report
open target/site/jacoco/index.html
```

---

## State Machine

Valid transitions:
```
OPEN ──→ IN_PROGRESS ──→ RESOLVED ──→ CLOSED
  ↓                        ↓
CANCELLED (from OPEN or IN_PROGRESS only)
```

Invalid transitions rejected by backend (409 Conflict).

---

## RAG Strategy

### Chunking
Semantic chunks by ticket section:
1. **Description**: ticket title + description + metadata
2. **Comments**: each comment as separate chunk
3. **Resolution**: final resolution notes (optional)

See [spec/rag-strategy.md](spec/rag-strategy.md) for full strategy.

### Embedding Model
- **Ollama + nomic-embed-text**
- 768 dimensions
- Local (no API keys, no cloud cost)
- ~100ms embedding latency

Why not OpenAI? See [spec/rag-strategy.md#embedding-model](spec/rag-strategy.md).

### Retrieval
- Top-K: 5 (configurable)
- Similarity threshold: 0.7 (configurable)
- Returns answer + cited ticket IDs
- "No match" if threshold not met (no hallucination)

### Grounding
- Answer generated ONLY from retrieved context
- LLM system prompt enforces grounding
- Hallucination detection: answer cites tickets from context only
- Metrics logged: hit rate, relevance scores

---

## Configuration

Edit `src/main/resources/application.properties`:

```properties
# Ollama
spring.ai.ollama.base-url=http://localhost:11434
spring.ai.ollama.chat.model=mistral
spring.ai.ollama.embedding.model=nomic-embed-text

# RAG
rag.retrieval.topK=5
rag.retrieval.similarityThreshold=0.7

# H2 (change for prod: remove mem:, use file path)
spring.datasource.url=jdbc:h2:mem:testdb
spring.jpa.hibernate.ddl-auto=update
```

---

## Project Structure

```
.cursor/rules/           # AI guidelines
├─ java-springboot.md
├─ testing.md
├─ api-standards.md
└─ rag-vector-store.md

spec/                    # Specifications
├─ requirements.md
├─ architecture.md
├─ data-model.md
├─ api-contract.md
├─ rag-strategy.md
└─ implementation-plan.md

src/main/java/support_ticket_ai/
├─ controller/          # REST endpoints
├─ service/             # Business logic
├─ repository/          # Data access
├─ entity/              # JPA entities
├─ dto/                 # Request/response
├─ exception/           # Custom exceptions
├─ rag/                 # RAG pipeline
└─ config/              # Spring beans

src/test/java/          # Tests

frontend/               # React UI (Phase 5)
```

---

## Development Workflow

1. **Plan**: Read spec files (requirements, architecture, api-contract)
2. **Implement**: Follow rules in `.cursor/rules/`
3. **Test**: Write tests alongside code
4. **Validate**: Run full test suite before PR
5. **Document**: Update spec files + commit message

See [spec/implementation-plan.md](spec/implementation-plan.md) for phases.

---

## Key Decisions

### Ollama vs OpenAI
- Local (privacy)
- No API keys needed
- Lower latency (~100ms)
- Cost: free (self-hosted)
- See [spec/rag-strategy.md#embedding-model](spec/rag-strategy.md) for full analysis

### Semantic Chunking vs Fixed-Size
- Preserves ticket structure (Description, Comment, Resolution)
- Better retrieval quality for bounded domain
- No overlap needed

### Spring AI In-Memory VectorStore (Phase 1) → PGVector (Phase 2)
- Phase 1: H2 + in-memory (dev/test friendly)
- Phase 2: Postgres + PGVector (prod scalability)
- Same API abstraction (easy swap)

---

## Acceptance Criteria

- [x] Specification complete
- [x] Ollama integrated (no OpenAI)
- [x] Configuration setup
- [ ] Phase 2: CRUD + Comments
- [ ] Phase 3: State Machine
- [ ] Phase 4: Search + Filter
- [ ] Phase 5: RAG Pipeline
- [ ] Phase 6: Frontend
- [ ] Phase 7: Tests + Polish

See [spec/requirements.md](spec/requirements.md#acceptance-criteria-mvp) for full checklist.

---

## Debugging

### Ollama not responding
```bash
curl http://localhost:11434/api/tags
# Should return list of models

docker logs <container-id>
# Check for errors
```

### Embeddings not generated
```
Check: TicketIngestionService logs
Check: VectorStore bean initialized
Check: Ollama model endpoint reachable
```

### RAG returns "no match"
```
1. Verify question is support-domain related
2. Check similarity threshold (maybe too strict)
3. Verify embeddings were created for tickets
4. Run `GET /api/tickets` to confirm data exists
```

---

## Monitoring

### Logs
All operations logged:
- Ticket CRUD
- State transitions
- RAG retrieval (question, hit rate, scores)
- Hallucination detections
- Ollama errors

### Metrics
```
rag.hit_rate           # % of questions with ≥1 relevant chunk
rag.avg_relevance_score # avg cosine similarity
rag.hallucination_count # answers citing out-of-context tickets
```

---

## Next Steps

1. [x] Phase 1: Specification + Rules (DONE)
2. [ ] Phase 2: Ticket CRUD
3. [ ] Phase 3: State Machine
4. [ ] Phase 4: Search + Filter
5. [ ] Phase 5: RAG Pipeline
6. [ ] Phase 6: Frontend
7. [ ] Phase 7: Testing + Polish

See [spec/implementation-plan.md](spec/implementation-plan.md) for detailed tasks.

---

## References

- [Spring AI Docs](https://docs.spring.io/spring-ai/reference/)
- [Ollama](https://ollama.ai/)
- [nomic-embed-text](https://huggingface.co/nomic-ai/nomic-embed-text-v1)
- [Spring Data JPA](https://spring.io/projects/spring-data-jpa)
- [H2 Database](https://www.h2database.com/)
