#!/usr/bin/env bash
# Seed 100 support tickets across diverse categories for RAG testing
BASE="http://localhost:8080/api/tickets"

post() {
  curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE" \
    -H "Content-Type: application/json" \
    -d "$1"
}

tick=0
ok=0

send() {
  code=$(post "$1")
  tick=$((tick+1))
  [[ "$code" == "201" ]] && ok=$((ok+1))
  printf "  [%3d] %s\n" "$tick" "$code"
}

echo "==> Seeding 100 tickets to $BASE"
echo ""

# ── Payments (12) ──────────────────────────────────────────────────────────
echo "--- Payments ---"
send '{"title":"Payment gateway timeout on checkout","description":"Users report 504 errors after 30s on /checkout/pay. Affects ~12% of sessions during peak hours. Traced to upstream payment provider latency spikes.","priority":"CRITICAL","category":"Payments"}'
send '{"title":"Duplicate charge on subscription renewal","description":"Several customers billed twice on monthly renewal. Idempotency key not being sent correctly to Stripe API in retry logic.","priority":"CRITICAL","category":"Payments"}'
send '{"title":"Credit card validation rejects valid Amex cards","description":"15-digit Amex card numbers failing frontend Luhn check. Regex pattern requires exactly 16 digits.","priority":"HIGH","category":"Payments"}'
send '{"title":"Refund not reflected in customer account after 5 days","description":"Refund issued via Stripe dashboard but customer balance not updated in our system. Webhook handler may be dropping refund events.","priority":"HIGH","category":"Payments"}'
send '{"title":"Currency conversion rounding error on invoices","description":"GBP invoices show 0.01 discrepancy due to floating-point arithmetic in currency conversion utility.","priority":"MEDIUM","category":"Payments"}'
send '{"title":"PayPal checkout button not rendering on Safari","description":"PayPal SDK fails to initialize on Safari 17 due to missing popup blocker exception. Affects iOS and macOS Safari users.","priority":"HIGH","category":"Payments"}'
send '{"title":"Promo code discount not applied at checkout","description":"SAVE20 promo code accepted but 20% discount not deducted from order total. Backend validation passes but price calculation skips discount step.","priority":"HIGH","category":"Payments"}'
send '{"title":"Invoice PDF generation fails for large orders","description":"Orders with more than 50 line items cause PDF generator to timeout. Memory limit reached in pdf-lib during table rendering.","priority":"MEDIUM","category":"Payments"}'
send '{"title":"Bank transfer option missing for EU customers","description":"SEPA bank transfer payment method not shown for customers with EU billing address. Feature flag incorrectly scoped to US only.","priority":"MEDIUM","category":"Payments"}'
send '{"title":"Subscription plan upgrade does not prorate correctly","description":"Mid-cycle plan upgrade charges full new plan price instead of prorated amount. Billing cycle anchor not being respected.","priority":"HIGH","category":"Payments"}'
send '{"title":"3DS authentication redirect loop","description":"Customers using 3DS cards get stuck in redirect loop between our callback URL and bank authentication page. State parameter not preserved across redirect.","priority":"CRITICAL","category":"Payments"}'
send '{"title":"Payment history CSV export includes wrong date range","description":"Exporting last 30 days of payments returns data from last 60 days. Date filter using createdAt instead of processedAt.","priority":"LOW","category":"Payments"}'

# ── Authentication (10) ───────────────────────────────────────────────────
echo "--- Authentication ---"
send '{"title":"SSO login fails with SAML signature validation error","description":"Enterprise customers using Okta SSO get SAML signature validation failure. Certificate thumbprint mismatch after Okta certificate rotation.","priority":"CRITICAL","category":"Authentication"}'
send '{"title":"Password reset email not delivered","description":"Reset emails sent successfully per logs but not received by customers. Mailgun suppression list blocking domain after bounce spike last week.","priority":"HIGH","category":"Authentication"}'
send '{"title":"MFA TOTP codes rejected after timezone change","description":"Users who changed device timezone report valid TOTP codes being rejected. Server time drift of 45s outside 30s window tolerance.","priority":"HIGH","category":"Authentication"}'
send '{"title":"Session token not invalidated after logout","description":"JWT remains valid for up to 24h after user logs out. Token blacklist not being checked on subsequent requests.","priority":"HIGH","category":"Authentication"}'
send '{"title":"Google OAuth callback URL mismatch in production","description":"Google OAuth2 flow fails in production with redirect_uri_mismatch. Prod callback URL missing from Google Cloud Console authorized URIs.","priority":"CRITICAL","category":"Authentication"}'
send '{"title":"Account locked after 3 failed attempts instead of 10","description":"Brute-force lockout triggering too aggressively. Failed attempt counter not resetting after successful login.","priority":"MEDIUM","category":"Authentication"}'
send '{"title":"Remember me cookie expires after browser close","description":"Persistent session cookie set with session scope instead of max-age. Users must log in on every browser restart.","priority":"LOW","category":"Authentication"}'
send '{"title":"Magic link tokens expire too quickly","description":"Passwordless login links expire in 5 minutes causing friction for users with slow email delivery. Configurable expiry needed.","priority":"MEDIUM","category":"Authentication"}'
send '{"title":"API key rotation breaks existing integrations","description":"Rotating API keys immediately invalidates old key with no grace period. Integrations need overlap window to update.","priority":"HIGH","category":"Authentication"}'
send '{"title":"Login page CSRF token missing on page refresh","description":"Hard refresh on login page results in CSRF token validation failure on first submit. Token not regenerated on GET.","priority":"MEDIUM","category":"Authentication"}'

# ── Performance (10) ──────────────────────────────────────────────────────
echo "--- Performance ---"
send '{"title":"Dashboard load time exceeds 8s for large accounts","description":"Accounts with more than 10k records see dashboard load times of 8-12s. N+1 query on related entities fetching one record at a time.","priority":"HIGH","category":"Performance"}'
send '{"title":"Search results slow when filtering by date range","description":"Filtering tickets by date range on large datasets takes 6-10s. Missing composite index on (created_at, status).","priority":"HIGH","category":"Performance"}'
send '{"title":"PDF report generation blocks main thread","description":"Generating monthly PDF reports causes API response times to spike system-wide. PDF job not offloaded to background worker queue.","priority":"HIGH","category":"Performance"}'
send '{"title":"Memory leak in WebSocket connection handler","description":"WebSocket service memory usage grows 50MB/hour under load. Connections not being cleaned up on client disconnect event.","priority":"CRITICAL","category":"Performance"}'
send '{"title":"Bulk import of 5000 records times out","description":"CSV imports exceeding 5000 rows timeout after 30s. No streaming or chunked processing implemented, entire file loaded into memory.","priority":"HIGH","category":"Performance"}'
send '{"title":"Autocomplete search triggers on every keystroke","description":"Search input fires API request on each keypress causing 20+ requests per second. Debounce not applied to search handler.","priority":"MEDIUM","category":"Performance"}'
send '{"title":"Image thumbnails not cached causing repeated S3 requests","description":"Product images fetched from S3 on every page load. No CDN caching headers set on image responses.","priority":"MEDIUM","category":"Performance"}'
send '{"title":"Database connection pool exhausted during traffic spike","description":"Connection pool limit of 10 exceeded during peak load causing request queuing. Pool size not tuned for concurrent user load.","priority":"CRITICAL","category":"Performance"}'
send '{"title":"Scheduled job runs every minute instead of daily","description":"Cleanup job cron expression set to * * * * * instead of 0 0 * * *. Running 1440x more frequently than intended.","priority":"HIGH","category":"Performance"}'
send '{"title":"GraphQL query with deep nesting causes stack overflow","description":"Deeply nested GraphQL queries (depth > 15) cause stack overflow in resolver. No query depth limit configured.","priority":"HIGH","category":"Performance"}'

# ── UI/UX (10) ───────────────────────────────────────────────────────────
echo "--- UI/UX ---"
send '{"title":"Date picker shows wrong month on initial render","description":"Calendar opens showing current month minus one. Off-by-one error in month index initialization (0-indexed vs 1-indexed).","priority":"MEDIUM","category":"UI/UX"}'
send '{"title":"Form does not scroll to first validation error","description":"On submit with validation errors, page stays at current scroll position. Users miss error messages above the fold.","priority":"MEDIUM","category":"UI/UX"}'
send '{"title":"Dark mode toggle not persisted across sessions","description":"Dark mode preference resets on page reload. Theme stored in component state instead of localStorage.","priority":"LOW","category":"UI/UX"}'
send '{"title":"Mobile navigation menu overlaps page content","description":"Hamburger menu opens but does not push content, overlay appears behind interactive elements on iOS 17 Safari.","priority":"HIGH","category":"UI/UX"}'
send '{"title":"Data table column sort resets on pagination","description":"Sorting by name column then navigating to page 2 clears the sort order. Sort state not included in pagination query params.","priority":"MEDIUM","category":"UI/UX"}'
send '{"title":"Tooltip text truncated on small screen widths","description":"Tooltips wider than viewport get clipped with no scroll or wrapping. Tooltip overflow hidden without max-width constraint.","priority":"LOW","category":"UI/UX"}'
send '{"title":"File upload progress bar stuck at 99%","description":"Large file uploads show 99% progress then stall for 30-60s while server processes. Upload completion event fires only after full server processing.","priority":"MEDIUM","category":"UI/UX"}'
send '{"title":"Confirmation dialog missing on bulk delete action","description":"Bulk delete button removes selected records immediately with no confirm prompt. Accidental deletions reported by multiple users.","priority":"HIGH","category":"UI/UX"}'
send '{"title":"Keyboard navigation skips dropdown menu items","description":"Tab order bypasses dropdown options, failing WCAG 2.1 keyboard navigation requirement. Dropdown items not in tab index sequence.","priority":"MEDIUM","category":"UI/UX"}'
send '{"title":"Empty state illustration missing on filtered views","description":"When filters return no results, page shows blank white space instead of empty state with clear action prompt.","priority":"LOW","category":"UI/UX"}'

# ── API / Integration (10) ───────────────────────────────────────────────
echo "--- API/Integration ---"
send '{"title":"Webhook events delivered out of order","description":"Event ordering not guaranteed causing downstream systems to process updates before creates. No sequence number or causal ordering implemented.","priority":"HIGH","category":"API"}'
send '{"title":"Rate limiter returning 429 for whitelisted IPs","description":"IP whitelist for premium API tier not checked before rate limit counter. Whitelisted customers hit 100 req/min limit.","priority":"HIGH","category":"API"}'
send '{"title":"REST API returns 200 for validation errors","description":"Input validation failures returning HTTP 200 with error body instead of 400. Frontend error handling relies on status code.","priority":"HIGH","category":"API"}'
send '{"title":"Pagination cursor breaks with special characters in IDs","description":"Cursor-based pagination fails when record IDs contain + or / characters. Base64 encoding not URL-safe.","priority":"MEDIUM","category":"API"}'
send '{"title":"Zapier integration stops syncing after OAuth token expiry","description":"Zapier integration fails silently when OAuth token expires. Refresh token flow not implemented, requiring manual re-authentication.","priority":"HIGH","category":"API"}'
send '{"title":"Slack notification webhook sends duplicate messages","description":"Slack notifications sent twice for some events. Retry logic triggers on timeout but original request was processed.","priority":"MEDIUM","category":"API"}'
send '{"title":"API documentation shows deprecated endpoint as active","description":"Docs still list /v1/users/search as active endpoint. It was removed in v2 but docs not updated. Causing integration failures.","priority":"MEDIUM","category":"API"}'
send '{"title":"CORS headers missing on OPTIONS preflight response","description":"Browser preflight requests failing for cross-origin API calls. Access-Control-Allow-Methods not included in OPTIONS response.","priority":"HIGH","category":"API"}'
send '{"title":"Batch API endpoint ignores items after index 100","description":"Batch create endpoint silently drops items beyond index 100. Undocumented limit not communicated to caller.","priority":"HIGH","category":"API"}'
send '{"title":"GraphQL mutation returns stale data after update","description":"After updating a record via mutation, returned object reflects pre-update state. Cache not invalidated before response constructed.","priority":"MEDIUM","category":"API"}'

# ── Data / Database (10) ─────────────────────────────────────────────────
echo "--- Data ---"
send '{"title":"Soft-deleted records appearing in list views","description":"Records marked deleted_at still returned in API responses. WHERE clause missing deleted_at IS NULL filter in list queries.","priority":"HIGH","category":"Data"}'
send '{"title":"Data export includes PII fields without redaction","description":"CSV export of user records includes raw email, phone, and address without masking. GDPR compliance risk.","priority":"CRITICAL","category":"Data"}'
send '{"title":"Search index out of sync after bulk update","description":"Bulk status update not propagating to Elasticsearch index. Background sync job failing silently on bulk payloads.","priority":"HIGH","category":"Data"}'
send '{"title":"Timezone-naive timestamps causing date grouping errors","description":"Daily aggregation reports showing wrong day boundaries for non-UTC users. Timestamps stored as UTC but grouped without timezone conversion.","priority":"MEDIUM","category":"Data"}'
send '{"title":"Database migration fails on existing production data","description":"Migration adding NOT NULL column fails on tables with existing rows. Default value not specified in migration script.","priority":"CRITICAL","category":"Data"}'
send '{"title":"Cascade delete removing unrelated child records","description":"Deleting a parent organization cascades to delete shared resource records used by other organizations.","priority":"CRITICAL","category":"Data"}'
send '{"title":"Audit log missing entries for admin actions","description":"Admin bulk operations not writing to audit log. Audit middleware skipped for admin role routes.","priority":"HIGH","category":"Data"}'
send '{"title":"CSV import silently ignores rows with encoding errors","description":"UTF-8 BOM and Windows-1252 encoded CSVs cause rows to be skipped without error reporting. No encoding detection or error feedback.","priority":"MEDIUM","category":"Data"}'
send '{"title":"Duplicate records created during concurrent requests","description":"Race condition in upsert logic allows two simultaneous requests to create duplicate records. Missing unique constraint and proper locking.","priority":"HIGH","category":"Data"}'
send '{"title":"Report aggregation incorrect for accounts spanning multiple timezones","description":"Multi-region accounts show daily totals double-counted at UTC midnight. Aggregation not aware of account-level timezone setting.","priority":"MEDIUM","category":"Data"}'

# ── Infrastructure / DevOps (10) ─────────────────────────────────────────
echo "--- Infrastructure ---"
send '{"title":"Deployment pipeline fails on Node 20 upgrade","description":"CI build fails after Node.js upgrade to v20. Several transitive dependencies use deprecated APIs removed in v20.","priority":"HIGH","category":"Infrastructure"}'
send '{"title":"Health check endpoint returns 200 during startup","description":"Kubernetes liveness probe hitting /health which returns 200 before app is ready to serve traffic. Readiness probe not configured.","priority":"HIGH","category":"Infrastructure"}'
send '{"title":"SSL certificate auto-renewal cron not running","description":"Let\'s Encrypt cert renewal cron job disabled after server migration. Certificate expires in 14 days.","priority":"CRITICAL","category":"Infrastructure"}'
send '{"title":"Log rotation not configured on application servers","description":"Application logs filling disk to 100% capacity. Log rotation not set up, /var/log partition exhausted after 72h.","priority":"HIGH","category":"Infrastructure"}'
send '{"title":"Redis eviction causing session loss under memory pressure","description":"Redis memory limit reached, LRU eviction removing active session keys. Session store not separated from cache store.","priority":"HIGH","category":"Infrastructure"}'
send '{"title":"Container restart loop due to misconfigured env var","description":"Payment service pod in CrashLoopBackOff. PAYMENT_API_URL env var pointing to staging URL in production config.","priority":"CRITICAL","category":"Infrastructure"}'
send '{"title":"Backup job not verifying restore integrity","description":"Nightly database backups complete successfully but restore procedure never tested. Backup files corrupted for last 3 days.","priority":"CRITICAL","category":"Infrastructure"}'
send '{"title":"CDN cache not purged after content update","description":"Static asset updates not reflected for users due to 7-day CDN TTL with no cache invalidation on deploy.","priority":"MEDIUM","category":"Infrastructure"}'
send '{"title":"Alert thresholds not updated after traffic growth","description":"CPU alert threshold set to 80% correct for old traffic volume. Service runs at 75% baseline, alerts not firing when actually degraded.","priority":"MEDIUM","category":"Infrastructure"}'
send '{"title":"Secrets stored in environment variables visible in process list","description":"API keys set as process env vars visible via ps aux by other users on shared host. Should use secrets manager.","priority":"HIGH","category":"Infrastructure"}'

# ── Email / Notifications (8) ────────────────────────────────────────────
echo "--- Notifications ---"
send '{"title":"Welcome email sent multiple times on signup","description":"New user registration triggers welcome email 3-4 times. Event listener registered multiple times due to hot-reload in dev bleeding into prod deploy.","priority":"HIGH","category":"Notifications"}'
send '{"title":"Email unsubscribe link not working","description":"Clicking unsubscribe in email returns 404. Unsubscribe route removed during URL restructuring, link in email not updated.","priority":"HIGH","category":"Notifications"}'
send '{"title":"Push notifications not delivered on Android 14","description":"FCM push notifications failing for Android 14 devices after Google changed notification permission model. Permission not re-requested on upgrade.","priority":"HIGH","category":"Notifications"}'
send '{"title":"In-app notification badge count not updating in real time","description":"Unread notification count only updates on page refresh. WebSocket message handler not connected to badge counter component.","priority":"MEDIUM","category":"Notifications"}'
send '{"title":"Digest email contains HTML tags in plain text version","description":"Users on email clients showing plain text see raw HTML tags. Plain text version generated from HTML without stripping tags.","priority":"MEDIUM","category":"Notifications"}'
send '{"title":"Notification preferences not respected for system alerts","description":"Users who opted out of all notifications still receive critical system alerts. System alerts bypassing preference check.","priority":"HIGH","category":"Notifications"}'
send '{"title":"Email template broken in Outlook 2019","description":"Marketing email layout broken in Outlook 2019 due to CSS Grid usage. Outlook requires table-based layout for consistent rendering.","priority":"MEDIUM","category":"Notifications"}'
send '{"title":"SMS verification codes not delivered to international numbers","description":"OTP SMS delivery failing for +44 and +49 numbers. Twilio account not configured for international messaging, only US numbers enabled.","priority":"HIGH","category":"Notifications"}'

# ── Search (5) ───────────────────────────────────────────────────────────
echo "--- Search ---"
send '{"title":"Full-text search not finding hyphenated words","description":"Searching for e-commerce returns no results matching ecommerce or e commerce. Tokenizer not configured to handle hyphen as word separator.","priority":"MEDIUM","category":"Search"}'
send '{"title":"Search ranking ignores recency for stale popular results","description":"Old highly-clicked results ranking above recent relevant content. Recency signal not included in ranking formula.","priority":"MEDIUM","category":"Search"}'
send '{"title":"Autocomplete shows deleted items","description":"Search suggestions include product names for items that have been deleted. Suggestion index not updated on soft delete.","priority":"MEDIUM","category":"Search"}'
send '{"title":"Search results differ between regions due to index lag","description":"EU search index 6-8 hours behind US primary. Replication lag causing inconsistent search results globally.","priority":"HIGH","category":"Search"}'
send '{"title":"Boolean search operators treated as literal text","description":"Searching ticket AND payment returns results containing the word AND. Boolean operator parsing not implemented in query parser.","priority":"LOW","category":"Search"}'

# ── Billing (5) ──────────────────────────────────────────────────────────
echo "--- Billing ---"
send '{"title":"Annual plan discount not reflected on first invoice","description":"Customers upgrading to annual billing charged monthly rate on first cycle. Discount coupon applied to renewals but not initial annual invoice.","priority":"HIGH","category":"Billing"}'
send '{"title":"Tax calculation incorrect for Canadian provinces","description":"Canadian customers in Quebec charged 5% GST instead of 14.975% combined GST+QST. Province-specific tax rates not configured.","priority":"HIGH","category":"Billing"}'
send '{"title":"Billing address not updated when shipping address changes","description":"Updating shipping address in account settings does not sync to billing address. Two separate address records not linked.","priority":"LOW","category":"Billing"}'
send '{"title":"Enterprise contract end date not triggering renewal workflow","description":"Contract expiry date not connected to renewal notification workflow. Three enterprise contracts lapsed without renewal outreach.","priority":"CRITICAL","category":"Billing"}'
send '{"title":"Usage-based billing calculation off by one billing period","description":"Usage metrics aggregated for wrong time window. Billing period starts on day 1 but usage counter resets at midnight UTC vs account timezone.","priority":"HIGH","category":"Billing"}'

echo ""
echo "==> Done. $ok/100 tickets created successfully."
