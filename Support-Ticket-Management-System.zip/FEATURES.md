# 📋 Feature Overview - Ticket AI System

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    SUPPORT TICKET AI SYSTEM                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────┐           ┌──────────────────┐            │
│  │  Frontend (UI)   │◄────────► │  Backend (API)   │            │
│  │  React 18        │           │  Spring Boot 4.1 │            │
│  │  TypeScript      │           │  Java 25         │            │
│  │  Port: 3000      │           │  Port: 8080      │            │
│  └──────────────────┘           └────────┬─────────┘            │
│                                           │                      │
│                                    ┌──────▼────────┐            │
│                                    │   Databases   │            │
│                                    ├───────────────┤            │
│                                    │  H2 (SQL)     │            │
│                                    │  Embeddings   │            │
│                                    └────────┬──────┘            │
│                                            │                    │
│                           ┌────────────────▼──────────────┐    │
│                           │    Ollama (Local LLM)         │    │
│                           ├───────────────────────────────┤    │
│                           │ Models:                       │    │
│                           │ - mistral (7B chat)           │    │
│                           │ - nomic-embed-text (768-dim)  │    │
│                           │ Port: 11434                   │    │
│                           └──────────────────────────────┘    │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Feature Categories

### 1. 🎫 Core Ticket Management

#### Create Tickets
- **Endpoint**: `POST /api/tickets`
- **UI**: "Create" button
- Fields: Title, Description, Priority (LOW, MEDIUM, HIGH, CRITICAL), Category
- Auto-generates: ID, Status (OPEN), timestamps

#### View Tickets
- **Endpoint**: `GET /api/tickets`
- **UI**: Main list view with pagination
- Features: Sorting, pagination (20 per page)
- Show: ID, Title, Status, Priority, Created date

#### View Ticket Detail
- **Endpoint**: `GET /api/tickets/{id}`
- **UI**: Click any ticket to expand
- Show: Full description, comments, assignee, category
- Actions: Change status, update assignee, add comments

#### Update Tickets
- **Endpoint**: `PUT /api/tickets/{id}`
- Fields: Title, Description, Priority, Category

#### Search & Filter
- **Endpoint**: `GET /api/tickets?search=...&status=...&priority=...`
- Search: Full-text search on title + description
- Filter: By status or priority
- UI: Search bar + filter dropdowns

#### Delete Tickets
- **Endpoint**: `DELETE /api/tickets/{id}`
- UI: Delete button in detail view

---

### 2. 💬 Comments & Collaboration

#### Add Comments
- **Endpoint**: `POST /api/tickets/{id}/comments`
- Fields: Text, Author
- UI: Comment box at bottom of ticket detail

#### View Comments
- **Endpoint**: `GET /api/tickets/{id}/comments`
- Show: Comment text, author, creation date
- Appears below ticket in detail view

#### Thread View
- Comments organized chronologically
- Shows conversation history for context

---

### 3. 🔄 State Management

#### Status Transitions
Valid state machine:
```
OPEN ──► IN_PROGRESS ──► RESOLVED ──► CLOSED
  │                           ▲
  ↓___________________________|
CANCELLED
```

- **Endpoint**: `PATCH /api/tickets/{id}/status`
- UI: Status dropdown in detail view
- Enforces valid transitions (prevents invalid states)

#### Priority & Assignment
- **Assign**: `PATCH /api/tickets/{id}/assignee`
- **Change Priority**: `PUT /api/tickets/{id}`
- UI: Both in detail view

---

### 4. 🤖 AI-Powered Features

### A. Ask AI (RAG - Retrieval Augmented Generation)

**Purpose**: Answer questions about ticket history with citations

- **Endpoint**: `POST /api/ai/ask`
- **UI**: "💡 Ask AI" quick button OR full AI Hub
- **How it works**:
  1. Searches relevant tickets using embeddings
  2. Retrieves top-K most similar tickets
  3. Generates answer grounded in those tickets
  4. Cites specific ticket IDs
  
- **Inputs**:
  - Question (required)
  - topK (1-20, default 5)
  - similarityThreshold (0.0-1.0, default 0.7)

- **Outputs**:
  - Answer text
  - List of cited tickets (TKT-1, TKT-2, etc)
  - Relevance score
  - "No match" indicator if insufficient results

- **Example Questions**:
  - "Have we seen payment failures before?"
  - "What are common shipping issues?"
  - "How many login problems have we had?"

### B. Sentiment Analysis

**Purpose**: Understand customer mood and urgency

- **Endpoint**: `POST /api/ai/sentiment`
- **UI**: Sentiment tab in AI Hub
- **Returns**:
  - Sentiment: POSITIVE, NEGATIVE, or NEUTRAL
  - Confidence: 0.0-1.0 (how sure the model is)
  - Explanation: Why the text has that sentiment

- **Use Cases**:
  - Assess customer frustration
  - Prioritize urgent complaints
  - Monitor satisfaction trends

### C. Text Summarization

**Purpose**: Condense long descriptions to key points

- **Endpoint**: `POST /api/ai/summarize`
- **UI**: Summarize tab in AI Hub
- **Returns**:
  - Summary: Concise version
  - Compression ratio: How much smaller (e.g., 3.5x compression)
  - Original text preserved

- **Use Cases**:
  - Quick ticket overview
  - Create ticket notes
  - Export summaries for reports

### D. Auto-Tag Generation

**Purpose**: Automatically categorize tickets

- **Endpoint**: `POST /api/ai/tags`
- **UI**: Tags tab in AI Hub
- **Returns**:
  - Tags: List of relevant keywords (e.g., ["login", "urgent", "authentication"])
  - Suggested category: Higher-level classification

- **Use Cases**:
  - Auto-tag new tickets
  - Discover related issues
  - Build knowledge base taxonomies

---

## API Quick Reference

| Feature | Method | Endpoint | Purpose |
|---------|--------|----------|---------|
| **Tickets** |
| Create | POST | `/api/tickets` | Create new ticket |
| List | GET | `/api/tickets` | List all tickets (paginated) |
| Detail | GET | `/api/tickets/{id}` | Get single ticket + comments |
| Update | PUT | `/api/tickets/{id}` | Update ticket fields |
| Change Status | PATCH | `/api/tickets/{id}/status` | Change ticket status |
| Update Assignee | PATCH | `/api/tickets/{id}/assignee` | Assign to user |
| Delete | DELETE | `/api/tickets/{id}` | Delete ticket |
| **Comments** |
| Add | POST | `/api/tickets/{id}/comments` | Add comment to ticket |
| List | GET | `/api/tickets/{id}/comments` | Get ticket comments |
| **AI Features** |
| Ask | POST | `/api/ai/ask` | RAG Q&A over tickets |
| Sentiment | POST | `/api/ai/sentiment` | Analyze text sentiment |
| Summarize | POST | `/api/ai/summarize` | Summarize text |
| Tags | POST | `/api/ai/tags` | Generate tags & category |

---

## UI Components

### Pages

**Tickets List** (`/`)
- Grid of tickets with pagination
- Search & filter bars
- Create button
- Click to view detail

**Ticket Detail** (`/tickets/{id}`)
- Full ticket info
- Comment section
- Status/priority/assignee controls
- Back button

**Create Ticket** (`/create`)
- Form with required fields
- Priority selector
- Success confirmation

**AI Hub** (`/ai`)
- 4 tabs: Ask, Sentiment, Summarize, Tags
- Each tab is a mini-app for that feature
- Real-time API testing

### Header

- App title with logo
- Two action buttons:
  - **🤖 AI Hub**: Full AI interface
  - **💡 Ask AI**: Quick ask dialog
- Professional gradient styling

---

## Technology Stack

### Backend
- **Framework**: Spring Boot 4.1.1
- **Language**: Java 25
- **Database**: H2 (in-memory)
- **ORM**: JPA/Hibernate
- **AI Libraries**: Spring AI 2.0.1
- **Build**: Maven 3.9.16

### Frontend
- **Framework**: React 18
- **Language**: TypeScript
- **HTTP Client**: Axios
- **Styling**: CSS-in-JS (inline styles)
- **Build**: Create React App
- **Package Manager**: npm

### AI Infrastructure
- **LLM Runtime**: Ollama (local)
- **Chat Model**: mistral (7B)
- **Embedding Model**: nomic-embed-text (768-dim)
- **Vector Storage**: In-memory vectors

---

## Data Models

### Ticket
```json
{
  "id": 1,
  "title": "Login button not working",
  "description": "Users report unable to click login button",
  "status": "OPEN",
  "priority": "HIGH",
  "assignee": "john@example.com",
  "category": "Bug",
  "createdAt": "2026-09-08T10:00:00Z",
  "updatedAt": "2026-09-08T10:00:00Z"
}
```

### Comment
```json
{
  "id": 1,
  "ticketId": 1,
  "text": "Reproduced on Firefox",
  "author": "jane@example.com",
  "createdAt": "2026-09-08T11:00:00Z"
}
```

### Ask Response
```json
{
  "question": "Payment issues?",
  "answer": "Yes, in TKT-1 and TKT-3...",
  "citedTickets": [1, 3],
  "relevanceScore": 0.85,
  "noMatch": false
}
```

---

## Status Codes & Errors

### Success
- `200 OK`: Request successful
- `201 Created`: Resource created

### Client Errors
- `400 Bad Request`: Invalid input
- `404 Not Found`: Resource doesn't exist
- `422 Unprocessable Entity`: Validation error

### Server Errors
- `500 Internal Server Error`: Server issue
- `503 Service Unavailable`: Ollama not running

### Common Error Response
```json
{
  "timestamp": "2026-09-08T10:00:00Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Question is required",
  "path": "/api/ai/ask"
}
```

---

## Performance Metrics

| Operation | Typical Time |
|-----------|-------------|
| Create ticket | < 100ms |
| List tickets (page 1) | < 200ms |
| Get ticket detail | < 150ms |
| Search tickets | 200-500ms |
| Add comment | < 100ms |
| Ask AI (RAG) | 5-10s |
| Sentiment analysis | 3-5s |
| Summarization | 4-8s |
| Tag generation | 3-5s |

---

## Security Considerations

### Current Implementation
- Basic request validation
- CORS enabled for localhost
- No authentication (dev mode)

### For Production
- [ ] Add JWT authentication
- [ ] Implement user roles (admin, agent, customer)
- [ ] Add input sanitization
- [ ] Rate limiting on AI endpoints
- [ ] Encrypt sensitive data in transit
- [ ] Audit logging for AI operations

---

## Future Feature Ideas

### Phase 7: Analytics
- Dashboard: Ticket trends, AI usage stats
- Reports: Monthly summaries, issue patterns
- Charts: Status distribution, priority trends

### Phase 8: Advanced RAG
- Fine-tuned embeddings per organization
- Multi-document chunking strategies
- Caching of embeddings
- Streaming responses

### Phase 9: Automation
- Auto-tag new tickets
- Suggested status transitions
- Escalation rules
- Template suggestions

### Phase 10: Integrations
- Slack notifications
- Email parsing (ticket creation)
- Zapier/IFTTT support
- Third-party API webhooks

---

## Deployment

### Development
```bash
./START.sh
# Opens: 
# - http://localhost:3000 (Frontend)
# - http://localhost:8080/api (Backend)
# - http://localhost:11434 (Ollama)
```

### Production
- Docker Compose setup needed
- Ollama model persistence
- Database migration to PostgreSQL
- Reverse proxy (Nginx)
- HTTPS/TLS enforcement
- Environment-specific configs

---

**Version**: 1.0.0  
**Last Updated**: September 8, 2026  
**Built with**: Java 25 | Spring Boot 4.1 | React 18 | Ollama
