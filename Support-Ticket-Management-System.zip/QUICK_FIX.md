# Quick Fix: "Network error or server unavailable"

## The Problem
Frontend shows: **"Network error or server unavailable"**

## The Solution (3 Steps)

### Step 1: Start Ollama (if not running)
```bash
docker run -d -p 11434:11434 ollama/ollama
```

### Step 2: Start Backend (in terminal 1)
```bash
cd /home/akash/Projects/ticket-ai
mvn clean compile -s /tmp/mvn-settings.xml
mvn spring-boot:run -s /tmp/mvn-settings.xml
```

Wait for this message:
```
Started TicketAiApplication in X.XXX seconds
```

### Step 3: Start Frontend (in terminal 2)
```bash
cd /home/akash/Projects/ticket-ai/frontend
npm install  # (if first time)
npm start
```

Browser will open to http://localhost:3000

## Verify Everything Works

### Test 1: Backend is running
```bash
curl http://localhost:8080/api/tickets
# Should return: {"content":[],"totalElements":0,...}
```

### Test 2: Frontend can reach backend
In browser DevTools (F12):
1. Open **Console** tab
2. Should NOT show errors like "Failed to fetch"
3. Network tab should show successful request to `/api/tickets`

### Test 3: Create a ticket
1. Click **✨ Create Ticket**
2. Fill form:
   - Title: "Test"
   - Description: "Test ticket"
   - Priority: HIGH
   - Category: Test
3. Click **Create Ticket**
4. Should see it in list (if error is gone)

## If Still Not Working

### Check 1: Is backend actually running?
```bash
# This should NOT say "Connection refused"
curl http://localhost:8080/api/tickets

# If connection refused, backend is NOT running
# Go back to Step 2 above
```

### Check 2: Is frontend pointing to right URL?
```bash
cat /home/akash/Projects/ticket-ai/frontend/.env
# Should show: REACT_APP_API_URL=http://localhost:8080/api
```

If wrong, fix it:
```bash
# Edit .env
echo 'REACT_APP_API_URL=http://localhost:8080/api' > /home/akash/Projects/ticket-ai/frontend/.env

# Restart frontend (kill npm, re-run npm start)
```

### Check 3: Hard refresh browser
```
Ctrl+Shift+R  (Windows/Linux)
Cmd+Shift+R   (Mac)
```

Or clear cache:
1. DevTools → Application tab
2. Storage → Clear Site Data
3. Refresh page

### Check 4: Port conflicts
```bash
# Check if ports are in use
lsof -i :8080  # Should be Java process
lsof -i :3000  # Should be Node process
lsof -i :11434 # Should be Docker/Ollama

# If stuck, kill old processes
pkill -f "spring-boot:run"
pkill -f "node"
```

## Correct Flow

```
Ollama ← running on :11434
  ↑
Backend ← running on :8080, connects to Ollama
  ↑
Frontend ← running on :3000, connects to Backend
  ↑
Browser ← http://localhost:3000
```

## Common Mistakes

❌ **Backend not running** (most common)
- Solution: Run `mvn spring-boot:run`

❌ **Frontend .env wrong**
- Solution: Should be `http://localhost:8080/api`

❌ **CORS not configured**
- Solution: CorsConfig.java added (already in code)

❌ **Frontend not restarted after .env change**
- Solution: Kill npm, run `npm start` again

❌ **Port already in use**
- Solution: Kill old process or use different port

❌ **Browser cached old version**
- Solution: Hard refresh (`Ctrl+Shift+R`)

## Still Stuck?

1. **Check backend logs** for errors
2. **Check browser DevTools** → Network tab
   - Look for failed request to `/api/tickets`
   - Check response (should be JSON, not HTML error)
3. **Test with curl**:
   ```bash
   curl -v http://localhost:8080/api/tickets
   ```
4. **Restart everything**:
   ```bash
   # Kill all
   pkill -f spring
   pkill -f node
   
   # Restart backend
   mvn spring-boot:run -s /tmp/mvn-settings.xml
   
   # Restart frontend (new terminal)
   npm start
   ```

---

**If backend is running and frontend has correct .env, error should be GONE.** 🎯
