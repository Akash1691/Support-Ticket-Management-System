package support_ticket_ai.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.exception.InvalidStateTransitionException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for StateMachine.
 */
@DisplayName("StateMachine Tests")
class StateMachineTests {

    @Test
    @DisplayName("should_allow_OPEN_to_IN_PROGRESS")
    void shouldAllowOpenToInProgress() {
        assertDoesNotThrow(() -> StateMachine.validateTransition(TicketStatus.OPEN, TicketStatus.IN_PROGRESS));
    }

    @Test
    @DisplayName("should_allow_OPEN_to_CANCELLED")
    void shouldAllowOpenToCancelled() {
        assertDoesNotThrow(() -> StateMachine.validateTransition(TicketStatus.OPEN, TicketStatus.CANCELLED));
    }

    @Test
    @DisplayName("should_allow_IN_PROGRESS_to_RESOLVED")
    void shouldAllowInProgressToResolved() {
        assertDoesNotThrow(() -> StateMachine.validateTransition(TicketStatus.IN_PROGRESS, TicketStatus.RESOLVED));
    }

    @Test
    @DisplayName("should_allow_IN_PROGRESS_to_CANCELLED")
    void shouldAllowInProgressToCancelled() {
        assertDoesNotThrow(() -> StateMachine.validateTransition(TicketStatus.IN_PROGRESS, TicketStatus.CANCELLED));
    }

    @Test
    @DisplayName("should_allow_RESOLVED_to_CLOSED")
    void shouldAllowResolvedToClosed() {
        assertDoesNotThrow(() -> StateMachine.validateTransition(TicketStatus.RESOLVED, TicketStatus.CLOSED));
    }

    @Test
    @DisplayName("should_reject_CLOSED_to_OPEN")
    void shouldRejectClosedToOpen() {
        assertThrows(InvalidStateTransitionException.class,
            () -> StateMachine.validateTransition(TicketStatus.CLOSED, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_reject_CANCELLED_to_OPEN")
    void shouldRejectCancelledToOpen() {
        assertThrows(InvalidStateTransitionException.class,
            () -> StateMachine.validateTransition(TicketStatus.CANCELLED, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_reject_RESOLVED_to_OPEN")
    void shouldRejectResolvedToOpen() {
        assertThrows(InvalidStateTransitionException.class,
            () -> StateMachine.validateTransition(TicketStatus.RESOLVED, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_reject_IN_PROGRESS_to_OPEN")
    void shouldRejectInProgressToOpen() {
        assertThrows(InvalidStateTransitionException.class,
            () -> StateMachine.validateTransition(TicketStatus.IN_PROGRESS, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_reject_same_status_transition")
    void shouldRejectSameStatusTransition() {
        assertThrows(InvalidStateTransitionException.class,
            () -> StateMachine.validateTransition(TicketStatus.OPEN, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_return_true_for_valid_transition")
    void shouldReturnTrueForValidTransition() {
        assertTrue(StateMachine.isValidTransition(TicketStatus.OPEN, TicketStatus.IN_PROGRESS));
    }

    @Test
    @DisplayName("should_return_false_for_invalid_transition")
    void shouldReturnFalseForInvalidTransition() {
        assertFalse(StateMachine.isValidTransition(TicketStatus.CLOSED, TicketStatus.OPEN));
    }
}
