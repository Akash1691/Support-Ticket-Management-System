package support_ticket_ai.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import support_ticket_ai.dto.TicketRequest;
import support_ticket_ai.entity.Priority;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.exception.TicketNotFoundException;
import support_ticket_ai.repository.TicketRepository;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for TicketService.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("TicketService Tests")
class TicketServiceTests {

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private org.springframework.context.ApplicationEventPublisher eventPublisher;

    @InjectMocks
    private TicketService ticketService;

    private Ticket sampleTicket;
    private TicketRequest ticketRequest;

    @BeforeEach
    void setUp() {
        sampleTicket = Ticket.builder()
            .id(1L)
            .title("Test Ticket")
            .description("Test Description")
            .status(TicketStatus.OPEN)
            .priority(Priority.HIGH)
            .build();

        ticketRequest = TicketRequest.builder()
            .title("Test Ticket")
            .description("Test Description")
            .priority(Priority.HIGH)
            .category("Test")
            .build();
    }

    @Test
    @DisplayName("should_create_ticket_successfully")
    void shouldCreateTicketSuccessfully() {
        when(ticketRepository.save(any(Ticket.class))).thenReturn(sampleTicket);

        Ticket result = ticketService.createTicket(ticketRequest);

        assertNotNull(result);
        assertEquals("Test Ticket", result.getTitle());
        assertEquals(TicketStatus.OPEN, result.getStatus());
        verify(ticketRepository, times(1)).save(any(Ticket.class));
    }

    @Test
    @DisplayName("should_get_ticket_by_id_successfully")
    void shouldGetTicketByIdSuccessfully() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));

        Ticket result = ticketService.getTicketById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Test Ticket", result.getTitle());
    }

    @Test
    @DisplayName("should_throw_TicketNotFoundException_when_ticket_not_found")
    void shouldThrowNotFoundWhenTicketNotFound() {
        when(ticketRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(TicketNotFoundException.class, () -> ticketService.getTicketById(999L));
    }

    @Test
    @DisplayName("should_list_tickets_with_pagination")
    void shouldListTicketsWithPagination() {
        Pageable pageable = PageRequest.of(0, 10);
        PageImpl<Ticket> page = new PageImpl<>(List.of(sampleTicket), pageable, 1);
        when(ticketRepository.findAll(pageable)).thenReturn(page);

        var result = ticketService.listTickets(pageable);

        assertEquals(1, result.getTotalElements());
        assertEquals(1, result.getContent().size());
    }

    @Test
    @DisplayName("should_search_tickets_by_keyword")
    void shouldSearchTicketsByKeyword() {
        Pageable pageable = PageRequest.of(0, 10);
        PageImpl<Ticket> page = new PageImpl<>(List.of(sampleTicket), pageable, 1);
        when(ticketRepository.searchByKeyword("test", pageable)).thenReturn(page);

        var result = ticketService.searchByKeyword("test", pageable);

        assertEquals(1, result.getTotalElements());
    }

    @Test
    @DisplayName("should_filter_tickets_by_status")
    void shouldFilterTicketsByStatus() {
        Pageable pageable = PageRequest.of(0, 10);
        PageImpl<Ticket> page = new PageImpl<>(List.of(sampleTicket), pageable, 1);
        when(ticketRepository.findByStatus(TicketStatus.OPEN, pageable)).thenReturn(page);

        var result = ticketService.filterByStatus(TicketStatus.OPEN, pageable);

        assertEquals(1, result.getTotalElements());
    }

    @Test
    @DisplayName("should_update_ticket_successfully")
    void shouldUpdateTicketSuccessfully() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));
        when(ticketRepository.save(any(Ticket.class))).thenReturn(sampleTicket);

        TicketRequest updateRequest = TicketRequest.builder()
            .title("Updated Title")
            .priority(Priority.CRITICAL)
            .build();

        Ticket result = ticketService.updateTicket(1L, updateRequest);

        assertNotNull(result);
        verify(ticketRepository, times(1)).save(any(Ticket.class));
    }

    @Test
    @DisplayName("should_change_status_successfully")
    void shouldChangeStatusSuccessfully() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));
        when(ticketRepository.save(any(Ticket.class))).thenReturn(sampleTicket);

        Ticket result = ticketService.changeStatus(1L, TicketStatus.IN_PROGRESS);

        assertNotNull(result);
        verify(ticketRepository, times(1)).save(any(Ticket.class));
    }

    @Test
    @DisplayName("should_throw_exception_on_invalid_status_transition")
    void shouldThrowExceptionOnInvalidStatusTransition() {
        sampleTicket.setStatus(TicketStatus.CLOSED);
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));

        assertThrows(Exception.class, () -> ticketService.changeStatus(1L, TicketStatus.OPEN));
    }

    @Test
    @DisplayName("should_delete_ticket_successfully")
    void shouldDeleteTicketSuccessfully() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));

        ticketService.deleteTicket(1L);

        verify(ticketRepository, times(1)).delete(sampleTicket);
    }
}
