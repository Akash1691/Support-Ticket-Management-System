package support_ticket_ai.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import support_ticket_ai.dto.CommentRequest;
import support_ticket_ai.entity.Comment;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.exception.TicketNotFoundException;
import support_ticket_ai.repository.CommentRepository;
import support_ticket_ai.repository.TicketRepository;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CommentService.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("CommentService Tests")
class CommentServiceTests {

    @Mock
    private CommentRepository commentRepository;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private org.springframework.context.ApplicationEventPublisher eventPublisher;

    @InjectMocks
    private CommentService commentService;

    private Ticket sampleTicket;
    private Comment sampleComment;
    private CommentRequest commentRequest;

    @BeforeEach
    void setUp() {
        sampleTicket = Ticket.builder()
            .id(1L)
            .title("Test Ticket")
            .status(TicketStatus.OPEN)
            .build();

        sampleComment = Comment.builder()
            .id(1L)
            .ticket(sampleTicket)
            .text("Test Comment")
            .author("test@example.com")
            .build();

        commentRequest = CommentRequest.builder()
            .text("Test Comment")
            .author("test@example.com")
            .build();
    }

    @Test
    @DisplayName("should_add_comment_successfully")
    void shouldAddCommentSuccessfully() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));
        when(commentRepository.save(any(Comment.class))).thenReturn(sampleComment);

        Comment result = commentService.addComment(1L, commentRequest);

        assertNotNull(result);
        assertEquals("Test Comment", result.getText());
        assertEquals("test@example.com", result.getAuthor());
        verify(commentRepository, times(1)).save(any(Comment.class));
    }

    @Test
    @DisplayName("should_throw_TicketNotFoundException_when_ticket_not_found")
    void shouldThrowNotFoundWhenTicketNotFound() {
        when(ticketRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(TicketNotFoundException.class,
            () -> commentService.addComment(999L, commentRequest));
    }

    @Test
    @DisplayName("should_get_comments_by_ticket")
    void shouldGetCommentsByTicket() {
        when(ticketRepository.existsById(1L)).thenReturn(true);
        when(commentRepository.findByTicketIdOrderByCreatedAtAsc(1L))
            .thenReturn(List.of(sampleComment));

        List<Comment> result = commentService.getCommentsByTicket(1L);

        assertEquals(1, result.size());
        assertEquals("Test Comment", result.get(0).getText());
    }

    @Test
    @DisplayName("should_throw_exception_when_ticket_not_found_on_get_comments")
    void shouldThrowExceptionWhenTicketNotFoundOnGetComments() {
        when(ticketRepository.existsById(999L)).thenReturn(false);

        assertThrows(TicketNotFoundException.class,
            () -> commentService.getCommentsByTicket(999L));
    }

    @Test
    @DisplayName("should_delete_comment_successfully")
    void shouldDeleteCommentSuccessfully() {
        when(commentRepository.findById(1L)).thenReturn(Optional.of(sampleComment));

        commentService.deleteComment(1L);

        verify(commentRepository, times(1)).delete(sampleComment);
    }
}
