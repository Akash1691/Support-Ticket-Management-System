package support_ticket_ai;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Skip integration test for Phase 2; full app context tested in Phase 6")
class TicketAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
