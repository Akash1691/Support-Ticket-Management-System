package support_ticket_ai.rag;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.document.Document;
import support_ticket_ai.dto.AskResponse;
import support_ticket_ai.dto.SentimentResponse;
import support_ticket_ai.entity.TicketStatus;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class AiServiceTests {

    @Test
    void explainsHowToCreateTicketWhenRagHasNoMatchingHistory() {
        RetrievalService retrievalService = mock(RetrievalService.class);
        ChatModel chatModel = mock(ChatModel.class);
        String question = "How I can log a ticket for any issue in this system?";

        AskResponse response = new AiService(retrievalService, chatModel).ask(question, 5, 0.7);

        assertFalse(response.isNoMatch());
        assertEquals(
            """
            To log a ticket in this application:
            1. Click Back to return to the Support-Ticket-Management-System page.
            2. Click Create Ticket.
            3. Enter a title, description, priority, and category.
            4. Click Create Ticket to submit it.""",
            response.getAnswer()
        );
        verifyNoInteractions(retrievalService);
        verifyNoInteractions(chatModel);
    }

    @Test
    void parsesNumericSentimentConfidenceReturnedByOllama() throws Exception {
        AiService service = new AiService(mock(RetrievalService.class), mock(ChatModel.class));

        SentimentResponse response = service.parseSentimentResponse(
            """
            {"sentiment":"POSITIVE","confidence":0.95,"explanation":"Strong positive language"}
            """
        );

        assertEquals("POSITIVE", response.getSentiment());
        assertEquals(0.95, response.getConfidence());
        assertEquals("Strong positive language", response.getExplanation());
    }

    @Test
    void returnsEveryRetrievedStatusTicketWithoutCallingChatModel() {
        RetrievalService retrievalService = mock(RetrievalService.class);
        ChatModel chatModel = mock(ChatModel.class);
        RetrievalService.RetrievalResult retrieval = new RetrievalService.RetrievalResult(
            List.of(new Document("Ticket TKT-7", Map.of())),
            List.of(7L, 12L, 19L),
            1.0,
            TicketStatus.RESOLVED
        );
        when(retrievalService.search("show resolved tickets", 5, 0.7)).thenReturn(retrieval);

        AskResponse response =
            new AiService(retrievalService, chatModel).ask("show resolved tickets", 5, 0.7);

        assertEquals("Tickets with status RESOLVED: TKT-7, TKT-12, TKT-19", response.getAnswer());
        assertEquals(List.of(7L, 12L, 19L), response.getCitedTickets());
        assertFalse(response.isNoMatch());
        verifyNoInteractions(chatModel);
    }
}
