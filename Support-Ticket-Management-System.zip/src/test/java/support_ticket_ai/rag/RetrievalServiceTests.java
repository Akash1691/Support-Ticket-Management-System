package support_ticket_ai.rag;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.repository.TicketRepository;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RetrievalServiceTests {

    @Mock
    private VectorStore vectorStore;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private TicketChunkizer ticketChunkizer;

    @Test
    void retrievesAllTicketsForExactStatusInIdOrder() {
        Ticket first = Ticket.builder().id(7L).status(TicketStatus.RESOLVED).build();
        Ticket second = Ticket.builder().id(12L).status(TicketStatus.RESOLVED).build();
        when(ticketRepository.findAllByStatusOrderByIdAsc(TicketStatus.RESOLVED))
            .thenReturn(List.of(first, second));
        when(ticketChunkizer.chunkify(first))
            .thenReturn(List.of(new Document("ticket-7", "Ticket TKT-7", Map.of())));
        when(ticketChunkizer.chunkify(second))
            .thenReturn(List.of(new Document("ticket-12", "Ticket TKT-12", Map.of())));

        RetrievalService service = new RetrievalService(vectorStore, ticketRepository, ticketChunkizer);
        RetrievalService.RetrievalResult result =
            service.search("show all resolved tickets", 5, 0.7);

        assertEquals(List.of(7L, 12L), result.citedTicketIds);
        assertEquals(TicketStatus.RESOLVED, result.exactStatus);
        assertEquals(1.0, result.relevanceScore);
        verify(vectorStore, never())
            .similaritySearch(org.mockito.ArgumentMatchers.any(SearchRequest.class));
    }
}
