package support_ticket_ai.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO for sentiment analysis.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SentimentResponse {
    
    private String text;
    
    /**
     * Sentiment label: POSITIVE, NEGATIVE, NEUTRAL
     */
    private String sentiment;
    
    /**
     * Confidence score (0.0 - 1.0)
     */
    private Double confidence;
    
    /**
     * Detailed explanation
     */
    private String explanation;
}
