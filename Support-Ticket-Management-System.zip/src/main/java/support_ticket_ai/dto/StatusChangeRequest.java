package support_ticket_ai.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import support_ticket_ai.entity.TicketStatus;

/**
 * Request DTO for changing ticket status.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StatusChangeRequest {

    @NotNull(message = "New status is required")
    private TicketStatus newStatus;
}
