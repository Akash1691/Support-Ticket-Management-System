package support_ticket_ai.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for text summarization.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SummarizeRequest {
    
    @NotBlank(message = "Text is required")
    private String text;
    
    /**
     * Max length of summary (default: auto)
     */
    private Integer maxLength;
}
