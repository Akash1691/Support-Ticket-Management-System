package support_ticket_ai.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import support_ticket_ai.entity.Priority;

/**
 * Request DTO for creating a new ticket.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TicketRequest {

    @NotBlank(message = "Title is required")
    private String title;

    private String description;

    @Builder.Default
    private Priority priority = Priority.MEDIUM;

    private String category;
}
