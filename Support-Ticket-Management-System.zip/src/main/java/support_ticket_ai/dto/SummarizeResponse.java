package support_ticket_ai.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO for text summarization.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SummarizeResponse {
    
    private String originalText;
    
    private String summary;
    
    /**
     * Compression ratio (original_length / summary_length)
     */
    private Double compressionRatio;
}
