package support_ticket_ai.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import support_ticket_ai.entity.Comment;

import java.time.LocalDateTime;

/**
 * Response DTO for a comment.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CommentResponse {

    private Long id;
    private Long ticketId;
    private String text;
    private String author;
    private LocalDateTime createdAt;

    public static CommentResponse from(Comment comment) {
        return CommentResponse.builder()
            .id(comment.getId())
            .ticketId(comment.getTicket().getId())
            .text(comment.getText())
            .author(comment.getAuthor())
            .createdAt(comment.getCreatedAt())
            .build();
    }
}
