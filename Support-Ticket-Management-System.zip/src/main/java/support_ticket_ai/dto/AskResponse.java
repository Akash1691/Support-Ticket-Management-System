package support_ticket_ai.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for question-answering endpoint.
 * Contains grounded answer + cited tickets or "no match" indicator.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AskResponse {

    private String question;

    /**
     * Generated answer (null if no match).
     */
    private String answer;

    /**
     * Ticket IDs cited in the answer.
     */
    @Builder.Default
    private List<Long> citedTickets = List.of();

    /**
     * Relevance score (average cosine similarity of retrieved chunks).
     */
    private double relevanceScore;

    /**
     * True if no relevant tickets found (threshold not met).
     */
    @Builder.Default
    private boolean noMatch = false;

    /**
     * Reason for no match (e.g., "No relevant tickets found").
     */
    private String reason;
}
