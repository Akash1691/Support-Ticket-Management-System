package support_ticket_ai.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for sentiment analysis.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SentimentRequest {
    
    @NotBlank(message = "Text is required")
    private String text;
}
