package support_ticket_ai.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for asking a question over ticket history.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AskRequest {

    @NotBlank(message = "Question is required")
    private String question;

    @Builder.Default
    private int topK = 5;

    @Builder.Default
    private double similarityThreshold = 0.7;
}
