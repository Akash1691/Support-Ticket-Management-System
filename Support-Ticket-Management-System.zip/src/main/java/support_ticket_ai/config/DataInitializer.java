package support_ticket_ai.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import support_ticket_ai.entity.Comment;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.entity.Priority;
import support_ticket_ai.event.CommentAddedEvent;
import support_ticket_ai.event.TicketCreatedEvent;
import support_ticket_ai.repository.TicketRepository;
import support_ticket_ai.repository.CommentRepository;
import support_ticket_ai.rag.TicketIngestionService;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final TicketRepository ticketRepository;
    private final CommentRepository commentRepository;
    private final ApplicationEventPublisher eventPublisher;
    private final TicketIngestionService ticketIngestionService;

    @Override
    public void run(String... args) throws Exception {
        if (ticketRepository.count() > 0) {
            log.info("Database already contains data. Skipping initialization.");
            // Still ingest any missing tickets (in case embeddings were cleared but DB wasn't)
            log.info("Ensuring all tickets are ingested in vector store...");
            ingestAllTickets();
            return;
        }

        log.info("Initializing test data...");
        createTestTickets();
        createInProgressTickets();
        createClosedTickets();
        createCancelledTickets();
        createSentimentTickets();
        
        // Explicitly ingest all tickets into vector store for RAG
        log.info("Ingesting all tickets into vector store...");
        ingestAllTickets();
        
        log.info("Test data initialization complete!");
    }
    
    /**
     * Ingest all existing tickets into the vector store.
     * This ensures embeddings are created for RAG searches.
     */
    private void ingestAllTickets() {
        var allTickets = ticketRepository.findAll();
        log.info("Ingesting {} tickets into vector store...", allTickets.size());
        for (Ticket ticket : allTickets) {
            try {
                ticketIngestionService.ingestTicket(ticket.getId());
            } catch (Exception e) {
                log.warn("Failed to ingest ticket {}: {}", ticket.getId(), e.getMessage());
            }
        }
        log.info("Ingestion complete!");
    }

    private Ticket saveTicket(String title, String description, String priority, String category, TicketStatus status) {
        Ticket ticket = Ticket.builder()
                .title(title)
                .description(description)
                .priority(Priority.valueOf(priority))
                .category(category)
                .status(status)
                .build();
        Ticket saved = ticketRepository.save(ticket);
        eventPublisher.publishEvent(new TicketCreatedEvent(this, saved.getId()));
        return saved;
    }

    private void createTestTickets() {
        log.info("Creating 20 OPEN tickets...");
        String[][] data = {
            {"Payment gateway timeout error", "Customers unable to process payments due to gateway timeout errors", "CRITICAL", "Bug"},
            {"Login fails on Safari", "User login functionality not working on Safari browser", "HIGH", "Bug"},
            {"Mobile app crashes on upload", "App crashes when uploading files larger than 100MB", "HIGH", "Bug"},
            {"Database connection drops", "Database connection failing randomly, affecting API availability", "CRITICAL", "Infrastructure"},
            {"Search returns wrong results", "Search feature showing deleted items and incorrect results", "MEDIUM", "Bug"},
            {"Password reset email not received", "Users not receiving password reset emails, unable to recover accounts", "HIGH", "Account"},
            {"CSV export corrupted", "Exported CSV files are corrupted and fail to open in Excel", "MEDIUM", "Feature"},
            {"Dashboard slow for large datasets", "Dashboard loading takes 30+ seconds for accounts with 100K+ records", "MEDIUM", "Performance"},
            {"Two-factor auth setup confusing", "Users abandoning 2FA setup due to poor UX and unclear documentation", "LOW", "UX"},
            {"Duplicate charges on peak hours", "Customers being charged multiple times during peak traffic hours", "CRITICAL", "Billing"},
            {"Data loss in edits", "User edits being lost randomly, customers losing hours of work", "CRITICAL", "Data"},
            {"Email notifications unreliable", "Some notifications delayed hours, users receiving duplicates", "MEDIUM", "Email"},
            {"Feature request: Dark mode", "Users requesting dark mode theme for the application", "LOW", "Feature"},
            {"API documentation needed", "Users requesting comprehensive API docs and webhook support", "MEDIUM", "Feature"},
            {"Refund not processed", "Refund requested 2 weeks ago but not yet processed to customer", "HIGH", "Billing"},
            {"Multi-currency rates wrong", "Exchange rates not updating, customers seeing incorrect prices", "HIGH", "Billing"},
            {"Account deletion not working", "Users request account deletion but data persists in backups", "CRITICAL", "Privacy"},
            {"Bulk import feature needed", "Users need ability to bulk import data from CSV or Excel files", "MEDIUM", "Feature"},
            {"Real-time collaboration support", "Request for real-time collaboration features like Google Docs", "LOW", "Feature"},
            {"Offline sync broken", "Mobile app changes made offline not syncing when connection restored", "MEDIUM", "Bug"}
        };
        for (String[] row : data) {
            saveTicket(row[0], row[1], row[2], row[3], TicketStatus.OPEN);
        }
    }

    private void createInProgressTickets() {
        log.info("Creating IN_PROGRESS tickets...");
        String[][] data = {
            {"API integration failing for third-party apps", "OAuth token exchange failing for Slack and GitHub integrations after recent auth update", "HIGH", "Bug"},
            {"Performance degradation on search", "Full-text search queries taking 10x longer since last deployment, investigating index issues", "HIGH", "Performance"},
            {"User role permissions not inherited", "Child accounts not inheriting parent org permissions correctly after role refactor", "MEDIUM", "Bug"},
            {"SSO login loop on enterprise accounts", "Enterprise users get redirect loop when logging in via SAML SSO provider", "CRITICAL", "Bug"},
            {"Scheduled reports not triggering", "Cron-based report delivery stopped working after timezone config change", "MEDIUM", "Feature"},
            {"Webhook delivery failures", "Webhooks failing silently for customers using TLS 1.0, need graceful error handling", "HIGH", "Infrastructure"},
            {"Mobile push notifications delayed", "iOS push notifications delayed by 15-30 mins, Android unaffected", "MEDIUM", "Bug"},
        };
        for (String[] row : data) {
            saveTicket(row[0], row[1], row[2], row[3], TicketStatus.IN_PROGRESS);
        }
    }

    private void createClosedTickets() {
        log.info("Creating CLOSED tickets...");
        String[][] data = {
            {"Legacy API v1 deprecation", "Migrated all internal consumers off v1 endpoints. External partners notified. Monitoring complete.", "LOW", "Infrastructure"},
            {"GDPR data export feature", "Implemented full data export per user request. Verified compliance with legal team. Deployed to prod.", "HIGH", "Privacy"},
            {"Onboarding flow redesign", "New onboarding wizard shipped. Drop-off rate reduced by 40%. A/B test concluded successfully.", "MEDIUM", "UX"},
            {"Rate limiting on public API", "Token bucket rate limiter deployed. Abuse pattern stopped. No customer escalations in 30 days.", "HIGH", "Infrastructure"},
            {"Billing cycle proration bug", "Fixed proration calculation on mid-cycle plan upgrades. Retroactive credits issued to affected accounts.", "HIGH", "Billing"},
        };
        for (String[] row : data) {
            saveTicket(row[0], row[1], row[2], row[3], TicketStatus.CLOSED);
        }
    }

    private void createCancelledTickets() {
        log.info("Creating CANCELLED tickets...");
        String[][] data = {
            {"Custom theme builder feature", "Feature request deprioritized after roadmap review. Similar functionality covered by existing CSS overrides.", "LOW", "Feature"},
            {"SMS two-factor authentication", "Cancelled in favor of TOTP-based 2FA. SMS 2FA deemed insecure per security team recommendation.", "MEDIUM", "Security"},
            {"Desktop app for Windows", "Cancelled — usage data shows <2% of users on desktop clients. Investing in PWA instead.", "LOW", "Feature"},
            {"Migrate to MySQL", "Database migration cancelled after benchmarks showed no performance benefit over current Postgres setup.", "HIGH", "Infrastructure"},
        };
        for (String[] row : data) {
            saveTicket(row[0], row[1], row[2], row[3], TicketStatus.CANCELLED);
        }
    }

    private void createSentimentTickets() {
        log.info("Creating 20 RESOLVED tickets with sentiment feedback...");

        createSentimentTicket("Login issue resolved", "User was unable to login",
            "Amazing! The support team fixed my login issue in minutes. Absolutely fantastic service and very professional staff. I'm extremely happy with how quickly this was resolved. Best support experience ever!");
        createSentimentTicket("Payment processing fixed", "Customer unable to complete purchase",
            "Excellent! You guys fixed the payment issue perfectly. The solution was exactly what I needed. Outstanding work! Very impressed with the quality of support. Thank you so much!");
        createSentimentTicket("Mobile app crashes resolved", "App crashing on iPhone",
            "Perfect fix! The app works beautifully now. I love the new update. Everything runs smoothly without any crashes. Incredible work by the development team. Highly recommend!");
        createSentimentTicket("Dashboard performance improved", "Dashboard loading slowly",
            "Wonderful improvement! Dashboard is now lightning fast. The performance boost is amazing. Exceeded all my expectations. Great job on optimizing the system. Very satisfied!");
        createSentimentTicket("Email notifications working", "Not receiving email notifications",
            "Fantastic! All my notifications are coming through perfectly now. The fix was exactly what I needed. Outstanding support team. Really appreciate the quick response. Excellent service!");
        createSentimentTicket("Export feature bug reported", "CSV export generating corrupted files",
            "This is absolutely terrible! The exported file is still broken and useless. I've wasted so much time on this issue. The support was unhelpful and dismissive. Very disappointed with the quality. This is unacceptable!");
        createSentimentTicket("Account access issue", "Cannot access account after password change",
            "Horrible experience! I'm locked out of my account and nobody is helping. The support team ignored my emails for days. This is the worst customer service I've ever experienced. Completely frustrated!");
        createSentimentTicket("Data loss incident", "User lost important data",
            "This is a disaster! I lost all my important work and nobody can help me recover it. The system is completely unreliable. I'm switching to a competitor immediately. Total waste of money!");
        createSentimentTicket("Refund not processed", "Refund requested but not received",
            "Unacceptable! I requested a refund two weeks ago and still nothing. The support team is useless and unhelpful. Very angry about this situation. Worst company ever!");
        createSentimentTicket("Security concern not addressed", "Potential security vulnerability reported",
            "Terrible handling of security issue! My data might be compromised and you don't seem to care. Very disappointed and concerned. This is unacceptable for a company handling sensitive data!");
        createSentimentTicket("Feature parity request", "Feature available on web but not mobile",
            "The issue was fixed. The mobile app now has the same features as the web version. The resolution was standard and expected. Works as it should now. Nothing special but gets the job done.");
        createSentimentTicket("Database sync issue", "Data not syncing between devices",
            "The sync issue is now resolved. Data synchronizes between devices. The fix was implemented as described. Functionality is back to normal. Average resolution time for this type of issue.");
        createSentimentTicket("API rate limiting question", "User asking about API rate limits",
            "The support team provided information about API rate limits. The answer was clear and direct. It addresses the question adequately. Standard technical documentation provided. Acceptable response.");
        createSentimentTicket("Configuration help", "User needs help configuring settings",
            "The configuration steps were provided and it works. The instructions were standard and straightforward. Configuration is complete. Typical support interaction. No issues.");
        createSentimentTicket("Documentation request", "User asking for more documentation",
            "Additional documentation has been provided. The docs are comprehensive and cover the main points. Contains the basic information needed. Standard documentation level. Adequate response.");
        createSentimentTicket("Partially resolved issue", "Complex issue with multiple aspects",
            "Good news: most of the issues were fixed and the system is much better now. However, there are still some small problems remaining. The main functionality works great but some edge cases aren't handled well yet. Overall satisfied but not perfect.");
        createSentimentTicket("Feature with limitations", "New feature implementation",
            "I love the new feature and it solves my main problem. However, it's quite limited compared to competitors. Great that you added it but it could be much more powerful. Good start but needs more work.");
        createSentimentTicket("Slow but working fix", "Performance issue resolved",
            "The issue is fixed and everything works now. However, the resolution took much longer than expected. Good technical solution but poor communication during the process. Satisfied with the result but disappointed with the timeline.");
        createSentimentTicket("Workaround provided", "Temporary solution needed",
            "The workaround works but it's inconvenient. Appreciate that you found a solution quickly but a proper fix would be better. This is acceptable for now but needs a permanent solution eventually.");
        createSentimentTicket("Updated with conditions", "Solution with dependencies",
            "Excellent solution for the core issue. Very happy with the technical implementation. Unfortunately, it requires upgrading to a newer version which breaks some other features for us. Mostly satisfied with the fix but not ideal for our setup.");
    }

    private void createSentimentTicket(String title, String description, String feedback) {
        Ticket saved = saveTicket(title, description, "MEDIUM", "Support", TicketStatus.RESOLVED);

        Comment comment = Comment.builder()
                .ticket(saved)
                .text(feedback)
                .author("Customer")
                .build();
        Comment savedComment = commentRepository.save(comment);
        eventPublisher.publishEvent(new CommentAddedEvent(this, saved.getId(), savedComment.getId()));
    }
}
