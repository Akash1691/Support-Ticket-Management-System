package support_ticket_ai.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import lombok.Getter;
import lombok.Setter;

/**
 * Configuration for Ollama + VectorStore.
 * Ollama models are auto-configured via Spring AI based on properties:
 *   spring.ai.ollama.base-url
 *   spring.ai.ollama.chat.model
 *   spring.ai.ollama.embedding.model
 *
 * VectorStore: auto-configured as SimpleVectorStore by Spring AI.
 * 
 * RAG retrieval parameters:
 *   rag.retrieval.topK (default: 5)
 *   rag.retrieval.similarityThreshold (default: 0.7)
 */
@Configuration
@EnableConfigurationProperties(OllamaConfig.OllamaProperties.class)
public class OllamaConfig {

    @Bean
    public VectorStore vectorStore(EmbeddingModel embeddingModel) {
        return SimpleVectorStore.builder(embeddingModel).build();
    }

    @ConfigurationProperties(prefix = "spring.ai.ollama")
    @Getter
    @Setter
    public static class OllamaProperties {
        private String baseUrl = "http://localhost:11434";
        private Chat chat = new Chat();
        private Embedding embedding = new Embedding();

        @Getter
        @Setter
        public static class Chat {
            private String model = "mistral";
        }

        @Getter
        @Setter
        public static class Embedding {
            private String model = "nomic-embed-text";
        }
    }
}
