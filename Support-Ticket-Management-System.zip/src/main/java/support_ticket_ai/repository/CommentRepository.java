package support_ticket_ai.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import support_ticket_ai.entity.Comment;

import java.util.List;

/**
 * Repository for Comment entity.
 * Provides CRUD and query methods.
 */
@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

    /**
     * Find all comments for a ticket, ordered by creation date.
     */
    List<Comment> findByTicketIdOrderByCreatedAtAsc(Long ticketId);
}
