package support_ticket_ai.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import support_ticket_ai.entity.TicketEmbeddingMetadata;

import java.util.List;

/**
 * Repository for TicketEmbeddingMetadata entity.
 * Tracks embeddings stored in vector store.
 */
@Repository
public interface TicketEmbeddingMetadataRepository extends JpaRepository<TicketEmbeddingMetadata, Long> {

    /**
     * Find all embedding metadata for a ticket.
     */
    List<TicketEmbeddingMetadata> findByTicketId(Long ticketId);

    /**
     * Delete all embedding metadata for a ticket.
     */
    void deleteByTicketId(Long ticketId);
}
