package support_ticket_ai.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import support_ticket_ai.entity.Priority;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;

import java.util.List;

/**
 * Repository for Ticket entity.
 * Provides CRUD and custom query methods.
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    /**
     * Find tickets by status.
     */
    Page<Ticket> findByStatus(TicketStatus status, Pageable pageable);

    /**
     * Retrieve every ticket for an exact status query in stable ID order.
     */
    List<Ticket> findAllByStatusOrderByIdAsc(TicketStatus status);

    /**
     * Find tickets by priority.
     */
    Page<Ticket> findByPriority(Priority priority, Pageable pageable);

    /**
     * Find tickets by assignee.
     */
    Page<Ticket> findByAssignee(String assignee, Pageable pageable);

    /**
     * Find tickets by category.
     */
    Page<Ticket> findByCategory(String category, Pageable pageable);

    /**
     * Search tickets by title or description keyword (case-insensitive).
     */
    @Query("""
        SELECT t FROM Ticket t
        WHERE LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%'))
           OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%'))
        ORDER BY t.updatedAt DESC
        """)
    Page<Ticket> searchByKeyword(String keyword, Pageable pageable);

    /**
     * Search tickets by status and keyword.
     */
    @Query("""
        SELECT t FROM Ticket t
        WHERE t.status = :status
          AND (LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%'))
               OR LOWER(t.description) LIKE LOWER(CONCAT('%', :keyword, '%')))
        ORDER BY t.updatedAt DESC
        """)
    Page<Ticket> searchByStatusAndKeyword(TicketStatus status, String keyword, Pageable pageable);
}
