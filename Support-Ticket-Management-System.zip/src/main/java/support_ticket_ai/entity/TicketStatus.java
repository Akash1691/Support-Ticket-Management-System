package support_ticket_ai.entity;

/**
 * Ticket status enum for state machine.
 * Valid transitions enforced in TicketService.
 */
public enum TicketStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED,
    CANCELLED
}
