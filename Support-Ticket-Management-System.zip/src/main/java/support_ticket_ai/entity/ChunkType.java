package support_ticket_ai.entity;

/**
 * Types of chunks for ticket embeddings.
 */
public enum ChunkType {
    DESCRIPTION,
    COMMENT,
    RESOLUTION
}
