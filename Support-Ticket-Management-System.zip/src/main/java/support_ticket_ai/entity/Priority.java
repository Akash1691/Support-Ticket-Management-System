package support_ticket_ai.entity;

/**
 * Ticket priority levels.
 */
public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
