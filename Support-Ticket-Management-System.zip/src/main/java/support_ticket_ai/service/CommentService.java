package support_ticket_ai.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import support_ticket_ai.dto.CommentRequest;
import support_ticket_ai.entity.Comment;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.event.CommentAddedEvent;
import support_ticket_ai.exception.TicketNotFoundException;
import support_ticket_ai.repository.CommentRepository;
import support_ticket_ai.repository.TicketRepository;

import java.util.List;

/**
 * Service for comment operations.
 * Handles CRUD for comments on tickets.
 * Publishes events for RAG ingestion.
 */
@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class CommentService {

    private final CommentRepository commentRepository;
    private final TicketRepository ticketRepository;
    private final ApplicationEventPublisher eventPublisher;

    /**
     * Add a comment to a ticket.
     */
    public Comment addComment(Long ticketId, CommentRequest request) {
        Ticket ticket = ticketRepository.findById(ticketId)
            .orElseThrow(() -> new TicketNotFoundException(ticketId));

        Comment comment = Comment.builder()
            .ticket(ticket)
            .text(request.getText())
            .author(request.getAuthor())
            .build();

        Comment saved = commentRepository.save(comment);
        log.info("Comment added: id={}, ticketId={}", saved.getId(), ticketId);
        eventPublisher.publishEvent(new CommentAddedEvent(this, ticketId, saved.getId()));
        return saved;
    }

    /**
     * Get all comments for a ticket.
     */
    @Transactional(readOnly = true)
    public List<Comment> getCommentsByTicket(Long ticketId) {
        // Verify ticket exists
        if (!ticketRepository.existsById(ticketId)) {
            throw new TicketNotFoundException(ticketId);
        }
        return commentRepository.findByTicketIdOrderByCreatedAtAsc(ticketId);
    }

    /**
     * Delete a comment.
     */
    public void deleteComment(Long commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("Comment not found: %d".formatted(commentId)));
        commentRepository.delete(comment);
        log.info("Comment deleted: id={}", commentId);
    }
}
