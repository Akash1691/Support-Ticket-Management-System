package support_ticket_ai.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import support_ticket_ai.dto.TicketRequest;
import support_ticket_ai.entity.Priority;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.event.TicketCreatedEvent;
import support_ticket_ai.event.TicketUpdatedEvent;
import support_ticket_ai.exception.TicketNotFoundException;
import support_ticket_ai.repository.TicketRepository;

/**
 * Service for ticket operations.
 * Handles CRUD, state machine transitions, search, and filtering.
 * Publishes events for RAG ingestion.
 */
@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class TicketService {

    private final TicketRepository ticketRepository;
    private final ApplicationEventPublisher eventPublisher;

    /**
     * Create a new ticket.
     */
    public Ticket createTicket(TicketRequest request) {
        Ticket ticket = Ticket.builder()
            .title(request.getTitle())
            .description(request.getDescription())
            .priority(request.getPriority() != null ? request.getPriority() : Priority.MEDIUM)
            .category(request.getCategory())
            .status(TicketStatus.OPEN)
            .build();

        Ticket saved = ticketRepository.save(ticket);
        log.info("Ticket created: id={}, title={}", saved.getId(), saved.getTitle());
        eventPublisher.publishEvent(new TicketCreatedEvent(this, saved.getId()));
        return saved;
    }

    /**
     * Get ticket by ID.
     */
    @Transactional(readOnly = true)
    public Ticket getTicketById(Long id) {
        return ticketRepository.findById(id)
            .orElseThrow(() -> new TicketNotFoundException(id));
    }

    /**
     * List all tickets with pagination.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> listTickets(Pageable pageable) {
        return ticketRepository.findAll(pageable);
    }

    /**
     * Search tickets by keyword.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> searchByKeyword(String keyword, Pageable pageable) {
        return ticketRepository.searchByKeyword(keyword, pageable);
    }

    /**
     * Filter tickets by status.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> filterByStatus(TicketStatus status, Pageable pageable) {
        return ticketRepository.findByStatus(status, pageable);
    }

    /**
     * Filter tickets by status and search keyword.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> filterByStatusAndKeyword(TicketStatus status, String keyword, Pageable pageable) {
        return ticketRepository.searchByStatusAndKeyword(status, keyword, pageable);
    }

    /**
     * Filter tickets by priority.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> filterByPriority(Priority priority, Pageable pageable) {
        return ticketRepository.findByPriority(priority, pageable);
    }

    /**
     * Filter tickets by assignee.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> filterByAssignee(String assignee, Pageable pageable) {
        return ticketRepository.findByAssignee(assignee, pageable);
    }

    /**
     * Filter tickets by category.
     */
    @Transactional(readOnly = true)
    public Page<Ticket> filterByCategory(String category, Pageable pageable) {
        return ticketRepository.findByCategory(category, pageable);
    }

    /**
     * Update ticket fields (title, description, priority, assignee, category).
     */
    public Ticket updateTicket(Long id, TicketRequest request) {
        Ticket ticket = getTicketById(id);

        if (request.getTitle() != null && !request.getTitle().isBlank()) {
            ticket.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            ticket.setDescription(request.getDescription());
        }
        if (request.getPriority() != null) {
            ticket.setPriority(request.getPriority());
        }
        if (request.getCategory() != null) {
            ticket.setCategory(request.getCategory());
        }

        Ticket updated = ticketRepository.save(ticket);
        log.info("Ticket updated: id={}", id);
        eventPublisher.publishEvent(new TicketUpdatedEvent(this, id));
        return updated;
    }

    /**
     * Update ticket assignee.
     */
    public Ticket updateAssignee(Long id, String assignee) {
        Ticket ticket = getTicketById(id);
        ticket.setAssignee(assignee);
        Ticket updated = ticketRepository.save(ticket);
        log.info("Ticket assignee updated: id={}, assignee={}", id, assignee);
        return updated;
    }

    /**
     * Change ticket status (state machine enforced).
     */
    public Ticket changeStatus(Long id, TicketStatus newStatus) {
        Ticket ticket = getTicketById(id);
        TicketStatus currentStatus = ticket.getStatus();

        // Validate state transition
        StateMachine.validateTransition(currentStatus, newStatus);

        ticket.setStatus(newStatus);
        Ticket updated = ticketRepository.save(ticket);
        log.info("Ticket status changed: id={}, from={}, to={}", id, currentStatus, newStatus);
        eventPublisher.publishEvent(new TicketUpdatedEvent(this, id));
        return updated;
    }

    /**
     * Delete ticket.
     */
    public void deleteTicket(Long id) {
        Ticket ticket = getTicketById(id);
        ticketRepository.delete(ticket);
        log.info("Ticket deleted: id={}", id);
    }
}
