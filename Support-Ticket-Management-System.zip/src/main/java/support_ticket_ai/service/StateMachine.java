package support_ticket_ai.service;

import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.exception.InvalidStateTransitionException;

/**
 * State machine for ticket status transitions.
 * Enforces valid transitions:
 *   OPEN → IN_PROGRESS, CANCELLED
 *   IN_PROGRESS → RESOLVED, CANCELLED
 *   RESOLVED → CLOSED
 *   CLOSED → (terminal, no transitions)
 *   CANCELLED → (terminal, no transitions)
 */
public class StateMachine {

    /**
     * Check if transition from current to next status is valid.
     * @throws InvalidStateTransitionException if transition is invalid
     */
    public static void validateTransition(TicketStatus current, TicketStatus next) {
        if (current == next) {
            throw new InvalidStateTransitionException(
                "Cannot transition to the same status: %s".formatted(current));
        }

        boolean valid = switch (current) {
            case OPEN -> next == TicketStatus.IN_PROGRESS || next == TicketStatus.CANCELLED;
            case IN_PROGRESS -> next == TicketStatus.RESOLVED || next == TicketStatus.CANCELLED;
            case RESOLVED -> next == TicketStatus.CLOSED;
            case CLOSED, CANCELLED -> false; // Terminal states
        };

        if (!valid) {
            throw new InvalidStateTransitionException(current, next);
        }
    }

    /**
     * Check if transition is valid without throwing exception.
     */
    public static boolean isValidTransition(TicketStatus current, TicketStatus next) {
        if (current == next) {
            return false;
        }

        return switch (current) {
            case OPEN -> next == TicketStatus.IN_PROGRESS || next == TicketStatus.CANCELLED;
            case IN_PROGRESS -> next == TicketStatus.RESOLVED || next == TicketStatus.CANCELLED;
            case RESOLVED -> next == TicketStatus.CLOSED;
            case CLOSED, CANCELLED -> false;
        };
    }
}
