package support_ticket_ai.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import support_ticket_ai.dto.CommentRequest;
import support_ticket_ai.dto.CommentResponse;
import support_ticket_ai.entity.Comment;
import support_ticket_ai.service.CommentService;

import java.util.List;

/**
 * REST controller for comment endpoints.
 */
@RestController
@RequestMapping("/api/tickets/{ticketId}/comments")
@RequiredArgsConstructor
@Slf4j
public class CommentController {

    private final CommentService commentService;

    /**
     * POST /api/tickets/{ticketId}/comments - Add a comment to a ticket.
     */
    @PostMapping
    public ResponseEntity<CommentResponse> addComment(
            @PathVariable Long ticketId,
            @Valid @RequestBody CommentRequest request) {
        log.info("Adding comment to ticket: ticketId={}", ticketId);
        Comment comment = commentService.addComment(ticketId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(CommentResponse.from(comment));
    }

    /**
     * GET /api/tickets/{ticketId}/comments - Get all comments for a ticket.
     */
    @GetMapping
    public ResponseEntity<List<CommentResponse>> getComments(@PathVariable Long ticketId) {
        log.info("Fetching comments for ticket: ticketId={}", ticketId);
        List<Comment> comments = commentService.getCommentsByTicket(ticketId);
        return ResponseEntity.ok(comments.stream().map(CommentResponse::from).toList());
    }
}
