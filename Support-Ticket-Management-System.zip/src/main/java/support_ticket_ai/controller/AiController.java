package support_ticket_ai.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import support_ticket_ai.dto.*;
import support_ticket_ai.rag.AiService;

/**
 * REST controller for AI question-answering endpoints.
 */
@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
@Slf4j
public class AiController {

    private final AiService aiService;

    /**
     * POST /api/ai/ask - Ask a question over ticket history.
     */
    @PostMapping("/ask")
    public ResponseEntity<AskResponse> ask(@Valid @RequestBody AskRequest request) {
        log.info("AI question received: '{}'", request.getQuestion());
        AskResponse response = aiService.ask(
            request.getQuestion(),
            request.getTopK(),
            request.getSimilarityThreshold()
        );
        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/ai/sentiment - Analyze sentiment of text.
     *
     * Request body:
     *   { "text": "This is frustrating!" }
     *
     * Response:
     *   {
     *     "text": "...",
     *     "sentiment": "NEGATIVE",
     *     "confidence": 0.92,
     *     "explanation": "The text expresses frustration and dissatisfaction"
     *   }
     */
    @PostMapping("/sentiment")
    public ResponseEntity<SentimentResponse> analyzeSentiment(@Valid @RequestBody SentimentRequest request) {
        log.info("Sentiment analysis requested");
        SentimentResponse response = aiService.analyzeSentiment(request.getText());
        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/ai/summarize - Summarize text.
     *
     * Request body:
     *   {
     *     "text": "Long ticket description...",
     *     "maxLength": 200
     *   }
     *
     * Response:
     *   {
     *     "originalText": "...",
     *     "summary": "Concise summary",
     *     "compressionRatio": 3.5
     *   }
     */
    @PostMapping("/summarize")
    public ResponseEntity<SummarizeResponse> summarize(@Valid @RequestBody SummarizeRequest request) {
        log.info("Summarize requested");
        SummarizeResponse response = aiService.summarize(request.getText(), request.getMaxLength());
        return ResponseEntity.ok(response);
    }
}
