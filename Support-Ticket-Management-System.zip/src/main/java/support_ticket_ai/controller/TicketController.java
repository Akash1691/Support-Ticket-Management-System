package support_ticket_ai.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import support_ticket_ai.dto.StatusChangeRequest;
import support_ticket_ai.dto.TicketDetailResponse;
import support_ticket_ai.dto.TicketRequest;
import support_ticket_ai.dto.TicketResponse;
import support_ticket_ai.entity.Priority;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.service.TicketService;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for ticket endpoints.
 */
@RestController
@RequestMapping("/api/tickets")
@RequiredArgsConstructor
@Slf4j
public class TicketController {

    private final TicketService ticketService;

    /**
     * POST /api/tickets - Create a new ticket.
     */
    @PostMapping
    public ResponseEntity<TicketResponse> createTicket(@Valid @RequestBody TicketRequest request) {
        log.info("Creating ticket: title={}", request.getTitle());
        Ticket ticket = ticketService.createTicket(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(TicketResponse.from(ticket));
    }

    /**
     * GET /api/tickets - List tickets with pagination, search, and filtering.
     * Query params:
     *   - page: 0-indexed page number (default: 0)
     *   - size: page size (default: 20)
     *   - search: keyword to search in title/description
     *   - status: filter by ticket status
     *   - priority: filter by priority
     *   - assignee: filter by assignee
     *   - category: filter by category
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> listTickets(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) TicketStatus status,
            @RequestParam(required = false) Priority priority,
            @RequestParam(required = false) String assignee,
            @RequestParam(required = false) String category) {

        Pageable pageable = PageRequest.of(page, size);
        Page<Ticket> tickets;

        // Build query based on parameters
        if (search != null && !search.isBlank()) {
            if (status != null) {
                tickets = ticketService.filterByStatusAndKeyword(status, search, pageable);
            } else {
                tickets = ticketService.searchByKeyword(search, pageable);
            }
        } else if (status != null) {
            tickets = ticketService.filterByStatus(status, pageable);
        } else if (priority != null) {
            tickets = ticketService.filterByPriority(priority, pageable);
        } else if (assignee != null && !assignee.isBlank()) {
            tickets = ticketService.filterByAssignee(assignee, pageable);
        } else if (category != null && !category.isBlank()) {
            tickets = ticketService.filterByCategory(category, pageable);
        } else {
            tickets = ticketService.listTickets(pageable);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("content", tickets.getContent().stream().map(TicketResponse::from).toList());
        response.put("totalElements", tickets.getTotalElements());
        response.put("totalPages", tickets.getTotalPages());
        response.put("currentPage", tickets.getNumber());
        response.put("pageSize", tickets.getSize());

        return ResponseEntity.ok(response);
    }

    /**
     * GET /api/tickets/{id} - Get ticket detail with comments.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TicketDetailResponse> getTicketDetail(@PathVariable Long id) {
        log.info("Fetching ticket detail: id={}", id);
        Ticket ticket = ticketService.getTicketById(id);
        return ResponseEntity.ok(TicketDetailResponse.from(ticket));
    }

    /**
     * PUT /api/tickets/{id} - Update ticket (title, description, priority, assignee, category).
     */
    @PutMapping("/{id}")
    public ResponseEntity<TicketResponse> updateTicket(
            @PathVariable Long id,
            @Valid @RequestBody TicketRequest request) {
        log.info("Updating ticket: id={}", id);
        Ticket updated = ticketService.updateTicket(id, request);
        return ResponseEntity.ok(TicketResponse.from(updated));
    }

    /**
     * PATCH /api/tickets/{id}/assignee - Update ticket assignee.
     */
    @PatchMapping("/{id}/assignee")
    public ResponseEntity<TicketResponse> updateAssignee(
            @PathVariable Long id,
            @Valid @RequestBody Map<String, String> body) {
        String assignee = body.get("assignee");
        log.info("Updating assignee: id={}, assignee={}", id, assignee);
        Ticket updated = ticketService.updateAssignee(id, assignee);
        return ResponseEntity.ok(TicketResponse.from(updated));
    }

    /**
     * PATCH /api/tickets/{id}/status - Change ticket status (state machine enforced).
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<TicketResponse> changeStatus(
            @PathVariable Long id,
            @Valid @RequestBody StatusChangeRequest request) {
        log.info("Changing status: id={}, newStatus={}", id, request.getNewStatus());
        Ticket updated = ticketService.changeStatus(id, request.getNewStatus());
        return ResponseEntity.ok(TicketResponse.from(updated));
    }

    /**
     * DELETE /api/tickets/{id} - Delete a ticket.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTicket(@PathVariable Long id) {
        log.info("Deleting ticket: id={}", id);
        ticketService.deleteTicket(id);
        return ResponseEntity.noContent().build();
    }
}
