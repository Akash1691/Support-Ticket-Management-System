package support_ticket_ai.exception;

/**
 * Exception thrown when a ticket is not found.
 */
public class TicketNotFoundException extends RuntimeException {
    public TicketNotFoundException(Long ticketId) {
        super("Ticket %d not found".formatted(ticketId));
    }

    public TicketNotFoundException(String message) {
        super(message);
    }
}
