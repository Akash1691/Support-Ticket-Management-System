package support_ticket_ai.exception;

import support_ticket_ai.entity.TicketStatus;

/**
 * Exception thrown when an invalid state transition is attempted.
 */
public class InvalidStateTransitionException extends RuntimeException {
    public InvalidStateTransitionException(TicketStatus from, TicketStatus to) {
        super("Cannot transition from %s to %s".formatted(from, to));
    }

    public InvalidStateTransitionException(String message) {
        super(message);
    }
}
