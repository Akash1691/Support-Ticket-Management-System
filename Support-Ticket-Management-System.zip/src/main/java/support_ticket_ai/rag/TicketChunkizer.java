package support_ticket_ai.rag;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.stereotype.Component;
import support_ticket_ai.entity.ChunkType;
import support_ticket_ai.entity.Comment;
import support_ticket_ai.entity.Ticket;

import java.util.*;

/**
 * Converts tickets into semantic chunks for embeddings.
 * Strategy: Chunk by ticket section (Description, Comment, Resolution)
 * rather than fixed-size chunks, to preserve semantic coherence.
 */
@Component
@Slf4j
public class TicketChunkizer {

    /**
     * Convert a ticket into chunks for embedding.
     * Creates one chunk per section: description, each comment.
     */
    public List<Document> chunkify(Ticket ticket) {
        List<Document> chunks = new ArrayList<>();

        // Chunk 1: Description
        Document descChunk = createDescriptionChunk(ticket);
        chunks.add(descChunk);
        log.debug("Created description chunk for ticket {}", ticket.getId());

        // Chunk 2+: Comments (one per chunk)
        for (Comment comment : ticket.getComments()) {
            Document commentChunk = createCommentChunk(ticket, comment);
            chunks.add(commentChunk);
            log.debug("Created comment chunk for ticket {} comment {}", ticket.getId(), comment.getId());
        }

        return chunks;
    }

    /**
     * Create a description chunk from ticket title, description, and metadata.
     */
    private Document createDescriptionChunk(Ticket ticket) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("ticketId", ticket.getId());
        metadata.put("chunkType", ChunkType.DESCRIPTION.toString());
        metadata.put("status", ticket.getStatus().toString());
        metadata.put("priority", ticket.getPriority().toString());
        if (ticket.getCategory() != null) {
            metadata.put("category", ticket.getCategory());
        }
        if (ticket.getAssignee() != null) {
            metadata.put("assignee", ticket.getAssignee());
        }
        metadata.put("createdAt", ticket.getCreatedAt().toString());

        String content = formatDescriptionChunk(ticket);
        String id = "ticket-%d-description".formatted(ticket.getId());

        return new Document(id, content, metadata);
    }

    /**
     * Create a comment chunk.
     */
    private Document createCommentChunk(Ticket ticket, Comment comment) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("ticketId", ticket.getId());
        metadata.put("commentId", comment.getId());
        metadata.put("chunkType", ChunkType.COMMENT.toString());
        metadata.put("status", ticket.getStatus().toString());
        if (comment.getAuthor() != null) {
            metadata.put("author", comment.getAuthor());
        }
        metadata.put("createdAt", comment.getCreatedAt().toString());

        String content = formatCommentChunk(ticket, comment);
        String id = "ticket-%d-comment-%d".formatted(ticket.getId(), comment.getId());

        return new Document(id, content, metadata);
    }

    /**
     * Format description chunk text.
     * Includes: Ticket ID, Title, Description, Category, Priority
     */
    private String formatDescriptionChunk(Ticket ticket) {
        StringBuilder sb = new StringBuilder();
        sb.append("Ticket TKT-").append(ticket.getId()).append(": ").append(ticket.getTitle()).append("\n");

        if (ticket.getDescription() != null && !ticket.getDescription().isBlank()) {
            sb.append("Description: ").append(ticket.getDescription()).append("\n");
        }

        if (ticket.getCategory() != null && !ticket.getCategory().isBlank()) {
            sb.append("Category: ").append(ticket.getCategory()).append("\n");
        }

        sb.append("Priority: ").append(ticket.getPriority()).append("\n");
        sb.append("Status: ").append(ticket.getStatus());

        return sb.toString();
    }

    /**
     * Format comment chunk text.
     * Includes: Author, Comment text
     */
    private String formatCommentChunk(Ticket ticket, Comment comment) {
        StringBuilder sb = new StringBuilder();
        sb.append("Ticket TKT-").append(ticket.getId()).append(" Comment");

        if (comment.getAuthor() != null && !comment.getAuthor().isBlank()) {
            sb.append(" by ").append(comment.getAuthor());
        }

        sb.append(":\n");
        sb.append(comment.getText());

        return sb.toString();
    }
}
