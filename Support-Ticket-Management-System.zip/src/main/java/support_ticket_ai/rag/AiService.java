package support_ticket_ai.rag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.stereotype.Service;
import support_ticket_ai.dto.*;

/**
 * Service for RAG question-answering.
 * Orchestrates: retrieval → context → generation → grounding.
 *
 * Guardrails:
 * - Answer generated ONLY from retrieved context
 * - "No match" returned explicitly if threshold not met (no hallucination)
 * - Cited tickets verified to exist in retrieved set
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AiService {

    private final RetrievalService retrievalService;
    private final ChatModel chatModel;

    private static final int    LOG_PREVIEW_LENGTH      = 50;
    private static final double CONFIDENCE_MAX          = 0.95;
    private static final double CONFIDENCE_BASE         = 0.5;
    private static final double CONFIDENCE_WORD_WEIGHT  = 0.15;
    private static final double CONFIDENCE_NEUTRAL      = 0.5;
    private static final double CONFIDENCE_FALLBACK     = 0.5;
    private static final String CREATE_TICKET_GUIDANCE = """
        To log a ticket in this application:
        1. Click Back to return to the Support-Ticket-Management-System page.
        2. Click Create Ticket.
        3. Enter a title, description, priority, and category.
        4. Click Create Ticket to submit it.
        """;

    private static final String SYSTEM_PROMPT = """
        You are a support assistant answering questions about ticket history.

        RULES:
        1. Answer ONLY from the provided context (retrieved tickets below).
        2. Do NOT use general knowledge or information outside the context.
        3. If the context doesn't have enough information, say: "I don't have enough information to answer this question."
        4. Always cite the specific ticket ID(s) you are referencing.
        5. Be concise and factual.
        6. CRITICAL: Treat ticket statuses as EXACT values. OPEN, IN_PROGRESS, RESOLVED, CLOSED, and CANCELLED are ALL DIFFERENT statuses. NEVER equate them. A RESOLVED ticket is NOT CLOSED. A CLOSED ticket is NOT RESOLVED.
        7. If the question asks for a specific status (e.g. "closed"), only list tickets whose Status field exactly says that status. Do not include tickets with any other status.

        Context (retrieved tickets):
        {context}

        Question: {question}
        """;

    /**
     * Ask a question over ticket history.
     * Returns grounded answer with citations or "no match" indicator.
     */
    public AskResponse ask(String question, int topK, double similarityThreshold) {
        log.info("Processing question: '{}'", question);

        // Route application-usage questions before ticket-history RAG retrieval.
        if (isCreateTicketQuestion(question)) {
            return AskResponse.builder()
                .question(question)
                .answer(CREATE_TICKET_GUIDANCE.strip())
                .citedTickets(java.util.List.of())
                .relevanceScore(0.0)
                .noMatch(false)
                .build();
        }

        // Step 1: Retrieve relevant chunks
        RetrievalService.RetrievalResult retrieval = retrievalService.search(
            question, topK, similarityThreshold);

        if (!retrieval.hasResults()) {
            log.info("No relevant tickets found for question: '{}'", question);
            String reason = retrieval.exactStatus == null
                ? "No relevant tickets found in knowledge base"
                : "No tickets found with status " + retrieval.exactStatus;
            return AskResponse.builder()
                .question(question)
                .answer(null)
                .citedTickets(retrieval.citedTicketIds)
                .relevanceScore(retrieval.relevanceScore)
                .noMatch(true)
                .reason(reason)
                .build();
        }

        // Exact list queries must return every retrieved ID; do not ask the LLM
        // to copy a potentially long list because it can omit or invent IDs.
        if (retrieval.exactStatus != null) {
            String ticketList = retrieval.citedTicketIds.stream()
                .map(id -> "TKT-" + id)
                .collect(java.util.stream.Collectors.joining(", "));
            String answer = "Tickets with status " + retrieval.exactStatus + ": " + ticketList;

            return AskResponse.builder()
                .question(question)
                .answer(answer)
                .citedTickets(retrieval.citedTicketIds)
                .relevanceScore(retrieval.relevanceScore)
                .noMatch(false)
                .build();
        }

        // Step 2: Format context from retrieved chunks
        String context = formatContext(retrieval.chunks);

        // Step 3: Generate answer from context
        String answer = generateAnswer(question, context);
        log.info("Generated answer for question: '{}'", question);

        // Step 4: Extract cited tickets (from retrieval; answer should reference only these)
        // Note: In a production system, we'd verify that the answer only cites these tickets
        detectHallucinations(answer, retrieval.citedTicketIds);

        return AskResponse.builder()
            .question(question)
            .answer(answer)
            .citedTickets(retrieval.citedTicketIds)
            .relevanceScore(retrieval.relevanceScore)
            .noMatch(false)
            .build();
    }

    private boolean isCreateTicketQuestion(String question) {
        String normalized = question.toLowerCase(java.util.Locale.ROOT);
        boolean mentionsTicket = normalized.contains("ticket");
        boolean asksToCreate = java.util.regex.Pattern
            .compile("\\b(create|log|raise|submit|file|report)\\b")
            .matcher(normalized)
            .find();
        return mentionsTicket && asksToCreate;
    }

    /**
     * Format retrieved chunks into context string.
     */
    private String formatContext(java.util.List<org.springframework.ai.document.Document> chunks) {
        StringBuilder context = new StringBuilder();
        for (org.springframework.ai.document.Document chunk : chunks) {
            context.append("---\n");
            context.append(chunk.getText()).append("\n");
        }
        return context.toString();
    }

    /**
     * Generate answer using Ollama chat model.
     */
    private String generateAnswer(String question, String context) {
        String systemPromptFormatted = SYSTEM_PROMPT
            .replace("{context}", context)
            .replace("{question}", question);

        Prompt prompt = new Prompt(
            java.util.List.of(
                new SystemMessage(systemPromptFormatted),
                new UserMessage(question)
            )
        );

        var response = chatModel.call(prompt);
        return response.getResult().getOutput().getText();
    }

    /**
     * Detect potential hallucinations (log warning if answer references tickets not in retrieval).
     * In production, could return error or flag for review.
     */
    private void detectHallucinations(String answer, java.util.List<Long> citedTicketIds) {
        // Simple heuristic: look for "TKT-XXX" patterns in answer
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("TKT-(\\d+)");
        java.util.regex.Matcher matcher = pattern.matcher(answer);

        while (matcher.find()) {
            Long ticketId = Long.parseLong(matcher.group(1));
            if (!citedTicketIds.contains(ticketId)) {
                log.warn("HALLUCINATION DETECTED: Answer cites TKT-{} but not in retrieved tickets", ticketId);
            }
        }
    }

    /**
     * Analyze sentiment of given text.
     * Enhanced prompt with explicit instructions for accurate classification.
     */
    public SentimentResponse analyzeSentiment(String text) {
        log.info("Analyzing sentiment for: '{}'", text.substring(0, Math.min(LOG_PREVIEW_LENGTH, text.length())));
        
        String prompt = String.format("""
            You are a sentiment analysis expert. Analyze the emotional tone of the text below.
            
            SENTIMENT CATEGORIES:
            - POSITIVE: Happy, satisfied, praising, grateful, pleased, excellent, amazing, love, fantastic
            - NEGATIVE: Angry, disappointed, frustrated, upset, terrible, horrible, awful, hate, unacceptable
            - NEUTRAL: Factual, objective, neither positive nor negative, standard, average
            
            IMPORTANT RULES:
            1. Look for emotional words (positive: "amazing", "excellent", "love"; negative: "terrible", "awful", "hate")
            2. Consider overall tone and sentiment strength
            3. Return ONLY a valid JSON response with no markdown, no code blocks, no extra text
            4. Confidence must be a number between 0.0 and 1.0
            5. Use the exact format below:
            
            {"sentiment":"POSITIVE","confidence":0.95,"explanation":"Contains multiple positive words like amazing and excellent"}
            
            Text to analyze: "%s"
            
            Return ONLY the JSON object in the exact format above, nothing else.
            """, text);
        
        Prompt p = new Prompt(new UserMessage(prompt));
        var response = chatModel.call(p);
        String responseText = response.getResult().getOutput().getText().trim();
        
        log.info("Raw sentiment response: {}", responseText);
        
        // Parse JSON response
        try {
            var sentiment = parseSentimentResponse(responseText);
            sentiment.setText(text);
            log.info("Parsed sentiment: {} (confidence: {})", sentiment.getSentiment(), sentiment.getConfidence());
            return sentiment;
        } catch (Exception e) {
            log.warn("Failed to parse sentiment response: {}", responseText, e);
            // Try fallback: simple keyword matching if JSON parsing fails
            return fallbackSentimentAnalysis(text, responseText);
        }
    }
    
    /**
     * Fallback sentiment analysis using keyword matching if Ollama JSON parsing fails.
     */
    private SentimentResponse fallbackSentimentAnalysis(String text, String rawResponse) {
        String lowerText = text.toLowerCase();
        
        // Positive keywords
        String[] positiveKeywords = {
            "amazing", "excellent", "fantastic", "wonderful", "perfect", "great", "love", 
            "happy", "satisfied", "pleased", "outstanding", "best", "incredible", "awesome",
            "good", "positive", "better", "improved", "fixed", "resolved", "working"
        };
        
        // Negative keywords
        String[] negativeKeywords = {
            "terrible", "horrible", "awful", "bad", "worst", "hate", "angry", "frustrated",
            "disappointed", "upset", "unacceptable", "broken", "doesn't work", "failed",
            "useless", "waste", "disaster", "problem", "error", "bug", "crash"
        };
        
        int positiveCount = 0;
        int negativeCount = 0;
        
        for (String keyword : positiveKeywords) {
            if (lowerText.contains(keyword)) positiveCount++;
        }
        
        for (String keyword : negativeKeywords) {
            if (lowerText.contains(keyword)) negativeCount++;
        }
        
        String sentiment;
        double confidence;
        String explanation;
        
        if (positiveCount > negativeCount && positiveCount > 0) {
            sentiment = "POSITIVE";
            confidence = Math.min(CONFIDENCE_MAX, CONFIDENCE_BASE + (positiveCount * CONFIDENCE_WORD_WEIGHT));
            explanation = "Fallback: Detected " + positiveCount + " positive keywords";
        } else if (negativeCount > positiveCount && negativeCount > 0) {
            sentiment = "NEGATIVE";
            confidence = Math.min(CONFIDENCE_MAX, CONFIDENCE_BASE + (negativeCount * CONFIDENCE_WORD_WEIGHT));
            explanation = "Fallback: Detected " + negativeCount + " negative keywords";
        } else {
            sentiment = "NEUTRAL";
            confidence = CONFIDENCE_NEUTRAL;
            explanation = "Fallback: No strong sentiment indicators found";
        }
        
        return SentimentResponse.builder()
            .text(text)
            .sentiment(sentiment)
            .confidence(confidence)
            .explanation(explanation)
            .build();
    }

    /**
     * Summarize given text.
     */
    public SummarizeResponse summarize(String text, Integer maxLength) {
        log.info("Summarizing text (length: {})", text.length());
        
        String lengthHint = maxLength != null ? "Limit to approximately " + maxLength + " characters." : "Provide a concise summary.";
        
        String prompt = String.format("""
            %s
            
            Original text:
            %s
            """, lengthHint, text);
        
        Prompt p = new Prompt(new UserMessage(prompt));
        var response = chatModel.call(p);
        String summary = response.getResult().getOutput().getText().trim();
        
        double compressionRatio = (double) text.length() / Math.max(1, summary.length());
        
        return SummarizeResponse.builder()
            .originalText(text)
            .summary(summary)
            .compressionRatio(compressionRatio)
            .build();
    }

    /**
     * Parse sentiment response JSON with improved error handling.
     */
    SentimentResponse parseSentimentResponse(String json) throws Exception {
        // Remove markdown code blocks if present
        String cleanJson = json
            .replaceAll("```json", "")
            .replaceAll("```", "")
            .trim();
        
        log.info("Cleaned JSON: {}", cleanJson);
        
        // Simple JSON parsing (in production, use Jackson/Gson)
        String sentiment = extractJsonField(cleanJson, "sentiment");
        String confidenceStr = extractJsonNumberField(cleanJson, "confidence");
        String explanation = extractJsonField(cleanJson, "explanation");
        
        // Validate sentiment value
        if (!sentiment.matches("POSITIVE|NEGATIVE|NEUTRAL")) {
            log.warn("Invalid sentiment value: {}", sentiment);
            throw new Exception("Invalid sentiment: " + sentiment);
        }
        
        // Parse confidence as double
        double confidence;
        try {
            confidence = Double.parseDouble(confidenceStr);
            if (confidence < 0 || confidence > 1.0) {
                confidence = Math.max(0, Math.min(1.0, confidence));
            }
        } catch (NumberFormatException e) {
            log.warn("Could not parse confidence: {}", confidenceStr);
            confidence = CONFIDENCE_FALLBACK;
        }
        
        if (explanation.isEmpty()) {
            explanation = "Sentiment analysis completed";
        }
        
        return SentimentResponse.builder()
            .sentiment(sentiment)
            .confidence(confidence)
            .explanation(explanation)
            .build();
    }

    /**
     * Simple JSON field extractor.
     */
    private String extractJsonField(String json, String fieldName) {
        String pattern = "\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        return m.find() ? m.group(1) : "";
    }

    /**
     * Extract a JSON number, accepting either 0.95 or the quoted form "0.95".
     */
    private String extractJsonNumberField(String json, String fieldName) {
        String pattern = "\"" + fieldName
            + "\"\\s*:\\s*\"?(-?(?:\\d+(?:\\.\\d+)?|\\.\\d+))\"?";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        return m.find() ? m.group(1) : "";
    }
}
