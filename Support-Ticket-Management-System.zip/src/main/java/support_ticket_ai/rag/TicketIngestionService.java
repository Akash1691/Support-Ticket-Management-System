package support_ticket_ai.rag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import support_ticket_ai.event.CommentAddedEvent;
import support_ticket_ai.event.TicketCreatedEvent;
import support_ticket_ai.event.TicketUpdatedEvent;
import support_ticket_ai.exception.TicketNotFoundException;
import support_ticket_ai.repository.TicketEmbeddingMetadataRepository;
import support_ticket_ai.repository.TicketRepository;
import support_ticket_ai.entity.Ticket;

import java.util.List;

/**
 * Service for RAG ingestion pipeline.
 * Listens for ticket events and manages embeddings in vector store.
 *
 * Pipeline:
 * 1. Ticket created/updated → fetch ticket + comments
 * 2. Chunkify → split into semantic chunks (description, comments)
 * 3. Generate embeddings via Ollama
 * 4. Store in VectorStore with metadata
 * 5. Track in DB via TicketEmbeddingMetadata
 */
@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class TicketIngestionService {

    private final TicketRepository ticketRepository;
    private final TicketEmbeddingMetadataRepository embeddingMetadataRepository;
    private final TicketChunkizer chunkizer;
    private final VectorStore vectorStore;

    /**
     * Listen for ticket creation and ingest embeddings.
     */
    @EventListener
    public void onTicketCreated(TicketCreatedEvent event) {
        Long ticketId = event.getTicketId();
        log.info("Ingesting new ticket: {}", ticketId);
        ingestTicket(ticketId);
    }

    /**
     * Listen for comment addition and ingest comment chunk.
     */
    @EventListener
    public void onCommentAdded(CommentAddedEvent event) {
        Long ticketId = event.getTicketId();
        Long commentId = event.getCommentId();
        log.info("Ingesting comment: ticketId={}, commentId={}", ticketId, commentId);
        ingestTicket(ticketId);
    }

    /**
     * Listen for ticket updates and re-ingest.
     */
    @EventListener
    public void onTicketUpdated(TicketUpdatedEvent event) {
        Long ticketId = event.getTicketId();
        log.info("Re-ingesting updated ticket: {}", ticketId);
        reIngestTicket(ticketId);
    }

    /**
     * Ingest a ticket: chunkify → embed → store.
     * Does not delete old chunks (use reIngestTicket for that).
     */
    public void ingestTicket(Long ticketId) {
        Ticket ticket = ticketRepository.findById(ticketId)
            .orElseThrow(() -> new TicketNotFoundException(ticketId));

        // Chunkify
        List<Document> chunks = chunkizer.chunkify(ticket);
        if (chunks.isEmpty()) {
            log.warn("No chunks generated for ticket {}", ticketId);
            return;
        }

        // Store in vector store (embeddings generated automatically)
        vectorStore.add(chunks);
        log.info("Ingested ticket {}: {} chunks", ticketId, chunks.size());
    }

    /**
     * Re-ingest a ticket: delete old chunks, then ingest fresh.
     * Used when ticket is updated (to avoid stale embeddings).
     */
    public void reIngestTicket(Long ticketId) {
        // Delete old chunks from vector store
        embeddingMetadataRepository.deleteByTicketId(ticketId);
        log.info("Deleted old embeddings for ticket {}", ticketId);

        // Ingest fresh
        ingestTicket(ticketId);
    }
}
