package support_ticket_ai.rag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;
import org.springframework.ai.vectorstore.SearchRequest;
import support_ticket_ai.entity.Ticket;
import support_ticket_ai.entity.TicketStatus;
import support_ticket_ai.repository.TicketRepository;

import java.util.*;
import java.util.stream.Collectors;
import java.util.regex.Pattern;

/**
 * Service for RAG retrieval.
 * Performs similarity search on question embeddings.
 * Filters results by similarity threshold.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RetrievalService {

    private final VectorStore vectorStore;
    private final TicketRepository ticketRepository;
    private final TicketChunkizer ticketChunkizer;

    /**
     * Search for similar chunks given a question.
     * Returns sorted by relevance (similarity score descending).
     * Filters by similarity threshold.
     */
    private static final Map<Pattern, TicketStatus> STATUS_PATTERNS = Map.of(
        Pattern.compile("\\b(closed|close)\\b", Pattern.CASE_INSENSITIVE), TicketStatus.CLOSED,
        Pattern.compile("\\b(cancelled|canceled|cancel)\\b", Pattern.CASE_INSENSITIVE), TicketStatus.CANCELLED,
        Pattern.compile("\\b(resolved|resolve)\\b", Pattern.CASE_INSENSITIVE), TicketStatus.RESOLVED,
        Pattern.compile("\\b(in.?progress|in progress|ongoing)\\b", Pattern.CASE_INSENSITIVE), TicketStatus.IN_PROGRESS,
        Pattern.compile("\\b(open)\\b", Pattern.CASE_INSENSITIVE), TicketStatus.OPEN
    );

    private Optional<TicketStatus> detectStatusFilter(String question) {
        for (Map.Entry<Pattern, TicketStatus> entry : STATUS_PATTERNS.entrySet()) {
            if (entry.getKey().matcher(question).find()) {
                return Optional.of(entry.getValue());
            }
        }
        return Optional.empty();
    }

    public RetrievalResult search(String question, int topK, double similarityThreshold) {
        log.debug("Retrieving chunks for question: '{}' (topK={}, threshold={})",
            question, topK, similarityThreshold);

        Optional<TicketStatus> statusFilter = detectStatusFilter(question);
        statusFilter.ifPresent(s -> log.info("Status filter detected from question: {}", s));

        /*
         * Exact status lists are structured retrieval, not a similarity problem.
         * Retrieve all matching source records and turn them into RAG documents so
         * no ticket is lost because of topK ranking or an embedding startup race.
         */
        if (statusFilter.isPresent()) {
            TicketStatus status = statusFilter.get();
            List<Ticket> tickets = ticketRepository.findAllByStatusOrderByIdAsc(status);
            List<Document> documents = tickets.stream()
                .map(ticket -> ticketChunkizer.chunkify(ticket).getFirst())
                .toList();
            List<Long> ticketIds = tickets.stream().map(Ticket::getId).toList();

            log.info("Structured RAG retrieval found {} tickets with status {}", ticketIds.size(), status);
            return new RetrievalResult(documents, ticketIds, tickets.isEmpty() ? 0.0 : 1.0, status);
        }

        SearchRequest searchRequest = SearchRequest.builder()
            .query(question)
            .topK(topK)
            .similarityThreshold(similarityThreshold)
            .build();

        List<Document> results = vectorStore.similaritySearch(searchRequest);

        if (results.isEmpty()) {
            log.info("No relevant chunks found for question: '{}'", question);
            return RetrievalResult.empty();
        }

        // Extract ticket IDs and calculate average score
        Set<Long> ticketIds = results.stream()
            .map(doc -> (Number) doc.getMetadata().get("ticketId"))
            .map(Number::longValue)
            .collect(Collectors.toSet());

        double avgScore = results.stream()
            .mapToDouble(doc -> doc.getScore() != null ? doc.getScore() : 0.0)
            .average()
            .orElse(0.0);

        log.info("Retrieved {} chunks from {} tickets, avg score: {}", results.size(), ticketIds.size(), avgScore);
        return new RetrievalResult(results, new ArrayList<>(ticketIds), avgScore, null);
    }

    /**
     * Result of retrieval operation.
     */
    public static class RetrievalResult {
        public final List<Document> chunks;
        public final List<Long> citedTicketIds;
        public final double relevanceScore;
        public final TicketStatus exactStatus;

        public RetrievalResult(
            List<Document> chunks,
            List<Long> citedTicketIds,
            double relevanceScore,
            TicketStatus exactStatus
        ) {
            this.chunks = chunks;
            this.citedTicketIds = citedTicketIds;
            this.relevanceScore = relevanceScore;
            this.exactStatus = exactStatus;
        }

        public static RetrievalResult empty() {
            return new RetrievalResult(List.of(), List.of(), 0.0, null);
        }

        public boolean hasResults() {
            return !chunks.isEmpty();
        }
    }
}
