package support_ticket_ai.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * Event published when a comment is added to a ticket.
 * Triggers embedding ingestion for the new comment.
 */
@Getter
public class CommentAddedEvent extends ApplicationEvent {
    private final Long ticketId;
    private final Long commentId;

    public CommentAddedEvent(Object source, Long ticketId, Long commentId) {
        super(source);
        this.ticketId = ticketId;
        this.commentId = commentId;
    }
}
