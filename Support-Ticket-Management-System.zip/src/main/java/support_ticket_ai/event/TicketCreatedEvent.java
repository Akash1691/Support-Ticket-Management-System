package support_ticket_ai.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * Event published when a ticket is created.
 * Triggers embedding ingestion for RAG.
 */
@Getter
public class TicketCreatedEvent extends ApplicationEvent {
    private final Long ticketId;

    public TicketCreatedEvent(Object source, Long ticketId) {
        super(source);
        this.ticketId = ticketId;
    }
}
