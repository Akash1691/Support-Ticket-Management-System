package support_ticket_ai.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * Event published when a ticket is updated (title, description, etc.).
 * Triggers re-ingestion of embeddings for that ticket.
 */
@Getter
public class TicketUpdatedEvent extends ApplicationEvent {
    private final Long ticketId;

    public TicketUpdatedEvent(Object source, Long ticketId) {
        super(source);
        this.ticketId = ticketId;
    }
}
