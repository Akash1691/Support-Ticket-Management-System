#!/bin/bash

echo "Stopping Ticket AI services..."

pkill -f "TicketAiApplication" && echo "Backend stopped" || echo "Backend was not running"
pkill -f "react-scripts/scripts/start" && echo "Frontend stopped" || echo "Frontend was not running"

sudo systemctl stop ollama && echo "Ollama stopped" || echo "Ollama was not running"

echo "Done."
