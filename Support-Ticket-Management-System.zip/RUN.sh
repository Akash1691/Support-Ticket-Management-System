#!/bin/bash

echo "🚀 Support Ticket System - Full Stack Setup"
echo "==========================================="
echo ""

# Check ports
echo "✓ Checking ports..."
if lsof -i :11434 > /dev/null 2>&1; then
    echo "  ✓ Port 11434 (Ollama): IN USE"
else
    echo "  ✗ Port 11434 (Ollama): Available"
    echo "    Start Ollama with: docker run -d -p 11434:11434 ollama/ollama"
fi

if lsof -i :8080 > /dev/null 2>&1; then
    echo "  ✗ Port 8080 (Backend): IN USE - Kill with: pkill -f spring-boot:run"
else
    echo "  ✓ Port 8080 (Backend): Available"
fi

if lsof -i :3000 > /dev/null 2>&1; then
    echo "  ✗ Port 3000 (Frontend): IN USE - Kill with: pkill -f node"
else
    echo "  ✓ Port 3000 (Frontend): Available"
fi

echo ""
echo "📋 Next Steps:"
echo ""
echo "1. Ensure Ollama is running:"
echo "   docker run -d -p 11434:11434 ollama/ollama"
echo ""
echo "2. Start Backend (Terminal 1):"
echo "   cd /home/akash/Projects/ticket-ai"
echo "   mvn clean spring-boot:run -s /tmp/mvn-settings.xml"
echo ""
echo "3. Start Frontend (Terminal 2):"
echo "   cd /home/akash/Projects/ticket-ai/frontend"
echo "   npm install  # (first time only)"
echo "   npm start"
echo ""
echo "4. Open http://localhost:3000 in browser"
echo ""
echo "✨ All set! Create tickets → Ask AI → Profit!"
