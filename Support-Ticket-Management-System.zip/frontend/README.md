# Support Ticket System - Frontend

React 18 + TypeScript + Axios frontend for the AI-Powered Support Ticket Management System.

## Features

- **Ticket Management**
  - List tickets with pagination
  - Search by keyword
  - Filter by status, priority, category
  - View ticket details
  - Create new tickets
  - Update ticket information
  - Change ticket status (enforced state machine)
  - Assign tickets

- **Comments**
  - View all comments on a ticket
  - Add comments with author attribution

- **RAG Question-Answering**
  - Ask questions over ticket history
  - Tunable retrieval parameters (topK, similarity threshold)
  - Displays answers with cited ticket sources
  - Handles "no match" scenarios gracefully

## Architecture

```
src/
├── types/index.ts          # TypeScript interfaces (Ticket, Comment, etc.)
├── services/api.ts         # Axios API client + service layer
├── components/
│   ├── TicketList.tsx      # List view + search/filter
│   ├── TicketDetail.tsx    # Detail view + comments + edit
│   ├── CreateTicket.tsx    # Create new ticket form
│   └── AskQuestion.tsx     # RAG question modal
├── App.tsx                 # Main app + routing
└── index.css               # Global styles
```

## API Client

The frontend communicates with the backend API at `http://localhost:8080/api` (configurable via `REACT_APP_API_URL`).

### Services

#### ticketService
- `createTicket(request)` - Create new ticket
- `listTickets(page, size, search, status, priority)` - List with filtering
- `getTicket(id)` - Get ticket detail
- `updateTicket(id, request)` - Update ticket fields
- `changeStatus(id, newStatus)` - Change status (state machine enforced)
- `updateAssignee(id, assignee)` - Update assignee
- `deleteTicket(id)` - Delete ticket

#### commentService
- `addComment(ticketId, request)` - Add comment
- `getComments(ticketId)` - Get comments for ticket

#### aiService
- `ask(request)` - Ask question over ticket history

### Error Handling

All API errors are converted to `ApiError` with status code + message. Components display errors in red boxes.

## Running Locally

### Prerequisites
- Node 18+ (Node 20+ recommended)
- Backend running on `http://localhost:8080`

### Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm start
```

App opens on `http://localhost:3000`.

### Build for Production

```bash
npm run build
# Output: frontend/build/
```

## Components Overview

### TicketList
- Lists tickets with pagination
- Search box (title/description)
- Status filter dropdown
- "New Ticket" button
- Click to view detail

### TicketDetail
- Display ticket info (title, description, status, priority, assignee, category)
- Edit mode for title/description
- Status dropdown (enforces state machine transitions)
- Comments section (add + list)
- Shows created date

### CreateTicket
- Form: title* + description + priority + category
- Validation: title required
- Submit creates ticket + returns to list

### AskQuestion
- Modal dialog
- Question textarea
- Tunable topK (1-20) + similarity threshold (0.0-1.0)
- Display results:
  - If match: answer + cited tickets + relevance score
  - If no match: explicit message
- "Ask Another Question" to reset

## Configuration

Set `REACT_APP_API_URL` in `.env`:

```env
REACT_APP_API_URL=http://localhost:8080/api
```

## Development

### Folder Structure

```
frontend/
├── public/               # Static assets
├── src/
│   ├── components/       # React components
│   ├── services/         # API layer
│   ├── types/            # TypeScript interfaces
│   ├── App.tsx           # Main app
│   ├── App.css           # App styles
│   ├── index.tsx         # Entry point
│   └── index.css         # Global styles
├── package.json          # Dependencies
├── tsconfig.json         # TypeScript config
└── .env                  # Environment variables
```

### Styling

Uses native CSS with CSS variables. Tailwind setup included but not required for MVP.

### TypeScript

All components are fully typed. Key interfaces in `src/types/index.ts`:

- `Ticket`: ticket data
- `TicketDetail`: ticket + comments
- `Comment`: comment data
- `AskResponse`: RAG response
- `ApiError`: error handling

## Testing

### Manual Testing Checklist

- [ ] Create ticket (all fields)
- [ ] List tickets (pagination works)
- [ ] Search tickets (keyword search)
- [ ] Filter by status
- [ ] View ticket detail
- [ ] Edit ticket (title, description, priority)
- [ ] Change status (verify state machine)
- [ ] Add comment (with author)
- [ ] Ask question (relevant answer)
- [ ] Ask question (no match case)
- [ ] Error handling (404, 400, network errors)

## Deployment

### Docker (Optional)

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### Serve Build

```bash
npm install -g serve
serve -s build -l 3000
```

## Troubleshooting

### API Connection Issues
- Check backend is running on `http://localhost:8080`
- Verify `REACT_APP_API_URL` in `.env`
- Check browser console for network errors

### Build Failures
- Clear node_modules: `rm -rf node_modules && npm install`
- Clear cache: `npm run build --reset-cache`

### Component Not Rendering
- Check TypeScript errors: `npm run build`
- Check browser DevTools console for React errors

## Next Steps

- Add E2E tests (Cypress/Playwright)
- Add unit tests (Jest)
- Add theme switcher (light/dark mode)
- Add ticket export (CSV)
- Add filtering by assignee
- Optimize re-renders with React.memo
- Add loading skeletons
- Add infinite scroll (pagination alternative)

## References

- [React Docs](https://react.dev)
- [TypeScript Docs](https://www.typescriptlang.org/docs/)
- [Axios Docs](https://axios-http.com/docs/intro)
