import React, { useState } from 'react';
import { Ticket } from './types';
import { TicketList } from './components/TicketList';
import { TicketDetailView } from './components/TicketDetail';
import { CreateTicket } from './components/CreateTicket';
import { AiHub } from './components/AiHub';
import './App.css';

type View = 'list' | 'detail' | 'create' | 'ai-hub' | null;

function App() {
  const [view, setView] = useState<View>('list');
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);

  const handleSelectTicket = (ticket: Ticket) => {
    setSelectedTicketId(ticket.id);
    setView('detail');
  };

  const handleBack = () => {
    setView('list');
    setSelectedTicketId(null);
  };

  const handleCreateNew = () => {
    setView('create');
  };

  const handleCreateSuccess = () => {
    setView('list');
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ background: 'linear-gradient(135deg, #0066cc 0%, #004fa3 100%)', color: 'white', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', padding: '24px 0', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h1 style={{ fontSize: '32px', fontWeight: '700', marginBottom: '4px', letterSpacing: '-1px' }}>
                🎫 Support-Ticket-Management-System
              </h1>
              <p style={{ fontSize: '14px', opacity: 0.9, fontWeight: '500' }}>
                Support Ticket Management System
              </p>
            </div>
            <button
              onClick={() => setView('ai-hub')}
              style={{
                background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                color: 'white',
                padding: '12px 24px',
                borderRadius: '8px',
                border: 'none',
                fontWeight: '600',
                fontSize: '16px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                transition: 'all 0.3s',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
              }}
            >
              🤖 AI Hub
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main style={{ flex: 1, width: '100%' }}>
        {view === 'list' && (
          <div style={{ maxWidth: '1200px', width: '100%', margin: '0 auto', padding: '32px 16px' }}>
            <TicketList onSelectTicket={handleSelectTicket} onCreateNew={handleCreateNew} />
          </div>
        )}

        {view === 'detail' && selectedTicketId && (
          <div style={{ maxWidth: '1200px', width: '100%', margin: '0 auto', padding: '32px 16px' }}>
            <TicketDetailView ticketId={selectedTicketId} onBack={handleBack} />
          </div>
        )}

        {view === 'create' && (
          <div style={{ maxWidth: '1200px', width: '100%', margin: '0 auto', padding: '32px 16px' }}>
            <CreateTicket
              onSuccess={handleCreateSuccess}
              onCancel={handleBack}
            />
          </div>
        )}

        {view === 'ai-hub' && (
          <AiHub onBack={handleBack} />
        )}
      </main>

      {/* Footer */}
      <footer style={{ background: '#1f2937', color: '#9ca3af', textAlign: 'center', padding: '24px', marginTop: '48px', fontSize: '13px', borderTop: '1px solid #374151' }}>
        <p style={{ margin: 0 }}>
          ✨ Built with <strong style={{ color: '#fff' }}>Spring Boot 4.1</strong> | <strong style={{ color: '#fff' }}>React 18</strong> | <strong style={{ color: '#fff' }}>Ollama</strong> | <strong style={{ color: '#fff' }}>Java 25</strong>
        </p>
      </footer>
    </div>
  );
}

export default App;
