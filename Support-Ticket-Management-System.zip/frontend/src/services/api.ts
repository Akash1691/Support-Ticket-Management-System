/**
 * API client and services
 */

import axios, { AxiosInstance } from 'axios';
import {
  Ticket,
  TicketDetail,
  Comment,
  TicketRequest,
  CommentRequest,
  StatusChangeRequest,
  PaginatedResponse,
  AskRequest,
  AskResponse,
  SentimentRequest,
  SentimentResponse,
  SummarizeRequest,
  SummarizeResponse,
  ApiError,
} from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';

const axiosClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000,  // 120 seconds for Ask AI (Ollama LLM takes time)
  headers: {
    'Content-Type': 'application/json',
  },
});

// Error handler
axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      throw new ApiError(error.response.status, error.response.data.message);
    }
    throw new ApiError(500, 'Network error or server unavailable');
  }
);

/**
 * Ticket API service
 */
export const ticketService = {
  /**
   * Create a new ticket
   */
  createTicket(request: TicketRequest): Promise<Ticket> {
    return axiosClient.post('/tickets', request).then((res) => res.data);
  },

  /**
   * List tickets with pagination, search, filtering
   */
  listTickets(
    page: number = 0,
    size: number = 20,
    search?: string,
    status?: string,
    priority?: string
  ): Promise<PaginatedResponse<Ticket>> {
    const params: any = { page, size };
    if (search) params.search = search;
    if (status) params.status = status;
    if (priority) params.priority = priority;

    return axiosClient
      .get('/tickets', { params })
      .then((res) => res.data);
  },

  /**
   * Get ticket detail with comments
   */
  getTicket(id: number): Promise<TicketDetail> {
    return axiosClient.get(`/tickets/${id}`).then((res) => res.data);
  },

  /**
   * Update ticket (title, description, priority, category)
   */
  updateTicket(id: number, request: Partial<TicketRequest>): Promise<Ticket> {
    return axiosClient.put(`/tickets/${id}`, request).then((res) => res.data);
  },

  /**
   * Change ticket status
   */
  changeStatus(id: number, newStatus: string): Promise<Ticket> {
    const request: StatusChangeRequest = { newStatus: newStatus as any };
    return axiosClient
      .patch(`/tickets/${id}/status`, request)
      .then((res) => res.data);
  },

  /**
   * Update assignee
   */
  updateAssignee(id: number, assignee: string): Promise<Ticket> {
    return axiosClient
      .patch(`/tickets/${id}/assignee`, { assignee })
      .then((res) => res.data);
  },

  /**
   * Delete ticket
   */
  deleteTicket(id: number): Promise<void> {
    return axiosClient.delete(`/tickets/${id}`).then(() => undefined);
  },
};

/**
 * Comment API service
 */
export const commentService = {
  /**
   * Add comment to ticket
   */
  addComment(ticketId: number, request: CommentRequest): Promise<Comment> {
    return axiosClient
      .post(`/tickets/${ticketId}/comments`, request)
      .then((res) => res.data);
  },

  /**
   * Get comments for ticket
   */
  getComments(ticketId: number): Promise<Comment[]> {
    return axiosClient
      .get(`/tickets/${ticketId}/comments`)
      .then((res) => res.data);
  },
};

/**
 * AI service (RAG, Sentiment, Summarization)
 */
export const aiService = {
  /**
   * Ask question over ticket history
   */
  ask(request: AskRequest): Promise<AskResponse> {
    return axiosClient.post('/ai/ask', request).then((res) => res.data);
  },

  /**
   * Analyze sentiment of text
   */
  analyzeSentiment(request: SentimentRequest): Promise<SentimentResponse> {
    return axiosClient.post('/ai/sentiment', request).then((res) => res.data);
  },

  /**
   * Summarize text
   */
  summarize(request: SummarizeRequest): Promise<SummarizeResponse> {
    return axiosClient.post('/ai/summarize', request).then((res) => res.data);
  },
};
