/**
 * Ticket management types (aligned with backend)
 */

export enum TicketStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED',
  CANCELLED = 'CANCELLED',
}

export enum Priority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

export interface Ticket {
  id: number;
  title: string;
  description: string;
  status: TicketStatus;
  priority: Priority;
  assignee: string | null;
  category: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TicketDetail extends Ticket {
  comments: Comment[];
}

export interface Comment {
  id: number;
  ticketId: number;
  text: string;
  author: string | null;
  createdAt: string;
}

export interface TicketRequest {
  title: string;
  description: string;
  priority: Priority;
  category: string;
}

export interface CommentRequest {
  text: string;
  author: string;
}

export interface StatusChangeRequest {
  newStatus: TicketStatus;
}

export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}

/**
 * RAG types
 */

export interface AskRequest {
  question: string;
  topK: number;
  similarityThreshold: number;
}

export interface AskResponse {
  question: string;
  answer: string | null;
  citedTickets: number[];
  relevanceScore: number;
  noMatch: boolean;
  reason: string | null;
}

/**
 * Sentiment Analysis
 */
export interface SentimentRequest {
  text: string;
}

export interface SentimentResponse {
  text: string;
  sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  confidence: number;
  explanation: string;
}

/**
 * Summarization
 */
export interface SummarizeRequest {
  text: string;
  maxLength?: number;
}

export interface SummarizeResponse {
  originalText: string;
  summary: string;
  compressionRatio: number;
}

/**
 * Error handling
 */

export interface ErrorResponse {
  timestamp: string;
  status: number;
  error: string;
  message: string;
  path: string;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}
