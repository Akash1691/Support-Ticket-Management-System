import React, { useState } from 'react';
import {
  AskResponse,
  SentimentResponse,
  SummarizeResponse,
} from '../types';
import { aiService } from '../services/api';

type TabType = 'ask' | 'sentiment' | 'summarize';

interface AiHubProps {
  onBack?: () => void;
}

export const AiHub: React.FC<AiHubProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<TabType>('ask');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Ask tab state
  const [askQuestion, setAskQuestion] = useState('');
  const [askTopK, setAskTopK] = useState(5);
  const [askThreshold, setAskThreshold] = useState(0.7);
  const [askResponse, setAskResponse] = useState<AskResponse | null>(null);

  // Sentiment tab state
  const [sentimentText, setSentimentText] = useState('');
  const [sentimentResponse, setSentimentResponse] = useState<SentimentResponse | null>(null);

  // Summarize tab state
  const [summarizeText, setSummarizeText] = useState('');
  const [summarizeLength, setSummarizeLength] = useState<number | undefined>(undefined);
  const [summarizeResponse, setSummarizeResponse] = useState<SummarizeResponse | null>(null);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!askQuestion.trim()) {
      setError('Question is required');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const result = await aiService.ask({
        question: askQuestion,
        topK: askTopK,
        similarityThreshold: askThreshold,
      });
      setAskResponse(result);
    } catch (err: any) {
      setError(err.message || 'Failed to process question');
    } finally {
      setLoading(false);
    }
  };

  const handleSentiment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sentimentText.trim()) {
      setError('Text is required');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const result = await aiService.analyzeSentiment({ text: sentimentText });
      setSentimentResponse(result);
    } catch (err: any) {
      setError(err.message || 'Failed to analyze sentiment');
    } finally {
      setLoading(false);
    }
  };

  const handleSummarize = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!summarizeText.trim()) {
      setError('Text is required');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const result = await aiService.summarize({
        text: summarizeText,
        maxLength: summarizeLength,
      });
      setSummarizeResponse(result);
    } catch (err: any) {
      setError(err.message || 'Failed to summarize text');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#f9fafb', padding: '32px 16px' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <h1 style={{ fontSize: '40px', fontWeight: '800', marginBottom: '8px', color: '#1f2937', margin: 0 }}>
              🤖 AI Hub
            </h1>
            <p style={{ fontSize: '16px', color: '#6b7280', margin: '0' }}>
              Test AI-powered features: Ask, Sentiment, Summarize
            </p>
          </div>
          {onBack && (
            <button
              onClick={onBack}
              style={{
                padding: '10px 20px',
                background: '#6b7280',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                fontWeight: '600',
                fontSize: '14px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                whiteSpace: 'nowrap',
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.background = '#4b5563';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.background = '#6b7280';
              }}
            >
              ← Back
            </button>
          )}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: '12px', marginBottom: '32px', overflowX: 'auto', paddingBottom: '8px' }}>
          {(['ask', 'sentiment', 'summarize'] as TabType[]).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setError('');
                // Reset responses when switching tabs
                setAskResponse(null);
                setSentimentResponse(null);
                setSummarizeResponse(null);
              }}
              style={{
                padding: '12px 24px',
                border: 'none',
                borderRadius: '8px',
                fontWeight: '600',
                fontSize: '14px',
                cursor: 'pointer',
                background: activeTab === tab ? '#0066cc' : '#e5e7eb',
                color: activeTab === tab ? '#fff' : '#1f2937',
                transition: 'all 0.3s',
                whiteSpace: 'nowrap',
              }}
            >
              {tab === 'ask' && '💡 Ask AI'}
              {tab === 'sentiment' && '😊 Sentiment'}
              {tab === 'summarize' && '📝 Summarize'}
            </button>
          ))}
        </div>

        {/* Error */}
        {error && (
          <div style={{
            padding: '16px',
            background: '#fee2e2',
            color: '#991b1b',
            borderRadius: '8px',
            marginBottom: '24px',
            border: '1px solid #fecaca',
          }}>
            ❌ {error}
          </div>
        )}

        {/* Content */}
        <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', padding: '32px' }}>
          {/* ASK AI TAB */}
          {activeTab === 'ask' && (
            <div style={{ maxWidth: '800px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '16px', color: '#1f2937' }}>
                💡 Ask About Your Tickets
              </h2>
              <p style={{ color: '#6b7280', marginBottom: '24px' }}>
                Ask questions about your support ticket history. The AI will search relevant tickets and provide grounded answers with citations.
              </p>

              {askResponse ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                  <div style={{ background: '#eff6ff', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
                    <p style={{ fontSize: '12px', color: '#0369a1', marginBottom: '8px', fontWeight: '600' }}>QUESTION</p>
                    <p style={{ color: '#1e40af', fontSize: '16px', fontWeight: '600' }}>{askResponse.question}</p>
                  </div>

                  {askResponse.noMatch ? (
                    <div style={{ background: '#fef3c7', padding: '16px', borderRadius: '8px', border: '1px solid #fde68a', marginBottom: '16px' }}>
                      <p style={{ color: '#92400e', marginBottom: '8px' }}>⚠️ {askResponse.reason}</p>
                      <p style={{ fontSize: '13px', color: '#b45309' }}>
                        Try rephrasing or check if there are related tickets in the system.
                      </p>
                    </div>
                  ) : (
                    <div style={{ background: '#f0fdf4', padding: '16px', borderRadius: '8px', border: '1px solid #bbf7d0', marginBottom: '16px' }}>
                      <p style={{ fontSize: '12px', color: '#059669', marginBottom: '8px', fontWeight: '600' }}>ANSWER</p>
                      <p style={{ color: '#1f2937', whiteSpace: 'pre-wrap', lineHeight: '1.6', marginBottom: '12px' }}>
                        {askResponse.answer}
                      </p>
                      <div style={{ display: 'flex', gap: '16px', fontSize: '13px', color: '#4b5563' }}>
                        {askResponse.citedTickets.length > 0 && (
                          <div>
                            <strong>Cited:</strong> {askResponse.citedTickets.map((id) => `TKT-${id}`).join(', ')}
                          </div>
                        )}
                        <div>
                          <strong>Score:</strong> {(askResponse.relevanceScore * 100).toFixed(0)}%
                        </div>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      setAskResponse(null);
                      setAskQuestion('');
                    }}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#0066cc',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: 'pointer',
                    }}
                  >
                    Ask Another Question
                  </button>
                </div>
              ) : (
                <form onSubmit={handleAsk} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                      Question *
                    </label>
                    <textarea
                      value={askQuestion}
                      onChange={(e) => setAskQuestion(e.target.value)}
                      placeholder="e.g., Have we seen payment failures? What are common shipping issues?"
                      style={{
                        width: '100%',
                        padding: '12px',
                        border: '1px solid #d1d5db',
                        borderRadius: '8px',
                        fontFamily: 'inherit',
                        fontSize: '14px',
                        minHeight: '120px',
                      }}
                      disabled={loading}
                    />
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                        Top Results: {askTopK}
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="20"
                        value={askTopK}
                        onChange={(e) => setAskTopK(parseInt(e.target.value))}
                        style={{ width: '100%' }}
                        disabled={loading}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                        Threshold: {askThreshold.toFixed(2)}
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={askThreshold}
                        onChange={(e) => setAskThreshold(parseFloat(e.target.value))}
                        style={{ width: '100%' }}
                        disabled={loading}
                      />
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '12px' }}>
                    <button
                      type="submit"
                      disabled={loading}
                      style={{
                        flex: 1,
                        padding: '12px',
                        background: '#0066cc',
                        color: '#fff',
                        border: 'none',
                        borderRadius: '8px',
                        fontWeight: '600',
                        cursor: loading ? 'not-allowed' : 'pointer',
                        opacity: loading ? 0.6 : 1,
                      }}
                    >
                      {loading ? '⏳ Thinking...' : '🚀 Ask'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* SENTIMENT TAB */}
          {activeTab === 'sentiment' && (
            <div style={{ maxWidth: '800px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '16px', color: '#1f2937' }}>
                😊 Sentiment Analysis
              </h2>
              <p style={{ color: '#6b7280', marginBottom: '24px' }}>
                Analyze the sentiment of customer messages, feedback, or ticket descriptions to understand the customer's mood.
              </p>

              {sentimentResponse ? (
                <div>
                  <div style={{ background: '#f3f4f6', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', color: '#4b5563', marginBottom: '8px' }}>INPUT</p>
                    <p style={{ color: '#1f2937', fontSize: '14px' }}>{sentimentResponse.text}</p>
                  </div>

                  <div
                    style={{
                      background:
                        sentimentResponse.sentiment === 'POSITIVE'
                          ? '#f0fdf4'
                          : sentimentResponse.sentiment === 'NEGATIVE'
                            ? '#fef2f2'
                            : '#fffbeb',
                      padding: '16px',
                      borderRadius: '8px',
                      marginBottom: '16px',
                      border: `1px solid ${
                        sentimentResponse.sentiment === 'POSITIVE'
                          ? '#bbf7d0'
                          : sentimentResponse.sentiment === 'NEGATIVE'
                            ? '#fecaca'
                            : '#fde68a'
                      }`,
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
                      <span style={{ fontSize: '32px' }}>
                        {sentimentResponse.sentiment === 'POSITIVE' ? '😊' : sentimentResponse.sentiment === 'NEGATIVE' ? '😞' : '😐'}
                      </span>
                      <div>
                        <p style={{ fontSize: '18px', fontWeight: '700', color: '#1f2937', margin: '0' }}>
                          {sentimentResponse.sentiment}
                        </p>
                        <p style={{ fontSize: '13px', color: '#4b5563', margin: '0' }}>
                          Confidence: {(sentimentResponse.confidence * 100).toFixed(0)}%
                        </p>
                      </div>
                    </div>
                    <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '0' }}>
                      {sentimentResponse.explanation}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setSentimentResponse(null);
                      setSentimentText('');
                    }}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#0066cc',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: 'pointer',
                    }}
                  >
                    Analyze Another
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSentiment}>
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                      Text to Analyze *
                    </label>
                    <textarea
                      value={sentimentText}
                      onChange={(e) => setSentimentText(e.target.value)}
                      placeholder="e.g., This product is amazing! I love it."
                      style={{
                        width: '100%',
                        padding: '12px',
                        border: '1px solid #d1d5db',
                        borderRadius: '8px',
                        fontFamily: 'inherit',
                        fontSize: '14px',
                        minHeight: '120px',
                      }}
                      disabled={loading}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#0066cc',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      opacity: loading ? 0.6 : 1,
                    }}
                  >
                    {loading ? '⏳ Analyzing...' : '📊 Analyze'}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* SUMMARIZE TAB */}
          {activeTab === 'summarize' && (
            <div style={{ maxWidth: '800px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '16px', color: '#1f2937' }}>
                📝 Text Summarization
              </h2>
              <p style={{ color: '#6b7280', marginBottom: '24px' }}>
                Condense long descriptions or documents into concise summaries while preserving key information.
              </p>

              {summarizeResponse ? (
                <div>
                  <div style={{ background: '#f3f4f6', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', color: '#4b5563', marginBottom: '8px', fontWeight: '600' }}>ORIGINAL</p>
                    <p style={{ color: '#1f2937', fontSize: '14px', lineHeight: '1.6', maxHeight: '200px', overflow: 'auto' }}>
                      {summarizeResponse.originalText}
                    </p>
                  </div>

                  <div style={{ background: '#f0fdf4', padding: '16px', borderRadius: '8px', border: '1px solid #bbf7d0', marginBottom: '16px' }}>
                    <p style={{ fontSize: '13px', color: '#059669', marginBottom: '8px', fontWeight: '600' }}>SUMMARY</p>
                    <p style={{ color: '#1f2937', fontSize: '14px', lineHeight: '1.6', marginBottom: '12px' }}>
                      {summarizeResponse.summary}
                    </p>
                    <p style={{ fontSize: '13px', color: '#4b5563' }}>
                      Compression: {summarizeResponse.compressionRatio.toFixed(2)}x
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setSummarizeResponse(null);
                      setSummarizeText('');
                    }}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#0066cc',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: 'pointer',
                    }}
                  >
                    Summarize Another
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSummarize}>
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                      Text to Summarize *
                    </label>
                    <textarea
                      value={summarizeText}
                      onChange={(e) => setSummarizeText(e.target.value)}
                      placeholder="Paste a long ticket description, customer feedback, or any text..."
                      style={{
                        width: '100%',
                        padding: '12px',
                        border: '1px solid #d1d5db',
                        borderRadius: '8px',
                        fontFamily: 'inherit',
                        fontSize: '14px',
                        minHeight: '120px',
                      }}
                      disabled={loading}
                    />
                  </div>

                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                      Max Length (optional)
                    </label>
                    <input
                      type="number"
                      value={summarizeLength || ''}
                      onChange={(e) => setSummarizeLength(e.target.value ? parseInt(e.target.value) : undefined)}
                      placeholder="Leave blank for auto"
                      style={{
                        width: '100%',
                        padding: '12px',
                        border: '1px solid #d1d5db',
                        borderRadius: '8px',
                        fontFamily: 'inherit',
                        fontSize: '14px',
                      }}
                      disabled={loading}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    style={{
                      width: '100%',
                      padding: '12px',
                      background: '#0066cc',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '8px',
                      fontWeight: '600',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      opacity: loading ? 0.6 : 1,
                    }}
                  >
                    {loading ? '⏳ Summarizing...' : '✨ Summarize'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
