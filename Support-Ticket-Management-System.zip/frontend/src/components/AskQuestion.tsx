import React, { useState } from 'react';
import { AskRequest, AskResponse } from '../types';
import { aiService } from '../services/api';

interface AskQuestionProps {
  onClose: () => void;
}

export const AskQuestion: React.FC<AskQuestionProps> = ({ onClose }) => {
  const [question, setQuestion] = useState('');
  const [topK, setTopK] = useState(5);
  const [threshold, setThreshold] = useState(0.7);
  const [response, setResponse] = useState<AskResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) {
      setError('Question is required');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const request: AskRequest = {
        question,
        topK,
        similarityThreshold: threshold,
      };
      const result = await aiService.ask(request);
      setResponse(result);
    } catch (err: any) {
      setError(err.message || 'Failed to ask question');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-md max-w-2xl w-full max-h-96 overflow-y-auto p-6 space-y-4">
        <div className="flex justify-between items-center border-b pb-4">
          <h2 className="text-2xl font-bold">Ask about Tickets</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl"
          >
            ×
          </button>
        </div>

        {error && <div className="p-3 bg-red-50 text-red-600 rounded-md">{error}</div>}

        {response ? (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-sm text-gray-600 mb-1">Question:</p>
              <p className="font-medium">{response.question}</p>
            </div>

            {response.noMatch ? (
              <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
                <p className="text-gray-700">
                  ⚠️ {response.reason}
                </p>
                <p className="text-sm text-gray-600 mt-2">
                  Try rephrasing your question or check if there are related tickets in the system.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-green-50 p-4 rounded-md border border-green-200">
                  <p className="text-sm text-gray-600 mb-2">Answer:</p>
                  <p className="text-gray-900 whitespace-pre-wrap">{response.answer}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <div>
                      {response.citedTickets.length > 0 && (
                        <p className="text-sm text-gray-600">
                          <strong>Cited tickets:</strong> {response.citedTickets.map(id => `TKT-${id}`).join(', ')}
                        </p>
                      )}
                    </div>
                    <div className="text-sm">
                      <span className="bg-gray-200 px-2 py-1 rounded">
                        Score: {(response.relevanceScore * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={() => {
                setResponse(null);
                setQuestion('');
              }}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Ask Another Question
            </button>
          </div>
        ) : (
          <form onSubmit={handleAsk} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Question *
              </label>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="e.g., Have we seen payment failures before? What are common shipping issues?"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-20"
                disabled={loading}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Top Results (topK): {topK}
                </label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={topK}
                  onChange={(e) => setTopK(parseInt(e.target.value))}
                  className="w-full"
                  disabled={loading}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Relevance Threshold: {threshold.toFixed(2)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={threshold}
                  onChange={(e) => setThreshold(parseFloat(e.target.value))}
                  className="w-full"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="flex gap-3 border-t pt-4">
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {loading ? 'Thinking...' : 'Ask'}
              </button>
              <button
                type="button"
                onClick={onClose}
                disabled={loading}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50"
              >
                Close
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
