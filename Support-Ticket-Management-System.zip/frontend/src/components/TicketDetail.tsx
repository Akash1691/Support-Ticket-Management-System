import React, { useEffect, useState } from 'react';
import {
  TicketDetail,
  Comment,
  TicketStatus,
  Priority,
  CommentRequest,
} from '../types';
import { ticketService, commentService } from '../services/api';

interface TicketDetailViewProps {
  ticketId: number;
  onBack: () => void;
}

export const TicketDetailView: React.FC<TicketDetailViewProps> = ({ ticketId, onBack }) => {
  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    priority: Priority.MEDIUM,
  });
  const [newComment, setNewComment] = useState('');
  const [commentAuthor, setCommentAuthor] = useState('');
  const [assigneeInput, setAssigneeInput] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [submittingAssignee, setSubmittingAssignee] = useState(false);

  useEffect(() => {
    loadTicket();
  }, [ticketId]);

  const loadTicket = async () => {
    try {
      setLoading(true);
      setError('');
      const detail = await ticketService.getTicket(ticketId);
      setTicket(detail);
      setAssigneeInput(detail.assignee || '');
      setEditForm({
        title: detail.title,
        description: detail.description,
        priority: detail.priority,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to load ticket');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: TicketStatus) => {
    try {
      const updated = await ticketService.changeStatus(ticketId, newStatus);
      setTicket({ ...ticket!, ...updated });
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to update status');
    }
  };

  const handleSaveEdit = async () => {
    try {
      const updated = await ticketService.updateTicket(ticketId, editForm);
      setTicket({ ...ticket!, ...updated });
      setIsEditing(false);
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to update ticket');
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    try {
      setSubmittingComment(true);
      const request: CommentRequest = {
        text: newComment,
        author: commentAuthor || 'Anonymous',
      };
      const comment = await commentService.addComment(ticketId, request);
      setTicket({
        ...ticket!,
        comments: [...ticket!.comments, comment],
      });
      setNewComment('');
      setCommentAuthor('');
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to add comment');
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleAssigneeChange = async () => {
    try {
      setSubmittingAssignee(true);
      const updated = await ticketService.updateAssignee(ticketId, assigneeInput);
      setTicket({ ...ticket!, assignee: updated.assignee });
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to update assignee');
    } finally {
      setSubmittingAssignee(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!ticket) {
    return (
      <div className="text-center py-8 text-red-600">Ticket not found</div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
        >
          ← Back
        </button>
        <h1 className="text-2xl font-bold">TKT-{ticket.id}</h1>
      </div>

      {error && <div className="p-3 bg-red-50 text-red-600 rounded-md">{error}</div>}

      {/* Header Info */}
      <div className="bg-white p-4 rounded-md border border-gray-200 space-y-3">
        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={ticket.status}
            onChange={(e) => handleStatusChange(e.target.value as TicketStatus)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {Object.values(TicketStatus).map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>

          <select
            value={ticket.priority}
            onChange={(e) =>
              setEditForm({ ...editForm, priority: e.target.value as Priority })
            }
            className="px-3 py-2 border border-gray-300 rounded-md"
          >
            {Object.values(Priority).map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>

          <div className="flex gap-2 flex-1 min-w-48">
            <input
              type="text"
              placeholder="Assignee"
              value={assigneeInput}
              onChange={(e) => setAssigneeInput(e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={handleAssigneeChange}
              disabled={submittingAssignee}
              className="px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
            >
              {submittingAssignee ? '...' : 'Set'}
            </button>
          </div>

          {ticket.category && (
            <span className="px-3 py-2 bg-gray-100 text-gray-700 rounded-md">
              {ticket.category}
            </span>
          )}
        </div>

        {isEditing ? (
          <div className="space-y-3">
            <input
              type="text"
              value={editForm.title}
              onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              placeholder="Title"
            />
            <textarea
              value={editForm.description}
              onChange={(e) =>
                setEditForm({ ...editForm, description: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md h-24"
              placeholder="Description"
            />
            <div className="flex gap-2">
              <button
                onClick={handleSaveEdit}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Save
              </button>
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div onClick={() => setIsEditing(true)} className="cursor-pointer">
            <h2 className="text-xl font-semibold">{ticket.title}</h2>
            <p className="text-gray-600 mt-2 whitespace-pre-wrap">
              {ticket.description}
            </p>
            <p className="text-xs text-gray-500 mt-4">
              Click to edit • Created {new Date(ticket.createdAt).toLocaleDateString()}
            </p>
          </div>
        )}
      </div>

      {/* Comments Section */}
      <div className="bg-white p-4 rounded-md border border-gray-200 space-y-4">
        <h3 className="text-lg font-semibold">Comments ({ticket.comments.length})</h3>

        {/* Add Comment */}
        <div className="space-y-2 border-t pt-4">
          <input
            type="text"
            placeholder="Your name (optional)"
            value={commentAuthor}
            onChange={(e) => setCommentAuthor(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment..."
            className="w-full px-3 py-2 border border-gray-300 rounded-md h-16 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="flex gap-2">
            <button
              onClick={handleAddComment}
              disabled={!newComment.trim() || submittingComment}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              {submittingComment ? 'Adding...' : 'Add Comment'}
            </button>
            <button
              onClick={() => {
                setNewComment('');
                setCommentAuthor('');
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Comments List */}
        <div className="space-y-3 border-t pt-4">
          {ticket.comments.length === 0 ? (
            <p className="text-gray-500">No comments yet</p>
          ) : (
            ticket.comments.map((comment) => (
              <div key={comment.id} className="p-3 bg-gray-50 rounded-md">
                <div className="flex justify-between items-start">
                  <div className="font-medium text-sm text-gray-900">
                    {comment.author || 'Anonymous'}
                  </div>
                  <div className="text-xs text-gray-500">
                    {new Date(comment.createdAt).toLocaleString()}
                  </div>
                </div>
                <p className="text-sm text-gray-700 mt-2 whitespace-pre-wrap">
                  {comment.text}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
