import React, { useEffect, useState } from 'react';
import { Ticket, TicketStatus, Priority, PaginatedResponse } from '../types';
import { ticketService } from '../services/api';

interface TicketListProps {
  onSelectTicket: (ticket: Ticket) => void;
  onCreateNew: () => void;
}

export const TicketList: React.FC<TicketListProps> = ({ onSelectTicket, onCreateNew }) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    loadTickets();
  }, [page, search, statusFilter]);

  const loadTickets = async () => {
    try {
      setLoading(true);
      setError('');
      const response: PaginatedResponse<Ticket> = await ticketService.listTickets(
        page,
        20,
        search || undefined,
        statusFilter || undefined
      );
      setTickets(response.content);
      setTotalPages(response.totalPages);
    } catch (err: any) {
      setError(err.message || 'Failed to load tickets');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: TicketStatus) => {
    switch (status) {
      case TicketStatus.OPEN:
        return 'text-blue-600 bg-blue-50';
      case TicketStatus.IN_PROGRESS:
        return 'text-yellow-600 bg-yellow-50';
      case TicketStatus.RESOLVED:
        return 'text-green-600 bg-green-50';
      case TicketStatus.CLOSED:
        return 'text-gray-600 bg-gray-50';
      case TicketStatus.CANCELLED:
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case Priority.LOW:
        return 'text-green-600';
      case Priority.MEDIUM:
        return 'text-blue-600';
      case Priority.HIGH:
        return 'text-orange-600';
      case Priority.CRITICAL:
        return 'text-red-600 font-bold';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Filters Card */}
      <div style={{ background: 'white', borderRadius: '12px', padding: '24px', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '280px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '6px', color: '#374151', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              🔍 Search Tickets
            </label>
            <input
              type="text"
              placeholder="Search by title or description..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
              style={{ width: '100%', padding: '10px 12px', border: '2px solid #d1d5db', borderRadius: '8px', fontSize: '14px', transition: 'all 0.3s' }}
              onFocus={(e) => e.target.style.borderColor = '#0066cc'}
              onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
            />
          </div>

          <div style={{ minWidth: '180px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: '600', marginBottom: '6px', color: '#374151', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              📊 Filter by Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(0);
              }}
              style={{ width: '100%', padding: '10px 12px', border: '2px solid #d1d5db', borderRadius: '8px', fontSize: '14px' }}
            >
              <option value="">All Statuses</option>
              {Object.values(TicketStatus).map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onCreateNew}
            style={{
              background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
              color: 'white',
              padding: '10px 16px',
              border: 'none',
              borderRadius: '8px',
              fontWeight: '600',
              fontSize: '14px',
              cursor: 'pointer',
              transition: 'all 0.3s',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              whiteSpace: 'nowrap',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
            }}
          >
            ✨ Create Ticket
          </button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div style={{
          padding: '16px',
          borderRadius: '8px',
          borderLeft: '4px solid #ef4444',
          backgroundColor: '#fee2e2',
          color: '#991b1b',
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          fontSize: '14px',
          animation: 'slideIn 0.3s ease-out',
        }}>
          <span style={{ fontSize: '18px' }}>⚠️</span>
          {error}
        </div>
      )}

      {/* Tickets Grid */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px 20px', color: '#4b5563' }}>
          <div style={{ display: 'inline-block', width: '24px', height: '24px', border: '3px solid #e5e7eb', borderTopColor: '#0066cc', borderRadius: '50%', animation: 'spin 1s linear infinite', marginRight: '12px' }}></div>
          Loading tickets...
        </div>
      ) : tickets.length === 0 ? (
        <div style={{
          background: 'white',
          borderRadius: '12px',
          padding: '60px 20px',
          textAlign: 'center',
          color: '#4b5563',
          boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>📭</div>
          <p style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>No tickets found</p>
          <p style={{ fontSize: '13px', color: '#9ca3af' }}>Try adjusting your search or create a new ticket</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gap: '12px' }}>
          {tickets.map((ticket) => (
            <div
              key={ticket.id}
              onClick={() => onSelectTicket(ticket)}
              style={{
                background: 'white',
                border: '2px solid #e5e7eb',
                borderRadius: '12px',
                padding: '20px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1)';
                e.currentTarget.style.borderColor = '#0066cc';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.boxShadow = '0 1px 2px 0 rgba(0, 0, 0, 0.05)';
                e.currentTarget.style.borderColor = '#e5e7eb';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: '16px' }}>
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontWeight: '700', color: '#111827', marginBottom: '4px', fontSize: '16px' }}>
                    TKT-{ticket.id}: {ticket.title}
                  </h3>
                  <p style={{ fontSize: '14px', color: '#4b5563', marginTop: '8px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {ticket.description || 'No description'}
                  </p>
                  <div style={{ display: 'flex', gap: '8px', marginTop: '12px', flexWrap: 'wrap' }}>
                    <span style={{
                      fontSize: '12px',
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontWeight: '700',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px',
                      ...{
                        'OPEN': { backgroundColor: '#dbeafe', color: '#1e40af' },
                        'IN_PROGRESS': { backgroundColor: '#fef08a', color: '#854d0e' },
                        'RESOLVED': { backgroundColor: '#dcfce7', color: '#166534' },
                        'CLOSED': { backgroundColor: '#f3f4f6', color: '#374151' },
                        'CANCELLED': { backgroundColor: '#fee2e2', color: '#991b1b' },
                      }[ticket.status] || {}
                    }}>
                      {ticket.status}
                    </span>
                    {ticket.category && (
                      <span style={{ fontSize: '12px', padding: '6px 12px', borderRadius: '6px', backgroundColor: '#f3f4f6', color: '#374151', fontWeight: '600' }}>
                        {ticket.category}
                      </span>
                    )}
                  </div>
                </div>
                <div style={{ textAlign: 'right', minWidth: '120px' }}>
                  <div style={{
                    fontSize: '16px',
                    fontWeight: '700',
                    ...(
                      ticket.priority === 'LOW' ? { color: '#10b981' } :
                      ticket.priority === 'MEDIUM' ? { color: '#3b82f6' } :
                      ticket.priority === 'HIGH' ? { color: '#f59e0b' } :
                      { color: '#ef4444', textShadow: '0 0 2px rgba(239, 68, 68, 0.3)' }
                    )
                  }}>
                    {ticket.priority}
                  </div>
                  {ticket.assignee && (
                    <div style={{ fontSize: '12px', color: '#4b5563', marginTop: '8px', fontWeight: '500' }}>
                      👤 {ticket.assignee}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '16px', padding: '16px' }}>
          <button
            onClick={() => setPage(Math.max(0, page - 1))}
            disabled={page === 0}
            style={{
              padding: '8px 16px',
              border: '2px solid #d1d5db',
              borderRadius: '8px',
              background: page === 0 ? '#f3f4f6' : 'white',
              color: '#374151',
              cursor: page === 0 ? 'not-allowed' : 'pointer',
              fontWeight: '600',
              opacity: page === 0 ? 0.5 : 1,
              transition: 'all 0.3s',
            }}
          >
            ← Previous
          </button>
          <span style={{ fontSize: '14px', fontWeight: '600', color: '#374151', minWidth: '80px', textAlign: 'center' }}>
            Page {page + 1} of {totalPages}
          </span>
          <button
            onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
            disabled={page === totalPages - 1}
            style={{
              padding: '8px 16px',
              border: '2px solid #d1d5db',
              borderRadius: '8px',
              background: page === totalPages - 1 ? '#f3f4f6' : 'white',
              color: '#374151',
              cursor: page === totalPages - 1 ? 'not-allowed' : 'pointer',
              fontWeight: '600',
              opacity: page === totalPages - 1 ? 0.5 : 1,
              transition: 'all 0.3s',
            }}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
};
