# Setup Guide: Support Ticket System

Complete setup instructions to run the full stack application.

## Prerequisites

- **Java 25** (for backend)
- **Node 18+** (for frontend)
- **Docker** (optional, for Ollama)
- **Maven** (for building Java)
- **npm/yarn** (for Node)

## Quick Start (5 minutes)

### 1. Start Ollama (Required for RAG)

```bash
# Using Docker
docker run -d -p 11434:11434 ollama/ollama

# OR if installed locally
ollama serve
```

Pull required models:
```bash
curl http://localhost:11434/api/pull -d '{"name":"nomic-embed-text"}'
curl http://localhost:11434/api/pull -d '{"name":"mistral"}'
```

Verify:
```bash
curl http://localhost:11434/api/tags
# Should show: nomic-embed-text, mistral
```

### 2. Start Backend (Port 8080)

```bash
cd /home/akash/Projects/ticket-ai

# Build
mvn clean install -s /tmp/mvn-settings.xml

# Run
mvn spring-boot:run -s /tmp/mvn-settings.xml -Dspring-boot.run.arguments="--server.port=8080"
```

Or with Maven wrapper:
```bash
./mvnw spring-boot:run
```

Wait for:
```
Started TicketAiApplication in X.XXX seconds
```

### 3. Start Frontend (Port 3000)

In a **new terminal**:

```bash
cd /home/akash/Projects/ticket-ai/frontend

# Install dependencies (first time only)
npm install

# Start dev server
npm start
```

Browser opens automatically to `http://localhost:3000`

## Troubleshooting

### Error: "Network error or server unavailable"

**Cause**: Frontend can't connect to backend.

**Solution**:

1. **Verify backend is running** (port 8080)
   ```bash
   curl http://localhost:8080/api/tickets
   # Should return JSON (not 404 or connection refused)
   ```

2. **Verify CORS config** exists (CorsConfig.java added)
   ```bash
   # Check logs for "addCorsMappings"
   ```

3. **Check frontend .env**
   ```bash
   cat frontend/.env
   # Should show: REACT_APP_API_URL=http://localhost:8080/api
   ```

4. **Frontend must be restarted** after .env changes
   ```bash
   # Stop npm start (Ctrl+C)
   # Restart: npm start
   ```

5. **Clear browser cache**
   - Press `Ctrl+Shift+R` (hard refresh)
   - Or open DevTools → Application → Clear Storage

### Error: "Ollama connection refused"

**Cause**: Ollama service not running.

**Solution**:

```bash
# Start Ollama
docker run -d -p 11434:11434 ollama/ollama

# Verify
curl http://localhost:11434/api/tags

# Or pull models manually
curl http://localhost:11434/api/pull -d '{"name":"mistral"}'
```

### Error: "Maven build failed"

**Solution**:

```bash
# Clear cache
rm -rf ~/.m2/repository

# Use provided settings
mvn clean install -s /tmp/mvn-settings.xml

# Or use workspace cache
mvn clean install -Dmaven.repo.local=/home/akash/Projects/ticket-ai/.m2
```

### Error: "npm: command not found"

**Solution**:

```bash
# Install Node/npm
curl -fsSL https://fnm.io/install | bash
fnm install 18
fnm use 18

# Or use nvm
curl https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
```

### Frontend shows "No tickets found"

This is normal! Database starts empty. Create a ticket:

1. Click **✨ Create Ticket** button
2. Fill in title, description, priority
3. Click **Create Ticket**
4. Should appear in the list

### RAG "Ask AI" not working

**Requirements**:

1. Ollama running (see above)
2. Backend running with CORS config
3. At least 1 ticket created and indexed

**Test**:

```bash
# Check Ollama is accessible
curl http://localhost:11434/api/tags

# Check backend is accessible
curl http://localhost:8080/api/tickets

# Check RAG endpoint
curl -X POST http://localhost:8080/api/ai/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"test","topK":5,"similarityThreshold":0.7}'
```

## Ports Summary

| Service | Port | URL |
|---------|------|-----|
| Backend | 8080 | http://localhost:8080 |
| Frontend | 3000 | http://localhost:3000 |
| Ollama | 11434 | http://localhost:11434 |
| H2 Console | 8080 | http://localhost:8080/h2-console |

## Database Access

H2 Database Console (dev only):

```
URL: http://localhost:8080/h2-console
JDBC URL: jdbc:h2:mem:testdb
User: sa
Password: (empty)
```

## Environment Variables

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:8080/api
```

### Backend (application.properties)
```
spring.ai.ollama.base-url=http://localhost:11434
spring.ai.ollama.chat.model=mistral
spring.ai.ollama.embedding.model=nomic-embed-text
rag.retrieval.topK=5
rag.retrieval.similarityThreshold=0.7
```

## Development Workflow

1. **Start Ollama** (background)
2. **Start Backend** (terminal 1)
3. **Start Frontend** (terminal 2)
4. **Open browser** to http://localhost:3000

## Production Deployment

### Backend

```bash
# Build JAR
mvn clean package -s /tmp/mvn-settings.xml

# Run JAR
java -jar target/ticket-ai-0.0.1-SNAPSHOT.jar
```

### Frontend

```bash
# Build static files
npm run build

# Output: build/ directory
# Deploy to static hosting (Vercel, Netlify, S3, etc.)
```

### Docker (optional)

```bash
# Build backend image
docker build -f Dockerfile.backend -t ticket-ai:latest .

# Run with Ollama
docker run -d \
  -p 8080:8080 \
  -e SPRING_AI_OLLAMA_BASE_URL=http://ollama:11434 \
  --link ollama \
  ticket-ai:latest
```

## Testing

### API Tests

```bash
# List tickets
curl http://localhost:8080/api/tickets

# Create ticket
curl -X POST http://localhost:8080/api/tickets \
  -H "Content-Type: application/json" \
  -d '{
    "title":"Test",
    "description":"Test ticket",
    "priority":"HIGH",
    "category":"Test"
  }'

# Ask question (with tickets in DB)
curl -X POST http://localhost:8080/api/ai/ask \
  -H "Content-Type: application/json" \
  -d '{
    "question":"What issues exist?",
    "topK":5,
    "similarityThreshold":0.7
  }'
```

### Unit Tests

```bash
# Backend tests
mvn test -s /tmp/mvn-settings.xml

# Frontend tests (if added)
npm test
```

## Helpful Commands

```bash
# Kill process on port 8080
lsof -ti:8080 | xargs kill -9

# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Kill Ollama
docker stop $(docker ps -q --filter ancestor=ollama/ollama)

# Check all services
curl http://localhost:8080/api/tickets && echo "Backend ✓"
curl http://localhost:11434/api/tags && echo "Ollama ✓"
```

## Support

For issues:

1. Check logs in terminal
2. Verify ports (8080, 3000, 11434) not in use
3. Restart all services
4. Clear browser cache (`Ctrl+Shift+R`)
5. Check CORS config in backend
6. Verify Ollama models are installed

---

**Happy Ticketing! 🎫✨**
