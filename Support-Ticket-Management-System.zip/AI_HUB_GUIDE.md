# 🤖 AI Hub - Complete Guide

## Overview

The **AI Hub** is a dedicated interface for testing and exploring all AI-powered features of the Support Ticket System. It includes:

1. **Ask AI** - RAG-based Q&A over ticket history
2. **Sentiment Analysis** - Analyze text sentiment (Positive, Negative, Neutral)
3. **Text Summarization** - Condense long descriptions
4. **Auto-Tag Generation** - Generate tags and categories automatically

---

## API Endpoints

### 1. Ask About Tickets (`/api/ai/ask`)

**Purpose**: Ask questions over your ticket history using Retrieval-Augmented Generation (RAG).

**Endpoint**: `POST /api/ai/ask`

**Request**:
```json
{
  "question": "Have we seen payment failures before?",
  "topK": 5,
  "similarityThreshold": 0.7
}
```

**Parameters**:
- `question` (required): Your question about tickets
- `topK` (optional, default: 5): How many relevant tickets to retrieve
- `similarityThreshold` (optional, default: 0.7): Minimum relevance score (0.0-1.0)

**Response - Success**:
```json
{
  "question": "Have we seen payment failures before?",
  "answer": "Yes, we've seen payment gateway failures. In ticket TKT-1, the customer reported...",
  "citedTickets": [1, 3],
  "relevanceScore": 0.85,
  "noMatch": false
}
```

**Response - No Match**:
```json
{
  "question": "Have we seen payment failures before?",
  "answer": null,
  "citedTickets": [],
  "relevanceScore": 0.0,
  "noMatch": true,
  "reason": "No relevant tickets found in knowledge base"
}
```

---

### 2. Sentiment Analysis (`/api/ai/sentiment`)

**Purpose**: Analyze the sentiment (mood) of customer messages or ticket descriptions.

**Endpoint**: `POST /api/ai/sentiment`

**Request**:
```json
{
  "text": "This product is amazing! I love the new features."
}
```

**Response**:
```json
{
  "text": "This product is amazing! I love the new features.",
  "sentiment": "POSITIVE",
  "confidence": 0.95,
  "explanation": "The text uses enthusiastic language like 'amazing' and 'love', indicating strong positive sentiment."
}
```

**Sentiment Values**:
- `POSITIVE` - Happy, satisfied, praising
- `NEGATIVE` - Unhappy, frustrated, critical
- `NEUTRAL` - Factual, objective, neither positive nor negative

---

### 3. Text Summarization (`/api/ai/summarize`)

**Purpose**: Create concise summaries of long ticket descriptions or customer feedback.

**Endpoint**: `POST /api/ai/summarize`

**Request**:
```json
{
  "text": "The customer reported that they tried to place an order but the payment gateway returned a timeout error. They tried 3 times with different payment methods...",
  "maxLength": 200
}
```

**Response**:
```json
{
  "originalText": "...",
  "summary": "Customer unable to complete payment due to gateway timeout errors across multiple payment methods.",
  "compressionRatio": 3.5
}
```

**Parameters**:
- `text` (required): Text to summarize
- `maxLength` (optional): Maximum length of summary in characters

**Compression Ratio**: `original_length / summary_length`. Higher = better compression.

---

### 4. Auto-Tag Generation (`/api/ai/tags`)

**Purpose**: Automatically generate relevant tags and predict ticket categories.

**Endpoint**: `POST /api/ai/tags`

**Request**:
```json
{
  "text": "User cannot login to their account after password reset",
  "maxTags": 5
}
```

**Response**:
```json
{
  "text": "User cannot login to their account after password reset",
  "tags": ["authentication", "login", "account", "password", "urgent"],
  "suggestedCategory": "Account Management"
}
```

**Parameters**:
- `text` (required): Text to analyze
- `maxTags` (optional, default: 5): Number of tags to generate

---

## UI Features

### AI Hub Interface

**Location**: Click **"🤖 AI Hub"** button in the header

**Tabs**:

#### Ask AI Tab
- Input: Text area for questions
- Controls: 
  - `topK` slider (1-20): Number of results to retrieve
  - `similarityThreshold` slider (0.0-1.0): Relevance cutoff
- Output: Formatted answer with cited ticket IDs and relevance score

#### Sentiment Tab
- Input: Text area for sentiment analysis
- Output: 
  - Emoji indicator (😊 positive, 😞 negative, 😐 neutral)
  - Sentiment label
  - Confidence percentage
  - Explanation

#### Summarize Tab
- Inputs:
  - Text area: Content to summarize
  - Max Length: Optional character limit
- Output:
  - Original text (collapsible)
  - Summary
  - Compression ratio

#### Tags Tab
- Inputs:
  - Text area: Content to analyze
  - Max Tags slider: 1-10 tags
- Output:
  - Colored tag badges
  - Suggested category

---

## Example Use Cases

### 1. Support Agent Researching a Complaint
**Scenario**: New complaint comes in about payment issues

**Process**:
1. Go to Ask AI tab
2. Ask: "What payment issues have customers reported?"
3. Review cited tickets for context
4. Use sentiment analysis on the new complaint to assess urgency
5. Use summarize to create quick reference notes

### 2. Creating a Ticket From Customer Feedback
**Scenario**: Need to create a structured ticket from long email

**Process**:
1. Copy customer message to Sentiment tab → Assess mood
2. Copy to Summarize tab → Get concise description
3. Copy to Tags tab → Get auto-generated tags
4. Create ticket with summary + sentiment + tags

### 3. Knowledge Discovery
**Scenario**: Finding similar historical issues

**Process**:
1. Go to Ask AI
2. Increase `topK` to 10 (find more results)
3. Lower `similarityThreshold` to 0.5 (less strict matching)
4. Review all cited tickets for patterns

---

## Backend Implementation Details

### Technology Stack

- **LLM**: Ollama (local, privacy-first)
- **Embedding Model**: `nomic-embed-text` (768-dimensional vectors)
- **Chat Model**: `mistral` (7B parameters, fast)
- **Vector Store**: Spring AI's SimpleVectorStore
- **Retrieval**: Cosine similarity search

### How RAG Works (Ask AI)

1. **Chunking**: Tickets + comments broken into semantic chunks
2. **Embedding**: Each chunk embedded using `nomic-embed-text`
3. **Retrieval**: Query embedded, cosine similarity search returns top-K chunks
4. **Filtering**: Chunks below `similarityThreshold` discarded
5. **Generation**: LLM generates answer from retrieved chunks + question
6. **Grounding**: Answer verified to only cite retrieved tickets (no hallucination)

### How Sentiment Works

- Uses Ollama's `mistral` model with JSON parsing
- Analyzes language patterns, word choice, emotional indicators
- Outputs structured JSON response

### How Summarization Works

- Abstractive summarization using `mistral`
- Can be constrained by `maxLength`
- Calculates compression ratio for efficiency feedback

### How Tagging Works

- JSON-based generation using `mistral`
- Extracts key concepts from text
- Predicts category based on content

---

## Configuration

### application.properties

```properties
# Ollama Configuration
spring.ai.ollama.base-url=http://localhost:11434
spring.ai.ollama.chat.model=mistral
spring.ai.ollama.embedding.model=nomic-embed-text

# RAG Parameters
app.rag.topK=5
app.rag.similarity-threshold=0.7
```

### Tuning Tips

**For better results**:
- Increase `topK` if getting too few results
- Decrease `similarityThreshold` for looser matching
- Test different threshold values (0.5 - 0.9)

---

## Frontend Components

### `/frontend/src/components/AiHub.tsx`
Main component with 4 tabs for all AI features

### `/frontend/src/services/api.ts`
API client methods:
- `aiService.ask(request)`
- `aiService.analyzeSentiment(request)`
- `aiService.summarize(request)`
- `aiService.generateTags(request)`

### `/frontend/src/types/index.ts`
TypeScript interfaces for request/response types

---

## Testing the APIs

### Using cURL

```bash
# Ask AI
curl -X POST http://localhost:8080/api/ai/ask \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What issues have we seen?",
    "topK": 5,
    "similarityThreshold": 0.7
  }'

# Sentiment
curl -X POST http://localhost:8080/api/ai/sentiment \
  -H "Content-Type: application/json" \
  -d '{"text": "I love this!"}'

# Summarize
curl -X POST http://localhost:8080/api/ai/summarize \
  -H "Content-Type: application/json" \
  -d '{"text": "Long text here...", "maxLength": 200}'

# Tags
curl -X POST http://localhost:8080/api/ai/tags \
  -H "Content-Type: application/json" \
  -d '{"text": "Login issue", "maxTags": 5}'
```

### Using the UI

1. **Start the application**: `./START.sh`
2. **Open frontend**: http://localhost:3000
3. **Click "🤖 AI Hub"** in header
4. **Try each tab**

---

## Performance Considerations

- First query is slower (model warmup)
- Ollama handles ~1-2 queries/second on 7B models
- Sentiment/Summary/Tags: ~3-5 seconds each
- Ask AI: ~5-10 seconds (includes retrieval + generation)

---

## Troubleshooting

**Q: "Network error or server unavailable"**  
A: Check if backend is running: `curl http://localhost:8080/api/tickets`

**Q: Ollama not responding**  
A: Run: `ollama serve` in another terminal

**Q: Response takes too long**  
A: Normal for 7B models. Use smaller `topK` for faster Ask AI.

**Q: Getting empty results for Ask AI**  
A: Lower `similarityThreshold` or create more tickets first (needs context)

---

## Future Enhancements

- [ ] Real-time streaming responses
- [ ] Multi-language support
- [ ] Fine-tuned models per category
- [ ] Batch operations for tags
- [ ] Caching of embeddings
- [ ] Analytics dashboard for AI feature usage
- [ ] Custom prompt templates

---

**Built with**: Spring Boot 4.1 | React 18 | Ollama | Java 25
