# AI Hub Test Data - 20 Samples Per Tab

## 📋 How to Use
1. Open http://localhost:3000
2. Click "🤖 AI Hub"
3. Copy each sample text and paste into the appropriate tab
4. Click the action button and wait for results

---

## 1️⃣ ASK AI TAB (20 Questions)

These questions will search your ticket database for relevant tickets.

```
1. "Have we seen payment failures before?"
2. "What issues have we seen with login?"
3. "Are there any database problems reported?"
4. "Have customers complained about mobile app?"
5. "What shipping issues have we encountered?"
6. "Are there any authentication problems?"
7. "Have we had performance issues?"
8. "What error messages do we see most?"
9. "Have customers reported timeout issues?"
10. "What's our most common bug report?"
11. "Are there any sync issues?"
12. "Have we seen crashes on iOS?"
13. "What validation errors are common?"
14. "Have customers had email delivery issues?"
15. "What networking problems exist?"
16. "Are there any data loss reports?"
17. "Have we seen UI glitches?"
18. "What API issues are there?"
19. "Have customers reported slow performance?"
20. "Are there any security concerns?"
```

**Note**: Ask AI works best when you have multiple tickets in the database. 
The first time may return "No relevant tickets found" if database is empty.

---

## 2️⃣ SENTIMENT TAB (20 Samples)

### Positive Feedback (5)
```
1. "Amazing product! Absolutely love it. Best purchase ever made!"
2. "Excellent support team. They resolved my issue immediately!"
3. "Outstanding quality. Exceeded all my expectations!"
4. "Fantastic service. Very professional and helpful staff!"
5. "Perfect! Everything works as promised. Highly recommend!"
```

### Negative Feedback (5)
```
6. "Terrible experience. Worst product ever. Total waste of money!"
7. "Disappointed. Poor quality. Doesn't work as advertised."
8. "Unacceptable. Broken from day one. No support whatsoever."
9. "Horrible service. They ignored my complaints completely."
10. "Worst purchase decision ever. Complete disaster!"
```

### Neutral Feedback (5)
```
11. "The product works as expected."
12. "It's okay. Nothing special but gets the job done."
13. "Average quality. Not great, not terrible."
14. "It has some features but also lacks others."
15. "Decent price. Standard functionality included."
```

### Mixed Feedback (5)
```
16. "Good product but terrible customer service."
17. "Excellent features but very complicated to use."
18. "Works well initially but started breaking after a week."
19. "I like some aspects but hate others."
20. "Decent overall but could be much better."
```

---

## 3️⃣ SUMMARIZE TAB (20 Samples)

### Short Issues (5)
```
1. "The database connection is failing randomly throughout the day. This affects about 2-3% of our users. We've been investigating for a week but haven't found the root cause yet. It happens intermittently without a clear pattern."

2. "Users are reporting that the mobile app crashes when uploading photos larger than 10MB. This works fine on the web version but fails consistently on iOS and Android. The issue started after the last update."

3. "The payment processing system is timing out for customers trying to complete checkout. This is causing cart abandonment and losing us sales. The issue appears to be on the payment gateway's end but we're still investigating."

4. "New user registration is failing for some email domains. Gmail works fine but corporate email addresses get validation errors. We need to fix the email regex pattern."

5. "The API is returning inconsistent data. Sometimes we get duplicates, sometimes we get missing fields. This is breaking our data synchronization process."
```

### Medium Issues (5)
```
6. "We've been experiencing intermittent performance issues with our search functionality. Query times have increased from 100ms to 5+ seconds on average. The database has grown significantly and we haven't optimized indexes in a while. Users are complaining about slow search results and getting frustrated. We need to investigate query performance and potentially implement caching."

7. "The password reset email feature is unreliable. Some users receive emails immediately, others wait 15+ minutes, and some never receive them at all. The emails are being generated correctly but seem to get stuck in the queue. This is causing support tickets from users locked out of their accounts."

8. "Our export to CSV feature is generating corrupted files. Users report that opening the exported CSV causes errors in Excel and other spreadsheet applications. The issue seems to affect large datasets (1000+ rows) more frequently. We need to check our CSV generation code."

9. "The mobile app's offline sync is not working properly. Changes made offline don't sync when connection is restored. Some users have lost data this way. We've added offline support but it's clearly buggy."

10. "Two-factor authentication setup is confusing users. Many abandon the setup process midway. The QR code doesn't work for some authenticator apps. Documentation is unclear about which apps are supported. Users end up calling support for help."
```

### Complex Issues (5)
```
11. "Our order processing pipeline has been experiencing severe delays and failures. When customers place orders during peak hours (8-10 AM, 2-4 PM), the system either processes them very slowly or times out entirely. This has resulted in multiple duplicate charges because users click submit multiple times. The issue appears to correlate with database load spikes. We've noticed that the connection pool is being exhausted during these times. We've temporarily increased the pool size but this is just a band-aid solution. Root cause analysis suggests our query optimization is poor and several N+1 queries are running. We've lost significant revenue and customer trust due to this issue. Additionally, some transactions are showing in our logs but not appearing in the payment processor's records, creating reconciliation issues."

12. "The file upload feature has multiple issues that are severely impacting user experience. Files above 500MB fail to upload with cryptic error messages. The progress indicator doesn't update properly, leading users to believe uploads are stuck. If network disconnects mid-upload, there's no resume capability and users have to start over. Some file types that should be supported are being rejected. Users lose hours of work when uploads fail. On mobile networks, uploads fail 30% of the time. We need a complete rewrite of the upload functionality with proper chunking, resume capability, better error messages, and progress tracking."

13. "Our customer dashboard is becoming increasingly slow as user accounts accumulate data. New users see instant load times but after 6 months of usage, dashboard load times exceed 30 seconds. This is because we're loading all historical data on page load without pagination or lazy loading. The dashboard makes 50+ API calls simultaneously which overwhelms the backend. Database queries are not indexed properly. This is causing massive support burden as customers complain about slowness. Some users with years of data have given up using the dashboard. We need to implement proper pagination, caching, and optimize queries."

14. "The email notification system is unreliable and overwhelming users. Some notifications arrive instantly, others are delayed by hours. Users receive duplicate notifications for the same event. There's no way to control notification frequency. Some users report receiving 100+ emails per day from our system. Unsubscribe links don't work properly. Users are unsubscribing from emails they actually want to receive because they can't control notification settings. This is affecting user retention."

15. "Our analytics dashboard is completely broken for large datasets. Reports for accounts with 100K+ events fail to generate. The dashboard freezes when trying to view data spanning multiple years. Custom date ranges don't work properly. Filters are ignored. There's no way to export large datasets. Users with lots of data can't use the product features they're paying for. Smaller customers have no issues. This is a scalability problem."
```

### Business Issues (5)
```
16. "We discovered a critical issue in our billing system. Some customers are being charged multiple times per day due to a race condition in our payment retry logic. We've been overcharging customers for weeks without realizing it. Customer trust is severely damaged. We need to refund affected customers and implement proper transaction locking."

17. "Our system has a data persistence issue where user edits are being lost randomly. Customers report losing hours of work. Sometimes changes save but then disappear after page refresh. The issue is intermittent which makes it hard to reproduce. Users are very upset. Preliminary investigation suggests race conditions in concurrent updates."

18. "The account deletion feature doesn't actually delete user data from our backups. Users requesting GDPR data deletion still have their info in our backup systems. This violates privacy regulations. We need a proper data deletion workflow that includes backups."

19. "Multi-currency support is broken. Exchange rates aren't updating daily. Some currencies show incorrect conversion rates. Customers in certain countries are seeing wrong prices. This is causing customer complaints and potential lost sales."

20. "Our disaster recovery plan failed during the last incident. Backup restoration took 8 hours instead of promised 1 hour RTO. Data consistency issues occurred after restore. Customer downtime was much longer than acceptable. Our backups are not being tested regularly."
```

---

## 4️⃣ TAGS TAB (20 Samples)

### Bug Reports (5)
```
1. "Application crashes when opening files larger than 1GB"

2. "Search feature returns incorrect results and shows deleted items"

3. "Mobile app freezes when processing large datasets"

4. "Login button is not responsive on Safari browser"

5. "Export function generates corrupted CSV files"
```

### Feature Requests (5)
```
6. "Request: Add dark mode theme to the application"

7. "Feature: Ability to export data in multiple formats (JSON, XML, CSV)"

8. "Need: Real-time collaboration like Google Docs"

9. "Request: Add API documentation and webhooks support"

10. "Feature: Bulk import data from CSV or Excel files"
```

### User Account Issues (5)
```
11. "User cannot reset password - reset email not received"

12. "Cannot delete account - option not visible in settings"

13. "Two-factor authentication keeps asking for code even after correct entry"

14. "Email not verified after signup - verification link expired"

15. "User account locked after failed login attempts - cannot unlock"
```

### Payment & Billing Issues (5)
```
16. "Invoice shows wrong amount - overcharged by 50%"

17. "Subscription renewal failed - payment method declined but no retry"

18. "User was charged twice for single order"

19. "Refund requested but not processed after 2 weeks"

20. "Pricing is different for same plan in different regions"
```

---

## 📊 Test Coverage Matrix

| Feature | Easy | Medium | Hard | Total |
|---------|------|--------|------|-------|
| **Ask** | 5 | 10 | 5 | 20 |
| **Sentiment** | 5 | 5 | 10 | 20 |
| **Summarize** | 5 | 5 | 10 | 20 |
| **Tags** | 5 | 5 | 10 | 20 |
| **TOTAL** | **20** | **25** | **35** | **80** |

---

## 🎯 Recommended Testing Order

### Session 1: Quick Test (15 min)
- Sentiment: Sample 1, 6, 11
- Summarize: Sample 1, 6, 11
- Tags: Sample 1, 6, 11
- Ask: Sample 1

### Session 2: Feature Deep Dive (30 min)
- Sentiment: All 20 samples
- Check accuracy and confidence levels

### Session 3: Complex Data (30 min)
- Summarize: All 20 samples (especially 11-15)
- Tags: All 20 samples
- Ask: All 20 samples (after creating tickets)

### Session 4: Edge Cases (15 min)
- Test with very short text
- Test with very long text
- Test with special characters
- Test with multiple languages (if supported)

---

## 💡 Pro Tips

1. **For Ask AI**: Create tickets first with these issues, then ask questions
2. **For Sentiment**: Notice confidence scores vary based on text clarity
3. **For Summarize**: Compare compression ratios between short/long text
4. **For Tags**: See how category prediction works for different issue types

---

## 📝 Notes

- Response times: 3-5 seconds typically
- First response may be slower (model warmup)
- All tests are safe to run - no data is persisted
- You can test multiple times with same data
- Results help you understand AI accuracy
