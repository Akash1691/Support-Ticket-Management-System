# Architecture: Support Ticket AI System

## System Components

```
┌─────────────────────┐
│   React Frontend    │
│  (Ticket UI, Ask)   │
└──────────┬──────────┘
           │ HTTP
           ▼
┌─────────────────────┐
│   Spring Boot API   │
├─────────────────────┤
│ Controllers         │
│ ├─ TicketController │
│ ├─ CommentController│
│ └─ AiController     │
│                     │
│ Services            │
│ ├─ TicketService    │
│ ├─ CommentService   │
│ ├─ IngestionService │
│ └─ AiService        │
│                     │
│ Repositories        │
│ └─ Data Access      │
└──────┬──────────────┘
       │
   ┌───┴──────────────────────────┐
   │                              │
   ▼                              ▼
┌─────────────────┐      ┌──────────────────┐
│   H2 Database   │      │  In-Memory       │
│  (Tickets,      │      │  VectorStore     │
│   Comments,     │      │  (Embeddings)    │
│   Metadata)     │      │                  │
└─────────────────┘      └────────┬─────────┘
                                  │
                         ┌────────┴─────────┐
                         │                  │
                         ▼                  ▼
                    ┌──────────────┐  ┌──────────────┐
                    │   Ollama     │  │   Ollama     │
                    │ Embeddings   │  │ Chat Model   │
                    │ (nomic-embed │  │ (mistral)    │
                    │  -text)      │  │              │
                    └──────────────┘  └──────────────┘
```

## Layer Breakdown

### Controller Layer (`controller/`)
- HTTP request → business logic → response
- Input validation via `@Valid`
- Error handling (return meaningful error DTO)
- Classes:
  - `TicketController`: CRUD + status + search/filter
  - `CommentController`: Add/list comments
  - `AiController`: POST /api/ai/ask

### Service Layer (`service/`)
- Business logic
- State machine enforcement
- Orchestration (RAG pipeline)
- Classes:
  - `TicketService`: Ticket CRUD + state transitions
  - `CommentService`: Comment management
  - `TicketIngestionService`: Ticket → embeddings
  - `AiService`: Retrieval + generation

### Repository Layer (`repository/`)
- Data access via Spring Data JPA
- Queries: TicketRepository, CommentRepository

### Entity Layer (`entity/`)
- JPA mapping
- Classes:
  - `Ticket`: id, title, description, status, priority, assignee, category, timestamps
  - `Comment`: id, ticketId, text, author, timestamp
  - `TicketEmbeddingMetadata`: id, ticketId, chunkType, embedding metadata

### RAG Layer (`rag/`)
- Embedding generation
- Chunk creation
- Vector search
- Classes:
  - `TicketChunkizer`: Ticket → chunks (semantic chunking)
  - `OllamaEmbeddingAdapter`: Wrap Ollama embedding model
  - `VectorStoreAdapter`: Wrap Spring AI VectorStore
  - `RetrievalService`: Similarity search

### DTO Layer (`dto/`)
- Request/response objects
- Classes:
  - `TicketRequest`, `TicketResponse`, `TicketDetailResponse`
  - `CommentRequest`, `CommentResponse`
  - `StatusChangeRequest`
  - `AskRequest`, `AskResponse`
  - `ErrorResponse`

### Exception Layer (`exception/`)
- Custom exceptions
- Classes:
  - `TicketNotFoundException`
  - `InvalidStateTransitionException`
  - `ValidationException`

### Config Layer (`config/`)
- Spring AI config
- VectorStore bean
- EmbeddingModel bean
- RAG properties bean

## Data Flow: Ticket Creation

```
1. UI: POST /api/tickets {title, description, ...}
   ↓
2. TicketController: validate input
   ↓
3. TicketService: createTicket()
   ├─ save to DB (status=OPEN)
   └─ publish TicketCreatedEvent
   ↓
4. TicketIngestionService (event listener): ingestTicket(ticketId)
   ├─ fetch ticket + comments
   ├─ TicketChunkizer: create chunks
   ├─ OllamaEmbedding: generate embeddings
   └─ VectorStore: store chunks + embeddings
   ↓
5. UI: receive TicketResponse
```

## Data Flow: RAG Question

```
1. UI: POST /api/ai/ask {question, topK=5, threshold=0.7}
   ↓
2. AiController: validate input
   ↓
3. AiService: askQuestion()
   ├─ RetrievalService.search(question, topK, threshold)
   │  ├─ OllamaEmbedding: embed question
   │  ├─ VectorStore: cosine similarity search
   │  └─ return chunks where score >= threshold
   ├─ if no chunks found:
   │  └─ return {answer: "", noMatch: true, reason: "No relevant tickets"}
   ├─ else:
   │  ├─ format retrieved chunks as context
   │  ├─ OllamaChat: generate answer from context
   │  ├─ extract cited ticket IDs
   │  └─ return {answer, citedTickets, relevanceScore}
   ↓
4. UI: display answer + sources
```

## Data Flow: State Transition

```
1. UI: PATCH /api/tickets/1/status {newStatus: IN_PROGRESS}
   ↓
2. TicketController: validate state machine
   ├─ fetch current ticket
   ├─ call StateMachine.isValidTransition(current, newStatus)
   ├─ if invalid: throw InvalidStateTransitionException
   ├─ else: TicketService.updateStatus()
   └─ log transition
   ↓
3. TicketService: updateStatus()
   ├─ update DB
   └─ trigger TicketUpdatedEvent
   ↓
4. TicketIngestionService: re-ingest ticket (update embeddings)
   ↓
5. UI: receive TicketResponse (new status)
```

## Technology Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18 + TypeScript |
| Backend | Spring Boot 4.1.1 + Spring AI 2.0.1 |
| Database | H2 (in-memory/file) |
| Vector Store | Spring AI in-memory VectorStore |
| Embeddings | Ollama + nomic-embed-text |
| LLM | Ollama + mistral |
| ORM | Spring Data JPA + Lombok |
| Testing | JUnit 5 + Mockito |

## Scaling Considerations

### Current (MVP)
- Single Spring Boot instance
- H2 file-based DB
- In-memory VectorStore
- Ollama local

### Future (if needed)
- Postgres + PGVector (replace H2 + in-memory)
- Ollama as service (could scale separately)
- Cache layer (Redis) for frequent questions
- Async ingestion (Kafka) if ticket volume high
