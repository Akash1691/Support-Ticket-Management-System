# RAG Strategy & Justification

## Problem Statement
Build a grounded Q&A system over ticket history. Questions like "Have we seen payment failures?" must:
1. Return answers backed by real tickets (not fabricated)
2. Cite ticket IDs as sources
3. Explicitly say "no match" if not found

## Solution: Retrieval-Augmented Generation (RAG)

### Why RAG?
- **Grounding**: LLM generates answer using only retrieved context
- **Traceability**: Cite exact ticket sources
- **Honesty**: "No match" is explicit, not hallucinated
- **Cost**: Local Ollama eliminates API costs
- **Privacy**: All data stays local

---

## Chunking Strategy

### Approach: Semantic Chunks by Ticket Section

**Rationale**:
- Tickets are structured, bounded objects (not unstructured text)
- Preserving semantic sections improves retrieval quality
- Fixed-size chunking loses context (comments are threads, not independent)
- Overlap not needed (each section self-contained)

### Chunk Types

#### 1. Description Chunk
**From**: Ticket title + description

**Example**:
```
Ticket TKT-1: Payment Processing Fails
Description: Customers unable to complete payment. Error 503 returned at checkout.
Category: Payment
Priority: CRITICAL
Status: OPEN
Assignee: support-team
```

**Metadata**:
```json
{
  "ticketId": 1,
  "chunkType": "DESCRIPTION",
  "status": "OPEN",
  "priority": "CRITICAL",
  "category": "Payment",
  "createdAt": "2024-01-15T10:30:00Z"
}
```

#### 2. Comment Chunks
**From**: Each comment thread

**Example**:
```
TKT-1 Comment by john@company.com:
Reproduced the issue. Server logs show payment gateway timeout. Root cause: timeout set to 5s, avg payment auth takes 8s.
```

**Metadata**:
```json
{
  "ticketId": 1,
  "chunkType": "COMMENT",
  "author": "john@company.com",
  "status": "OPEN",
  "createdAt": "2024-01-15T11:00:00Z"
}
```

#### 3. Resolution Chunk (Optional)
**From**: Final resolution notes (if added)

**Example**:
```
TKT-1 Resolution:
Issue resolved by increasing payment gateway timeout from 5s to 12s in config. No further issues reported. Closed 2024-01-16.
```

**Metadata**:
```json
{
  "ticketId": 1,
  "chunkType": "RESOLUTION",
  "status": "CLOSED",
  "resolvedAt": "2024-01-16T14:30:00Z"
}
```

### Why Not Fixed-Size Chunks?
- Ticket description (500 chars) + comments (2000 chars) have varying info density
- Splitting description mid-sentence loses coherence
- Comments as individual chunks preserves conversation flow
- Section-level chunks map naturally to ticket structure

---

## Embedding Model: Ollama + nomic-embed-text

### Choice Justification

| Factor | Ollama nomic-embed-text | OpenAI text-embedding-3 | Alternatives |
|--------|------------------------|------------------------|--------------|
| **Cost** | Free (local) | $0.02/1M tokens | PaLM, Cohere (paid) |
| **Privacy** | 100% local | Cloud-hosted | Good |
| **Latency** | <100ms | 200-500ms | Similar |
| **Quality** | 768 dims, SOTA for support domain | 3072 dims, high | Sentence-BERT (good) |
| **Dependencies** | Ollama Docker | API key required | Extra setup |
| **Reproducibility** | Same hardware = same results | Closed-box | Hard to guarantee |

### Model Details
- **nomic-embed-text**:
  - Trained on 240M documents (web + code + support docs)
  - 768 dimensions (vs 3072 for OpenAI)
  - Symmetric (good for retrieval)
  - Fast on CPU

### Configuration
```properties
spring.ai.ollama.embedding.model=nomic-embed-text
spring.ai.ollama.base-url=http://localhost:11434
```

---

## Vector Store: Spring AI In-Memory (Phase 1) → PGVector (Phase 2)

### Phase 1: In-Memory VectorStore (MVP)
**Why**:
- H2 is in-memory, no Postgres
- Spring AI provides simple in-memory store
- Good for testing + small datasets (<50k tickets)
- Embeddings re-indexed on app startup

**Trade-offs**:
- Lost on app restart (not persisted)
- No distributed queries
- Single-instance only

**Code**:
```java
@Bean
VectorStore vectorStore(EmbeddingModel embeddingModel) {
    return new SimpleVectorStore(embeddingModel);
}
```

### Phase 2: PGVector (if needed)
**When**:
- Prod deployment needs persistence
- Embedding count > 100k
- Distributed system

**Swap**:
- Replace H2 with Postgres
- Use `spring-ai-starter-vector-store-pgvector`
- Same API (Spring AI abstracts it)

---

## Retrieval Tuning Parameters

### Top-K (Default: 5)
**Meaning**: Return top 5 most similar chunks

**Rationale**:
- 5 chunks = ~2-3 tickets (considering multiple chunks per ticket)
- Enough context for answer, not overwhelming
- Configurable per request

### Similarity Threshold (Default: 0.7)
**Meaning**: Only return chunks with cosine similarity ≥ 0.7

**Rationale**:
- 0.7 = moderately related (not exact, not weak)
- Prevents false positives ("no match" if threshold not met)
- Tunable based on strictness

**Examples**:
- Threshold 0.5: permissive (many results, lower quality)
- Threshold 0.7: balanced (our default)
- Threshold 0.85: strict (only high-confidence)

**Config**:
```properties
rag.retrieval.topK=5
rag.retrieval.similarityThreshold=0.7
```

### Configurable in Request
```json
{
  "question": "...",
  "topK": 10,
  "similarityThreshold": 0.8
}
```

---

## Ingestion Pipeline

### On Ticket Create
1. Save ticket to DB (status=OPEN)
2. Fire `TicketCreatedEvent`
3. `TicketIngestionService` (event listener) runs:
   - Fetch ticket from DB
   - `TicketChunkizer.chunkify()`: create Description chunk
   - Generate embeddings via Ollama
   - Store in VectorStore
4. Done (comments added later)

### On Comment Add
1. Save comment to DB
2. Fire `CommentAddedEvent`
3. `TicketIngestionService` runs:
   - Fetch comment from DB
   - `TicketChunkizer.chunkify()`: create Comment chunk
   - Generate embedding
   - Store in VectorStore
4. Done

### On Ticket Update
1. Update DB fields
2. Fire `TicketUpdatedEvent`
3. `TicketIngestionService` runs:
   - Delete old chunks for this ticket
   - Fetch updated ticket + all comments
   - Re-chunk + re-embed
   - Store new chunks in VectorStore
4. Done

**Why re-ingest on update?**
- Prevent stale embeddings
- New description may match different questions
- Cheap operation (local Ollama)

---

## Grounding & Guardrails

### Flow
1. **Retrieve**: Embed question, search VectorStore
   ```
   question → Ollama embedding → cosine similarity search → chunks
   ```

2. **Check**: If no chunks ≥ threshold:
   ```json
   {
     "noMatch": true,
     "reason": "No relevant tickets found",
     "answer": null,
     "citedTickets": []
   }
   ```

3. **Context**: Format retrieved chunks + metadata:
   ```
   Context:
   [TKT-1] Payment Processing Fails - CRITICAL
   Description: Customers unable to complete payment...
   Comment: Reproduced the issue. Server logs show payment gateway timeout.
   ```

4. **Generate**: Send to Ollama Chat with system prompt:
   ```
   System: You are a support assistant. Answer ONLY from the provided context.
   Do not use general knowledge. If the context doesn't address the question, say "I don't have enough information."
   
   Context:
   [context above]
   
   Question: Have we seen payment failures before?
   ```

5. **Extract**: Parse answer, identify cited ticket IDs from context:
   ```json
   {
     "answer": "Yes, in TKT-1, customers...",
     "citedTickets": [1],
     "relevanceScore": 0.89,
     "noMatch": false
   }
   ```

### Hallucination Detection
**What we check**:
- Answer mentions ticket ID → verify it exists in citedTickets
- Answer claims fact → must appear in retrieved context
- Answer says "I don't know" → valid even if not in context

**What we log**:
- All questions + answers + scores
- Hallucination detections
- Metrics: hit rate, avg relevance, false positives

---

## LLM for Generation: Ollama + mistral

### Choice Justification
| Factor | Mistral | Llama2 | Neural-Chat |
|--------|---------|--------|-------------|
| **Instruction-tuned** | Yes (good for Q&A) | Yes | Yes (excellent) |
| **Size** | 7B (fast) | 7B/13B | 7B |
| **Quality** | SOTA for 7B | Good | Excellent (finetune) |
| **Latency** | <2s per answer | <2s | <2s |
| **Cost** | Free | Free | Free |

**Selected**: Mistral (balance of speed + quality)

**Config**:
```properties
spring.ai.ollama.chat.model=mistral
spring.ai.ollama.base-url=http://localhost:11434
```

---

## Monitoring & Observability

### Metrics to Track
1. **Retrieval Quality**:
   - Hit rate: % of questions with ≥1 relevant chunk
   - Avg relevance score (cosine similarity)
   - False positive rate (user says answer is wrong)

2. **Generation Quality**:
   - Hallucination rate: % of answers citing non-retrieved tickets
   - Answer length (word count)
   - Latency (time to generate)

3. **System Health**:
   - Ollama uptime
   - Embedding generation latency
   - Vector search latency

### Logging
```java
log.info("RAG Question: {} | Hits: {} | Score: {} | Cited: {}",
    question, hits.size(), avgScore, citedTickets);
```

---

## Re-ingestion & Freshness

### When to Re-ingest
- Ticket created ✓
- Ticket updated (title, description, priority, assignee) ✓
- Comment added ✓
- Comment deleted ✓
- Ticket status changed (update metadata only)

### Implementation
```java
@EventListener
public void onTicketUpdated(TicketUpdatedEvent event) {
    Long ticketId = event.getTicketId();
    
    // Delete old chunks
    vectorStore.delete(getChunkIds(ticketId));
    
    // Re-chunk + embed + store
    Ticket ticket = ticketRepository.findById(ticketId).orElseThrow();
    List<Document> chunks = chunkizer.chunkify(ticket);
    vectorStore.add(chunks);
    
    log.info("Re-ingested ticket {}", ticketId);
}
```

---

## Example: Question → Answer Flow

### Input
```json
{
  "question": "Have we seen payment failures before?",
  "topK": 5,
  "similarityThreshold": 0.7
}
```

### Retrieval
1. Embed: "have we seen payment failures before?" → 768-dim vector
2. Search: find top 5 chunks with sim ≥ 0.7
3. Results:
   - TKT-1 Description (sim: 0.89) — "Payment processing fails at checkout"
   - TKT-1 Comment (sim: 0.85) — "payment gateway timeout"
   - TKT-5 Description (sim: 0.72) — "Refund request for failed payment"

### Context
```
[TKT-1] Payment Processing Fails - CRITICAL - RESOLVED
Description: Customers unable to complete payment. Error 503 returned at checkout.
Comment: Reproduced the issue. Server logs show payment gateway timeout. Root cause: timeout set to 5s, avg auth takes 8s.

[TKT-5] Refund Request for Failed Payment - MEDIUM - RESOLVED
Description: Customer requested refund after payment failure. Issue was related to TKT-1 incident.
```

### Generation
```
System: Answer only from the provided context.

Context:
[as above]

Question: Have we seen payment failures before?
```

### Output
```json
{
  "question": "Have we seen payment failures before?",
  "answer": "Yes, we have encountered payment failures. In ticket TKT-1, customers were unable to complete payment with Error 503 at checkout. The root cause was a payment gateway timeout (timeout set to 5s but authentication takes ~8s). This was also related to refund issues in ticket TKT-5.",
  "citedTickets": [1, 5],
  "relevanceScore": 0.82,
  "noMatch": false,
  "reason": null
}
```

---

## Testing Strategy

### Unit Tests
- Chunkization: ticket → correct chunks
- Embedding: chunk → 768-dim vector (mocked Ollama)
- Similarity search: query → top-K results (mocked VectorStore)

### Integration Tests
- Ingest pipeline: create ticket → chunks stored
- Retrieval: question → chunks with metadata
- Grounding: answer cites only retrieved tickets

### Acceptance Tests
- Q&A examples (see examples above)
- "No match" case: question with no relevant tickets
- Hallucination detection: answer doesn't cite out-of-context facts

---

## Fallback & Error Handling

### Ollama Down
- **Embedding**: return error "Embedding service unavailable"
- **Chat**: return error "AI service unavailable"
- **No fallback to OpenAI** (user specified Ollama only)

### No Embeddings
- **First startup**: embeddings not yet generated
- **Response**: return explicit "Knowledge base not yet indexed. Please create tickets first."

### Retrieval No Match
- **Return**: `{noMatch: true, reason: "No relevant tickets found"}`
- **Not**: generic LLM answer

---

## Timeline
- **Week 1**: Phase 1-3 (CRUD + state machine)
- **Week 2**: Phase 4 (RAG pipeline)
- **Week 3**: Phase 5-6 (Frontend + testing)
