# API Contract

## Base Path
`http://localhost:8080/api`

---

## Ticket Endpoints

### POST /api/tickets - Create Ticket
**Request**
```json
{
  "title": "Payment processing fails at checkout",
  "description": "Customers unable to complete payment. Error 503 returned.",
  "priority": "CRITICAL",
  "category": "Payment"
}
```

**Response (201 Created)**
```json
{
  "id": 1,
  "title": "Payment processing fails at checkout",
  "description": "Customers unable to complete payment. Error 503 returned.",
  "status": "OPEN",
  "priority": "CRITICAL",
  "category": "Payment",
  "assignee": null,
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:30:00Z"
}
```

**Error (400 Bad Request)**
```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "status": 400,
  "error": "BadRequest",
  "message": "Title is required",
  "path": "/api/tickets"
}
```

---

### GET /api/tickets - List Tickets
**Query Parameters**
- `page=0` (default: 0)
- `size=20` (default: 20)
- `status=OPEN` (optional: filter)
- `priority=CRITICAL` (optional: filter)
- `search=payment` (optional: search title/description)

**Request**
```
GET /api/tickets?page=0&size=20&status=OPEN
```

**Response (200 OK)**
```json
{
  "content": [
    {
      "id": 1,
      "title": "Payment processing fails",
      "description": "...",
      "status": "OPEN",
      "priority": "CRITICAL",
      "assignee": null,
      "category": "Payment",
      "createdAt": "2024-01-15T10:30:00Z",
      "updatedAt": "2024-01-15T10:30:00Z"
    }
  ],
  "totalElements": 42,
  "totalPages": 3,
  "currentPage": 0,
  "pageSize": 20
}
```

---

### GET /api/tickets/{id} - Get Ticket Detail
**Request**
```
GET /api/tickets/1
```

**Response (200 OK)**
```json
{
  "id": 1,
  "title": "Payment processing fails at checkout",
  "description": "Customers unable to complete payment. Error 503 returned.",
  "status": "OPEN",
  "priority": "CRITICAL",
  "assignee": null,
  "category": "Payment",
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:30:00Z",
  "comments": [
    {
      "id": 1,
      "author": "john@company.com",
      "text": "Reproduced the issue. Server logs show payment gateway timeout.",
      "createdAt": "2024-01-15T11:00:00Z"
    }
  ]
}
```

**Error (404 Not Found)**
```json
{
  "timestamp": "2024-01-15T10:35:00Z",
  "status": 404,
  "error": "NotFound",
  "message": "Ticket 999 not found",
  "path": "/api/tickets/999"
}
```

---

### PUT /api/tickets/{id} - Update Ticket
**Request**
```json
{
  "title": "Payment processing issue - partially resolved",
  "description": "Customers unable to complete payment...",
  "priority": "HIGH",
  "assignee": "jane@company.com"
}
```

**Response (200 OK)**
```json
{
  "id": 1,
  "title": "Payment processing issue - partially resolved",
  "description": "...",
  "status": "OPEN",
  "priority": "HIGH",
  "assignee": "jane@company.com",
  "category": "Payment",
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:45:00Z"
}
```

---

### PATCH /api/tickets/{id}/status - Change Status
**Request**
```json
{
  "newStatus": "IN_PROGRESS"
}
```

**Response (200 OK)**
```json
{
  "id": 1,
  "title": "Payment processing fails",
  "status": "IN_PROGRESS",
  "priority": "CRITICAL",
  "updatedAt": "2024-01-15T10:50:00Z"
}
```

**Error (409 Conflict - Invalid Transition)**
```json
{
  "timestamp": "2024-01-15T10:51:00Z",
  "status": 409,
  "error": "InvalidStateTransition",
  "message": "Cannot transition from CLOSED to OPEN",
  "path": "/api/tickets/1/status"
}
```

---

## Comment Endpoints

### POST /api/tickets/{ticketId}/comments - Add Comment
**Request**
```json
{
  "text": "Increased timeout threshold in config. Testing fix.",
  "author": "jane@company.com"
}
```

**Response (201 Created)**
```json
{
  "id": 2,
  "ticketId": 1,
  "text": "Increased timeout threshold in config. Testing fix.",
  "author": "jane@company.com",
  "createdAt": "2024-01-15T12:15:00Z"
}
```

---

### GET /api/tickets/{ticketId}/comments - List Comments
**Request**
```
GET /api/tickets/1/comments
```

**Response (200 OK)**
```json
{
  "comments": [
    {
      "id": 1,
      "author": "john@company.com",
      "text": "Reproduced the issue...",
      "createdAt": "2024-01-15T11:00:00Z"
    },
    {
      "id": 2,
      "author": "jane@company.com",
      "text": "Increased timeout threshold...",
      "createdAt": "2024-01-15T12:15:00Z"
    }
  ]
}
```

---

## RAG Endpoint

### POST /api/ai/ask - Ask Question
**Request**
```json
{
  "question": "What have we seen payment failures before?",
  "topK": 5,
  "similarityThreshold": 0.7
}
```

**Response (200 OK - Match Found)**
```json
{
  "question": "Have we seen payment failures before?",
  "answer": "Yes, we have encountered payment failures. In ticket TKT-1, customers were unable to complete payment with Error 503. The issue was caused by a payment gateway timeout, which was resolved by increasing the timeout threshold in configuration.",
  "citedTickets": [1],
  "relevanceScore": 0.89,
  "noMatch": false,
  "reason": null
}
```

**Response (200 OK - No Match)**
```json
{
  "question": "What color is the office building?",
  "answer": null,
  "citedTickets": [],
  "relevanceScore": 0.0,
  "noMatch": true,
  "reason": "No relevant tickets found in knowledge base"
}
```

**Error (400 Bad Request)**
```json
{
  "timestamp": "2024-01-15T10:52:00Z",
  "status": 400,
  "error": "BadRequest",
  "message": "Question is required",
  "path": "/api/ai/ask"
}
```

---

## Global Error Format
All errors follow this structure:
```json
{
  "timestamp": "ISO-8601",
  "status": HTTP_STATUS_CODE,
  "error": "ErrorType",
  "message": "Human-readable message",
  "path": "/api/endpoint"
}
```

Status Codes:
- 200: OK
- 201: Created
- 400: Bad Request (validation)
- 404: Not Found
- 409: Conflict (state machine)
- 500: Internal Server Error
