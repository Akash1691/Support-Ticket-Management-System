# Implementation Plan: Phases & Milestones

## Phase 1: Foundation 
✓ Specification (requirements, architecture, data-model, api-contract, rag-strategy)
✓ Cursor rules + guidelines
- [ ] Update pom.xml: remove OpenAI, keep Ollama + PGVector
- [ ] Configure H2 schema (Ticket, Comment, TicketEmbeddingMetadata)
- [ ] application.properties: Ollama config

**Deliverable**: Spring Boot boots, H2 schema ready, Ollama connectivity verified

---

## Phase 2: Ticket CRUD 

### Entities
- [ ] `Ticket` entity (id, title, description, status, priority, category, assignee, timestamps)
- [ ] `Comment` entity (id, ticketId, text, author, timestamp)
- [ ] `TicketEmbeddingMetadata` entity (id, ticketId, chunkType, embeddingId)

### Repositories
- [ ] `TicketRepository extends JpaRepository<Ticket, Long>`
- [ ] `CommentRepository extends JpaRepository<Comment, Long>`

### Services
- [ ] `TicketService`: create, list, findById, update, delete
- [ ] `CommentService`: addComment, listComments

### Controllers
- [ ] `TicketController`: POST/GET/PUT /api/tickets, GET /api/tickets/{id}
- [ ] `CommentController`: POST/GET /api/tickets/{id}/comments

### DTOs
- [ ] `TicketRequest`, `TicketResponse`, `TicketDetailResponse`
- [ ] `CommentRequest`, `CommentResponse`
- [ ] `ErrorResponse`

### Testing
- [ ] Unit tests: TicketService, CommentService
- [ ] Integration tests: TicketController, CommentController
- [ ] Happy path + error cases (404, validation)

**Deliverable**: Full CRUD works end-to-end (UI ← → API ← → DB)

---

## Phase 3: State Machine

### State Machine Logic
- [ ] `TicketStatus` enum (OPEN, IN_PROGRESS, RESOLVED, CLOSED, CANCELLED)
- [ ] `StateMachine` class: `isValidTransition(from, to): boolean`
- [ ] Valid transitions enforced in TicketService
- [ ] Invalid transitions throw `InvalidStateTransitionException`

### Endpoint
- [ ] `PATCH /api/tickets/{id}/status` → StatusChangeRequest
- [ ] Log all transitions

### Testing
- [ ] Unit tests: all valid transitions pass
- [ ] Unit tests: all invalid transitions fail
- [ ] Integration tests: endpoint rejects invalid requests (409 Conflict)

**Deliverable**: State machine enforced end-to-end, all invalid transitions blocked

---

## Phase 4: Search & Filter

### Features
- [ ] Search by keyword (title, description, comment text)
- [ ] Filter by status
- [ ] Filter by priority
- [ ] Filter by assignee
- [ ] Pagination (page, size)

### Endpoint
- [ ] `GET /api/tickets?search=payment&status=OPEN&page=0&size=20`

### Repository Queries
- [ ] TicketRepository: custom queries for search + filter

### Testing
- [ ] Search: finds tickets by keyword
- [ ] Filter: returns only matching status/priority
- [ ] Pagination: correct page + totalPages

**Deliverable**: Search + filter working, pagination correct

---

## Phase 5: RAG Pipeline
### Chunking
- [ ] `TicketChunkizer`: ticket → chunks (Description, Comment, Resolution)
- [ ] Metadata included in each chunk

### Embedding Model Config
- [ ] `@Bean EmbeddingModel`: Ollama nomic-embed-text adapter
- [ ] Test connectivity to Ollama

### Vector Store Config
- [ ] `@Bean VectorStore`: Spring AI in-memory VectorStore
- [ ] Test storage + retrieval

### Ingestion Service
- [ ] `TicketIngestionService`: chunk → embed → store
- [ ] Event listeners:
  - `onTicketCreated(TicketCreatedEvent)`: ingest description
  - `onCommentAdded(CommentAddedEvent)`: ingest comment
  - `onTicketUpdated(TicketUpdatedEvent)`: delete old chunks, re-ingest all

### AI Service
- [ ] `AiService`: retrieve + generate
- [ ] `RetrievalService`: similarity search w/ topK + threshold

### Endpoint
- [ ] `POST /api/ai/ask` → AskRequest
- [ ] Response: answer + citedTickets + relevanceScore + noMatch flag

### Testing
- [ ] Unit tests: chunkization (mocked embedding)
- [ ] Unit tests: retrieval (mocked VectorStore)
- [ ] Integration tests: full RAG flow
  - Create ticket → embed → retrieve → generate answer
  - "No match" case: question with no relevant tickets
  - Grounding: answer cites only retrieved tickets

**Deliverable**: RAG endpoint works, answers grounded, no hallucinations detected

---

## Phase 6: Frontend

### Ticket List
- [ ] List tickets with search + filter
- [ ] Pagination controls
- [ ] Link to detail

### Ticket Detail
- [ ] Show ticket + comments
- [ ] Update fields
- [ ] Change status (with validation UI)
- [ ] Add comment

### Ticket Create
- [ ] Form: title, description, priority, category
- [ ] Validation feedback
- [ ] Redirect to detail

### Ask Question
- [ ] Input question
- [ ] Show answer + cited tickets
- [ ] Link to cited tickets
- [ ] "No match" handling

### Error Handling
- [ ] Display backend error messages
- [ ] 404 → "Ticket not found"
- [ ] 409 → "Invalid status transition"
- [ ] Validation errors → highlight fields

**Tech**: React 18 + TypeScript + Axios
**Deliverable**: Full UI functional, all flows clickable

---

## Phase 7: Testing & Polish

### Unit Test Coverage
- [ ] Services: 80%+
- [ ] State machine: 100%
- [ ] Chunization: 85%
- [ ] Retrieval: 85%

### Integration Tests
- [ ] Full CRUD flow
- [ ] State machine enforcement
- [ ] RAG pipeline (ingest + retrieval + generation)

### E2E Tests
- [ ] Create ticket → search → ask question → see answer

### Documentation
- [ ] README: setup, run, config Ollama
- [ ] API docs: OpenAPI/Swagger
- [ ] RAG docs: chunking strategy, embedding model justification
- [ ] Prompt history: all decisions logged

### Cleanup
- [ ] Remove debug logs
- [ ] No secrets in git
- [ ] .gitignore: /target, .env, *.log

**Deliverable**: High coverage, all acceptance criteria met, documented

---

## Acceptance Criteria Checklist

### Core Features
- [ ] Ticket CRUD (create, list, detail, update, delete)
- [ ] Comments (add, list)
- [ ] State machine (valid transitions enforced, invalid rejected)
- [ ] Search (by keyword)
- [ ] Filter (by status, priority, category)
- [ ] Data persistence (survives restart)

### RAG
- [ ] Embeddings generated on ticket create/update
- [ ] `/api/ai/ask` returns grounded answer
- [ ] Answer cites specific ticket IDs
- [ ] "No match" case handled (no fabrication)
- [ ] Retrieval parameters (topK, threshold) configurable

### Quality
- [ ] Backend validation (all inputs validated)
- [ ] UI shows meaningful errors
- [ ] No secrets in repo
- [ ] State machine tests pass
- [ ] RAG grounding tests pass
- [ ] Chunking strategy documented
- [ ] Embedding model choice documented + justified
- [ ] Re-ingestion on update (embeddings fresh)
- [ ] Hallucination detection logged

### Ollama Integration
- [ ] Ollama selected (not OpenAI)
- [ ] Config in application.properties
- [ ] Docker setup for Ollama documented
- [ ] Embedding model: nomic-embed-text
- [ ] Chat model: mistral
- [ ] No OpenAI dependencies in pom

---

## Branch Strategy
- `main`: stable, released
- `feature/*`: feature branches
- Each feature → PR → review → test → merge

## Git Commits
- Conventional Commits: `feat:`, `fix:`, `test:`, `docs:`
- Atomic commits: one logical change per commit
- Save all prompts to `.specstory/history/`
