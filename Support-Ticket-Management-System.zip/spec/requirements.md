# Requirements: AI-Powered Support Ticket Management System

## Overview
Build a support ticket system w/ REST API + React UI + RAG-based AI question-answering grounded in ticket history.

## Functional Requirements

### 1. Ticket Management (CRUD)
- **Create**: Title, description, priority, category
- **List**: All tickets w/ pagination + filtering
- **View**: Full ticket detail
- **Update**: Title, description, priority, assignee
- **Status**: State machine transition (OPEN → IN_PROGRESS → RESOLVED → CLOSED, OPEN → CANCELLED, IN_PROGRESS → CANCELLED)
- **Search**: By keyword (title, description, comments)
- **Filter**: By status, priority, assignee, category

### 2. Comments
- Add comment to ticket
- List comments on ticket
- Each comment has: text, author, timestamp

### 3. State Machine
Enforce valid transitions at backend:
```
OPEN  ──→  IN_PROGRESS  ──→  RESOLVED  ──→  CLOSED
 ↓                               ↓
CANCELLED (from OPEN or IN_PROGRESS only)

Invalid:
- CLOSED → OPEN ❌
- RESOLVED → OPEN ❌
- CANCELLED → OPEN ❌
- IN_PROGRESS → OPEN ❌
- RESOLVED → IN_PROGRESS ❌
```

### 4. RAG Question-Answering
- Endpoint: `POST /api/ai/ask`
- Input: natural language question
- Output: grounded answer w/ cited ticket IDs
- Scope: support ticket history only
- **Guardrail**: If no relevant tickets → return "no match", not fabricated answer

### 5. Data Persistence
- H2 database (in-memory for dev/test, file-based for prod)
- Survive application restart
- Schema: Tickets, Comments, Embeddings metadata

## Non-Functional Requirements

### Performance
- List 1000 tickets in <1s
- Search in <500ms
- RAG retrieval + generation in <5s

### Validation
- Backend: all input validation
- UI: form validation + error display

### Security
- No secrets committed (Ollama URL, API keys)
- Use environment variables for config

### Observability
- Log all state transitions
- Log RAG retrieval quality (hit rate, scores)
- Log any hallucinations detected

### Testing
- Unit tests: services, state machine
- Integration tests: controller + DB
- RAG tests: retrieval quality, grounding

## Acceptance Criteria (MVP)
- [ ] Ticket CRUD works end-to-end (UI → API → DB)
- [ ] State machine enforced (invalid transitions rejected)
- [ ] Comments can be added
- [ ] Search + filter work
- [ ] Embeddings generated on ticket create/update
- [ ] `/api/ai/ask` returns grounded answers w/ ticket citations
- [ ] "No match" case handled explicitly (no fabrication)
- [ ] All data persists after restart
- [ ] Backend validation + meaningful error messages in UI
- [ ] State machine integration tests pass
- [ ] RAG grounding tests pass (answer only uses retrieved context)
- [ ] Chunking strategy documented
- [ ] Embedding model choice documented + justified
- [ ] Retrieval params (top-K, threshold) configurable
- [ ] Re-ingestion on ticket update (embeddings stay fresh)

## Out of Scope
- Multi-user auth/permissions
- Autonomous agent (no chaining, no independent actions)
- Notifications
- Integrations (Slack, email)
- Advanced analytics
