# Data Model

## Entities

### Ticket
```sql
CREATE TABLE ticket (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  status VARCHAR(50) NOT NULL DEFAULT 'OPEN',
  priority VARCHAR(50) NOT NULL DEFAULT 'MEDIUM',
  assignee VARCHAR(255),
  category VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

**Enum: TicketStatus**
- OPEN
- IN_PROGRESS
- RESOLVED
- CLOSED
- CANCELLED

**Enum: Priority**
- LOW
- MEDIUM
- HIGH
- CRITICAL

**Relationships**
- One Ticket → Many Comments (1:N)
- One Ticket → Many TicketEmbeddingMetadata (1:N)

### Comment
```sql
CREATE TABLE comment (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  ticket_id BIGINT NOT NULL,
  text TEXT NOT NULL,
  author VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES ticket(id) ON DELETE CASCADE
);
```

**Relationships**
- Many Comments → One Ticket (N:1)

### TicketEmbeddingMetadata
Metadata only (embeddings stored in VectorStore separately).

```sql
CREATE TABLE ticket_embedding_metadata (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  ticket_id BIGINT NOT NULL,
  chunk_type VARCHAR(50), -- 'DESCRIPTION', 'COMMENT', 'RESOLUTION'
  embedding_id VARCHAR(255), -- ID in VectorStore
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES ticket(id) ON DELETE CASCADE
);
```

## VectorStore Schema (In-Memory, Spring AI)

Each document in store:
```
{
  id: "ticket-1-description",
  content: "Ticket TKT-1: Payment Processing Error\nDescription: Customer payment fails at checkout with 503 error\nCategory: Payment\nPriority: CRITICAL",
  metadata: {
    ticketId: 1,
    chunkType: "DESCRIPTION",
    status: "OPEN",
    priority: "CRITICAL",
    category: "Payment",
    createdAt: "2024-01-15T10:30:00Z"
  }
}
```

Stored in-memory. On app restart, re-indexed from tickets table.

## Indexes

```sql
CREATE INDEX idx_ticket_status ON ticket(status);
CREATE INDEX idx_ticket_priority ON ticket(priority);
CREATE INDEX idx_ticket_assignee ON ticket(assignee);
CREATE INDEX idx_ticket_category ON ticket(category);
CREATE INDEX idx_comment_ticket_id ON comment(ticket_id);
CREATE INDEX idx_embedding_ticket_id ON ticket_embedding_metadata(ticket_id);
```

## Uniqueness & Constraints

- Ticket.id: unique PK
- Comment.id: unique PK
- No natural keys (id is synthetic)
- Cascade delete: Ticket delete → Comment + TicketEmbeddingMetadata

## State Machine Invariants

Valid transitions:
- OPEN → IN_PROGRESS
- OPEN → CANCELLED
- IN_PROGRESS → RESOLVED
- IN_PROGRESS → CANCELLED
- RESOLVED → CLOSED

Invalid transitions (enforce in service):
- CLOSED → any (terminal state)
- CANCELLED → any (terminal state)
- RESOLVED → OPEN, IN_PROGRESS
- IN_PROGRESS → OPEN
- OPEN → RESOLVED, CLOSED (must go through IN_PROGRESS)

## Example Data

### Ticket
```
id: 1
title: "Payment processing fails at checkout"
description: "Customers unable to complete payment. Error 503 returned."
status: OPEN
priority: CRITICAL
assignee: "support-team"
category: "Payment"
created_at: 2024-01-15 10:30:00
updated_at: 2024-01-15 10:30:00
```

### Comment
```
id: 1
ticket_id: 1
author: "john@company.com"
text: "Reproduced the issue. Server logs show payment gateway timeout."
created_at: 2024-01-15 11:00:00

id: 2
ticket_id: 1
author: "jane@company.com"
text: "Increased timeout threshold in config. Testing fix."
created_at: 2024-01-15 12:15:00
```

### Chunk (for embeddings)
```
{
  id: "ticket-1-description",
  content: "Ticket TKT-1: Payment Processing\nPayment processing fails at checkout. Error 503. Category: Payment, Priority: CRITICAL",
  metadata: {ticketId: 1, chunkType: "DESCRIPTION", status: "OPEN", priority: "CRITICAL"}
}

{
  id: "ticket-1-comment-1",
  content: "Reproduced the issue. Server logs show payment gateway timeout.",
  metadata: {ticketId: 1, chunkType: "COMMENT", status: "OPEN"}
}

{
  id: "ticket-1-comment-2",
  content: "Increased timeout threshold in config. Testing fix.",
  metadata: {ticketId: 1, chunkType: "COMMENT", status: "OPEN"}
}
```
