# 🚀 Auto Data Initialization

## What Was Added

Created `DataInitializer.java` - A Spring Boot component that automatically creates test data when the backend starts.

### File Location
```
src/main/java/support_ticket_ai/config/DataInitializer.java
```

---

## How It Works

### 1. **Automatic Trigger**
- Runs when Spring Boot application starts
- Implements `CommandLineRunner` interface
- Executes before the app is fully ready

### 2. **Safety Check**
```java
if (ticketRepository.count() > 0) {
    log.info("Database already contains data. Skipping initialization.");
    return;
}
```
- Only creates data if database is empty
- Won't duplicate data on multiple restarts with persistent DB
- Safe to run multiple times

### 3. **Data Created**
- **20 General Test Tickets** (OPEN status)
  - Various categories and priorities
  - Real-world scenarios
  
- **20 Resolved Tickets with Comments**
  - 5 POSITIVE sentiment feedback
  - 5 NEGATIVE sentiment feedback
  - 5 NEUTRAL sentiment feedback
  - 5 MIXED sentiment feedback
  - Each has comment for testing sentiment analysis

---

## Current Setup

### Data Persistence
Since we're using H2 in-memory database:
- **Each backend restart** = New H2 database = Auto data creation
- Data is NOT persisted across restarts
- This is intentional (testing/development)

### What You Get on Every Start
```
✅ 40 total tickets
✅ 20 OPEN tickets
✅ 20 RESOLVED tickets with feedback
✅ All sentiment types covered
✅ Ready to test immediately
```

---

## Testing the Feature

### Verify Data is Created
```bash
# Check total tickets
curl http://localhost:8080/api/tickets | jq '.totalElements'

# Check breakdown
curl 'http://localhost:8080/api/tickets?status=OPEN' | jq '.totalElements'
curl 'http://localhost:8080/api/tickets?status=RESOLVED' | jq '.totalElements'

# Check a specific ticket with comments
curl http://localhost:8080/api/tickets/21 | jq '.comments'
```

### What to Test
1. **Start Backend** → Data auto-creates
2. **Open http://localhost:3000**
3. **View All Tickets** → See 40 tickets immediately
4. **Click Ticket #21** → See sentiment feedback comment
5. **Go to AI Hub → Sentiment** → Analyze the feedback

---

## Modifying Test Data

### To Change Test Tickets
Edit: `DataInitializer.java`
- `createTestTickets()` method (lines ~75-130)
- Modify the `ticketsData` array

### To Change Sentiment Tickets
Edit: `DataInitializer.java`
- `createSentimentTickets()` method (lines ~132-280)
- Add/remove `createSentimentTicket()` calls
- Each call creates 1 resolved ticket + 1 comment

### Example: Add a New Ticket
```java
createSentimentTicket(
    "Your title here",
    "Your description here",
    "Your feedback/comment text here",
    TicketStatus.RESOLVED
);
```

---

## Recompile & Restart

After making changes:

```bash
# Recompile
cd /home/akash/Projects/ticket-ai
HOME=/tmp mvn -s /tmp/mvn-settings.xml clean compile -q -DskipTests

# Restart backend
pkill -9 java
cd /home/akash/Projects/ticket-ai
HOME=/tmp nohup mvn -s /tmp/mvn-settings.xml spring-boot:run -q > backend.log 2>&1 &

# Wait 15 seconds, then verify
curl http://localhost:8080/api/tickets | jq '.totalElements'
```

---

## Benefits

✅ **No Manual Data Creation** - Just start backend, data appears
✅ **Fresh Start Each Run** - Great for testing and demos
✅ **Full Feature Coverage** - Tests CRUD, comments, sentiment, etc.
✅ **Ready to Use** - Open browser immediately after start
✅ **Easy to Modify** - Change test data without touching DB

---

## Related Files

- `src/main/java/support_ticket_ai/repository/TicketRepository.java` - Provides save() method
- `src/main/java/support_ticket_ai/repository/CommentRepository.java` - Provides save() method
- `src/main/java/support_ticket_ai/entity/Ticket.java` - Entity definition
- `src/main/java/support_ticket_ai/entity/Comment.java` - Entity definition

---

## Logs

Check what's happening:
```bash
tail -50 backend.log | grep -i "initializ"
```

You should see:
```
Initializing test data...
Creating 20 general test tickets...
Creating 20 resolved tickets with sentiment feedback...
Test data initialization complete!
```

---

## ✅ Status

**Implementation:** Complete
**Testing:** Verified - 40 tickets auto-created on start
**Comments:** Working - All sentiment feedback included
**Production Ready:** No (uses in-memory H2) - Modify for persistent DB if needed

---

## 🎯 Next Steps (Optional)

If you want to persist data across restarts:
1. Replace H2 with PostgreSQL/MySQL in `pom.xml`
2. Update `application.properties` with DB connection
3. Modify `DataInitializer.java` to check if data should be created
4. Data will persist across restarts

For now, auto-creation on each restart is perfect for testing! 🚀
